
import React from 'react';
import { Text, StyleSheet, TextStyle } from 'react-native';
import { colors } from '@/styles/commonStyles';

interface Text3DProps {
  children: string;
  style?: TextStyle;
  size?: number;
  color?: string;
  depth?: number;
}

export default function Text3D({ 
  children, 
  style, 
  size = 36, 
  color = colors.card, 
  depth = 5 
}: Text3DProps) {
  console.log('Text3D rendered with text:', children);

  const dynamicStyles = StyleSheet.create({
    text3D: {
      fontSize: size,
      fontWeight: '900',
      color: color,
      textAlign: 'center',
      letterSpacing: 2,
      // Création de l'effet 3D avec des ombres multiples
      textShadowColor: 'rgba(0, 0, 0, 0.8)',
      textShadowOffset: { width: 1, height: 1 },
      textShadowRadius: 0,
      // Utilisation de boxShadow pour un effet 3D plus prononcé
      boxShadow: `
        1px 1px 0px rgba(0, 0, 0, 0.8),
        2px 2px 0px rgba(0, 0, 0, 0.7),
        3px 3px 0px rgba(0, 0, 0, 0.6),
        4px 4px 0px rgba(0, 0, 0, 0.5),
        5px 5px 0px rgba(0, 0, 0, 0.4),
        6px 6px 10px rgba(0, 0, 0, 0.3),
        0px 0px 20px rgba(255, 255, 255, 0.2)
      `,
      // Transformation pour donner un aspect légèrement incliné
      transform: [
        { perspective: 1000 },
        { rotateX: '10deg' },
        { rotateY: '-5deg' }
      ],
    } as TextStyle,
  });

  return (
    <Text style={[dynamicStyles.text3D, style]}>
      {children}
    </Text>
  );
}
