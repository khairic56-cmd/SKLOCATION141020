
import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { IconSymbol } from '@/components/IconSymbol';
import { colors } from '@/styles/commonStyles';
import { router } from 'expo-router';

interface ProfileButtonProps {
  isLoggedIn?: boolean;
  userName?: string;
}

export default function ProfileButton({ isLoggedIn = false, userName }: ProfileButtonProps) {
  console.log('ProfileButton rendered, isLoggedIn:', isLoggedIn);

  const handlePress = () => {
    console.log('Profile button pressed');
    if (isLoggedIn) {
      router.push('/profile-menu');
    } else {
      router.push('/auth-options');
    }
  };

  return (
    <Pressable 
      style={styles.container}
      onPress={handlePress}
      android_ripple={{ color: 'rgba(255, 255, 255, 0.2)' }}
    >
      <View style={styles.content}>
        {isLoggedIn ? (
          <>
            <View style={styles.avatar}>
              <IconSymbol name="person.fill" size={16} color={colors.primary} />
            </View>
            <Text style={styles.userName} numberOfLines={1}>
              {userName || 'Profil'}
            </Text>
          </>
        ) : (
          <>
            <IconSymbol name="person.circle" size={24} color={colors.card} />
            <Text style={styles.loginText}>Connexion</Text>
          </>
        )}
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
    borderRadius: 20,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  avatar: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: colors.card,
    alignItems: 'center',
    justifyContent: 'center',
  },
  userName: {
    color: colors.card,
    fontSize: 12,
    fontWeight: '600',
    maxWidth: 60,
  },
  loginText: {
    color: colors.card,
    fontSize: 12,
    fontWeight: '600',
  },
});
