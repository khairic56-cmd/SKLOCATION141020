
import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  SafeAreaView,
  ImageBackground,
  Dimensions,
  Platform,
} from 'react-native';
import { Stack } from 'expo-router';
import { IconSymbol } from '@/components/IconSymbol';
import { colors } from '@/styles/commonStyles';
import { BlurView } from 'expo-blur';

const { width: screenWidth, height: screenHeight } = Dimensions.get('window');

interface FAQItem {
  id: string;
  question: string;
  answer: string;
}

const faqData: FAQItem[] = [
  {
    id: '1',
    question: 'Comment réserver une voiture ?',
    answer: 'Vous pouvez réserver une voiture en naviguant vers la page "Voitures", en sélectionnant le véhicule de votre choix et en suivant les étapes de réservation. Vous devrez choisir vos dates et fournir vos informations personnelles.',
  },
  {
    id: '2',
    question: 'Quels sont les modes de paiement acceptés ?',
    answer: 'Nous acceptons les paiements par carte bancaire (30% d\'acompte), virement bancaire, ou vous pouvez confirmer votre réservation par téléphone au 066145612.',
  },
  {
    id: '3',
    question: 'Où se trouve SKLOCATION ?',
    answer: 'SKLOCATION est basé dans le nord à Caen. Nous sommes une jeune entreprise dynamique spécialisée dans la location de véhicules.',
  },
  {
    id: '4',
    question: 'Quels types de véhicules proposez-vous ?',
    answer: 'Actuellement, nous mettons en avant notre voiture de location principale. D\'autres véhicules seront bientôt disponibles dans notre flotte pour répondre à tous vos besoins de mobilité.',
  },
  {
    id: '5',
    question: 'Comment puis-je annuler ma réservation ?',
    answer: 'Pour annuler votre réservation, veuillez nous contacter directement par téléphone au 066145612. Nos conditions d\'annulation vous seront communiquées lors de la réservation.',
  },
  {
    id: '6',
    question: 'Y a-t-il une limite d\'âge pour louer ?',
    answer: 'Oui, vous devez avoir au moins 21 ans et posséder un permis de conduire valide depuis au moins 2 ans pour pouvoir louer nos véhicules.',
  },
];

export default function FAQScreen() {
  const [expandedItems, setExpandedItems] = useState<string[]>([]);

  const toggleExpanded = (itemId: string) => {
    setExpandedItems(prev => 
      prev.includes(itemId) 
        ? prev.filter(id => id !== itemId)
        : [...prev, itemId]
    );
  };

  const renderFAQItem = (item: FAQItem) => {
    const isExpanded = expandedItems.includes(item.id);

    return (
      <View key={item.id} style={styles.faqItemContainer}>
        <BlurView
          intensity={Platform.OS === 'web' ? 0 : 10}
          tint="light"
          style={styles.faqItemBlur}
        >
          <Pressable
            style={styles.faqQuestion}
            onPress={() => toggleExpanded(item.id)}
          >
            <View style={styles.questionContent}>
              <IconSymbol
                name="questionmark.circle.fill"
                size={24}
                color="#FFFFFF"
                style={styles.questionIcon}
              />
              <Text style={styles.questionText}>{item.question}</Text>
              <IconSymbol
                name={isExpanded ? "chevron.up" : "chevron.down"}
                size={20}
                color="#FFFFFF"
              />
            </View>
          </Pressable>
          
          {isExpanded && (
            <View style={styles.faqAnswer}>
              <Text style={styles.answerText}>{item.answer}</Text>
            </View>
          )}
        </BlurView>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <Stack.Screen
        options={{
          title: 'FAQ',
          headerShown: false,
        }}
      />
      
      <ImageBackground
        source={require('@/assets/images/fe8f2173-6ef5-41b2-a6f6-1f34f79363d7.jpeg')}
        style={styles.backgroundImage}
        resizeMode="cover"
      >
        <BlurView
          intensity={Platform.OS === 'web' ? 0 : 5}
          tint="dark"
          style={styles.overlay}
        >
          <ScrollView
            style={styles.scrollView}
            contentContainerStyle={styles.scrollContent}
            showsVerticalScrollIndicator={false}
          >
            {/* Header Section */}
            <View style={styles.header}>
              <BlurView
                intensity={Platform.OS === 'web' ? 0 : 15}
                tint="light"
                style={styles.headerBlur}
              >
                <View style={styles.headerContent}>
                  <View style={styles.logoContainer}>
                    <IconSymbol
                      name="car.fill"
                      size={40}
                      color="#FFFFFF"
                    />
                    <Text style={styles.companyName}>SKLOCATION</Text>
                  </View>
                  
                  <Text style={styles.companyDescription}>
                    Jeune entrepreneur basé dans le nord à Caen
                  </Text>
                  
                  <View style={styles.highlightContainer}>
                    <IconSymbol
                      name="star.fill"
                      size={20}
                      color="#FFFFFF"
                    />
                    <Text style={styles.highlightText}>
                      Voiture en location disponible
                    </Text>
                  </View>
                  
                  <Text style={styles.futureText}>
                    D'autres véhicules seront bientôt disponibles !
                  </Text>
                </View>
              </BlurView>
            </View>

            {/* FAQ Section */}
            <View style={styles.faqSection}>
              <View style={styles.faqHeader}>
                <IconSymbol
                  name="questionmark.circle.fill"
                  size={32}
                  color="#FFFFFF"
                />
                <Text style={styles.faqTitle}>Questions Fréquentes</Text>
              </View>

              <View style={styles.faqList}>
                {faqData.map(renderFAQItem)}
              </View>
            </View>

            {/* Contact Section */}
            <View style={styles.contactSection}>
              <BlurView
                intensity={Platform.OS === 'web' ? 0 : 15}
                tint="light"
                style={styles.contactBlur}
              >
                <View style={styles.contactContent}>
                  <IconSymbol
                    name="phone.fill"
                    size={24}
                    color="#FFFFFF"
                  />
                  <Text style={styles.contactTitle}>Une question ?</Text>
                  <Text style={styles.contactText}>
                    Contactez-nous au 066145612
                  </Text>
                </View>
              </BlurView>
            </View>
          </ScrollView>
        </BlurView>
      </ImageBackground>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  backgroundImage: {
    flex: 1,
    width: screenWidth,
    height: screenHeight,
  },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.4)',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: 120,
  },
  header: {
    marginTop: Platform.OS === 'ios' ? 60 : 40,
    marginHorizontal: 20,
    marginBottom: 30,
  },
  headerBlur: {
    borderRadius: 20,
    overflow: 'hidden',
    ...Platform.select({
      web: {
        backgroundColor: 'rgba(255, 255, 255, 0.9)',
        backdropFilter: 'blur(10px)',
      },
      default: {
        backgroundColor: 'rgba(255, 255, 255, 0.1)',
      },
    }),
  },
  headerContent: {
    padding: 24,
    alignItems: 'center',
  },
  logoContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  companyName: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginLeft: 12,
    letterSpacing: 1,
  },
  companyDescription: {
    fontSize: 16,
    color: '#FFFFFF',
    textAlign: 'center',
    marginBottom: 20,
    fontStyle: 'italic',
  },
  highlightContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    marginBottom: 12,
  },
  highlightText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
    marginLeft: 8,
  },
  futureText: {
    fontSize: 14,
    color: '#FFFFFF',
    textAlign: 'center',
    fontWeight: '500',
  },
  faqSection: {
    marginHorizontal: 20,
    marginBottom: 30,
  },
  faqHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
    paddingHorizontal: 4,
  },
  faqTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginLeft: 12,
  },
  faqList: {
    gap: 12,
  },
  faqItemContainer: {
    marginBottom: 4,
  },
  faqItemBlur: {
    borderRadius: 16,
    overflow: 'hidden',
    ...Platform.select({
      web: {
        backgroundColor: 'rgba(255, 255, 255, 0.9)',
        backdropFilter: 'blur(10px)',
      },
      default: {
        backgroundColor: 'rgba(255, 255, 255, 0.1)',
      },
    }),
  },
  faqQuestion: {
    padding: 16,
  },
  questionContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  questionIcon: {
    marginRight: 12,
  },
  questionText: {
    flex: 1,
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  faqAnswer: {
    paddingHorizontal: 16,
    paddingBottom: 16,
    paddingTop: 0,
  },
  answerText: {
    fontSize: 14,
    color: '#FFFFFF',
    lineHeight: 20,
    marginLeft: 36,
  },
  contactSection: {
    marginHorizontal: 20,
    marginBottom: 40,
  },
  contactBlur: {
    borderRadius: 16,
    overflow: 'hidden',
    ...Platform.select({
      web: {
        backgroundColor: 'rgba(255, 255, 255, 0.9)',
        backdropFilter: 'blur(10px)',
      },
      default: {
        backgroundColor: 'rgba(255, 255, 255, 0.1)',
      },
    }),
  },
  contactContent: {
    padding: 20,
    alignItems: 'center',
  },
  contactTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginTop: 8,
    marginBottom: 4,
  },
  contactText: {
    fontSize: 16,
    color: '#FFFFFF',
    fontWeight: '600',
  },
});
