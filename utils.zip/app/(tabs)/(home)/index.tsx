
import React from "react";
import { Stack, Link } from "expo-router";
import { 
  ImageBackground, 
  Pressable, 
  StyleSheet, 
  View, 
  Text, 
  Platform,
  Dimensions,
  Image,
  Alert 
} from "react-native";
import { IconSymbol } from "@/components/IconSymbol";
import { colors } from "@/styles/commonStyles";
import { LinearGradient } from "expo-linear-gradient";
import Text3D from "@/components/Text3D";
import ProfileButton from "@/components/ProfileButton";
import * as WebBrowser from 'expo-web-browser';

const { width, height } = Dimensions.get('window');

export default function HomeScreen() {
  console.log('HomeScreen rendered');

  const handleSnapchatPress = async () => {
    console.log('Snapchat logo pressed');
    try {
      await WebBrowser.openBrowserAsync('https://snapchat.com/t/JyMGlmWc');
    } catch (error) {
      console.log('Error opening Snapchat URL:', error);
      Alert.alert('Erreur', 'Impossible d\'ouvrir le lien Snapchat');
    }
  };

  return (
    <>
      {Platform.OS === 'ios' && (
        <Stack.Screen
          options={{
            title: "SK LOC14",
            headerShown: false,
          }}
        />
      )}
      <ImageBackground
        source={require('@/assets/images/90892188-64fb-44bd-89c7-885a77d4b1e0.jpeg')}
        style={styles.backgroundImage}
        resizeMode="cover"
      >
        <LinearGradient
          colors={['rgba(0,0,0,0.3)', 'rgba(0,0,0,0.6)']}
          style={styles.overlay}
        >
          <View style={styles.container}>
            {/* Profile Button in top right */}
            <View style={styles.topBar}>
              <View style={styles.topBarSpacer} />
              <ProfileButton isLoggedIn={false} />
            </View>

            <View style={styles.header}>
              <Text3D size={42} color={colors.card} style={styles.title3D}>
                SK LOC14
              </Text3D>
              <Text style={styles.subtitle}>Location de voitures premium</Text>
            </View>
            
            <View style={styles.content}>
              <View style={styles.welcomeSection}>
                <Text style={styles.welcomeText}>
                  Découvrez notre flotte de véhicules exceptionnels
                </Text>
              </View>
              
              <Link href="/voiture" asChild>
                <Pressable style={styles.exploreButton}>
                  <IconSymbol name="car.fill" color={colors.card} size={24} />
                  <Text style={styles.exploreButtonText}>Explorer les voitures</Text>
                  <IconSymbol name="chevron.right" color={colors.card} size={20} />
                </Pressable>
              </Link>
            </View>
            
            <View style={styles.footer}>
              <Text style={styles.footerText}>
                Votre partenaire de confiance pour la location
              </Text>
              
              {/* Snapchat QR Code */}
              <Pressable 
                style={styles.snapchatButton}
                onPress={handleSnapchatPress}
                android_ripple={{ color: 'rgba(255, 255, 255, 0.2)' }}
              >
                <Image
                  source={require('@/assets/images/58bccc5c-eb26-4d93-89dd-e25ab0e9577b.jpeg')}
                  style={styles.snapchatLogo}
                  resizeMode="contain"
                />
                <Text style={styles.snapchatText}>Suivez-nous sur Snapchat</Text>
              </Pressable>
            </View>
          </View>
        </LinearGradient>
      </ImageBackground>
    </>
  );
}

const styles = StyleSheet.create({
  backgroundImage: {
    flex: 1,
    width: width,
    height: height,
  },
  overlay: {
    flex: 1,
  },
  container: {
    flex: 1,
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: Platform.OS === 'ios' ? 60 : 40,
    paddingBottom: Platform.OS !== 'ios' ? 120 : 60, // Extra padding for floating tab bar and Snapchat button
  },
  topBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  topBarSpacer: {
    flex: 1,
  },
  header: {
    alignItems: 'center',
    marginTop: 20,
  },
  title3D: {
    marginBottom: 10,
    // Ajout d'un effet de brillance
    textShadowColor: 'rgba(255, 255, 255, 0.3)',
    textShadowOffset: { width: 0, height: -1 },
    textShadowRadius: 2,
  },
  subtitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.card,
    textAlign: 'center',
    marginTop: 8,
    textShadowColor: 'rgba(0, 0, 0, 0.6)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 2,
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  welcomeSection: {
    marginBottom: 40,
    paddingHorizontal: 20,
  },
  welcomeText: {
    fontSize: 20,
    fontWeight: '500',
    color: colors.card,
    textAlign: 'center',
    lineHeight: 28,
    textShadowColor: 'rgba(0, 0, 0, 0.6)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 2,
  },
  exploreButton: {
    backgroundColor: colors.primary,
    paddingHorizontal: 32,
    paddingVertical: 16,
    borderRadius: 30,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    minWidth: 250,
    boxShadow: '0px 8px 20px rgba(41, 98, 255, 0.3)',
    elevation: 8,
  },
  exploreButtonText: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.card,
    marginHorizontal: 12,
  },
  footer: {
    alignItems: 'center',
    marginBottom: 20,
  },
  footerText: {
    fontSize: 14,
    fontWeight: '400',
    color: colors.card,
    textAlign: 'center',
    opacity: 0.9,
    textShadowColor: 'rgba(0, 0, 0, 0.6)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 2,
    marginBottom: 20,
  },
  snapchatButton: {
    backgroundColor: 'rgba(255, 252, 0, 0.9)', // Snapchat yellow with transparency
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 20,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    minWidth: 180,
    boxShadow: '0px 4px 15px rgba(255, 252, 0, 0.4)',
    elevation: 6,
    borderWidth: 2,
    borderColor: '#FFFC00',
  },
  snapchatLogo: {
    width: 32,
    height: 32,
    marginRight: 8,
    borderRadius: 4,
  },
  snapchatText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#000000', // Black text on yellow background for contrast
  },
});
