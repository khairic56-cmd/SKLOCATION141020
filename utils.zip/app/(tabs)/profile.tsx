
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  SafeAreaView,
  ImageBackground,
  Platform,
} from 'react-native';
import { Stack, router } from 'expo-router';
import { IconSymbol } from '@/components/IconSymbol';
import { colors } from '@/styles/commonStyles';
import { BlurView } from 'expo-blur';
import { supabase } from '@/app/integrations/supabase/client';

export default function ProfileScreen() {
  console.log('ProfileScreen rendered');
  
  const [isAdmin, setIsAdmin] = useState(false);
  const [userEmail, setUserEmail] = useState<string | null>(null);

  useEffect(() => {
    checkAdminStatus();
  }, []);

  const checkAdminStatus = async () => {
    try {
      const { data: { user }, error } = await supabase.auth.getUser();
      
      if (error || !user) {
        setIsAdmin(false);
        setUserEmail(null);
        return;
      }

      setUserEmail(user.email || null);

      // Check if user is admin
      const { data: adminData, error: adminError } = await supabase
        .from('admin_users')
        .select('*')
        .eq('email', user.email)
        .single();

      if (!adminError && adminData) {
        setIsAdmin(true);
      }
    } catch (error) {
      console.error('Error checking admin status:', error);
    }
  };

  const handleAuthOptions = () => {
    console.log('Navigate to auth options');
    router.push('/auth-options');
  };

  const handleAdminPanel = () => {
    console.log('Navigate to admin panel');
    router.push('/admin-panel');
  };

  return (
    <ImageBackground
      source={require('@/assets/images/285c86af-6344-4f73-beac-dbfa2112b685.jpeg')}
      style={styles.container}
      resizeMode="cover"
    >
      <SafeAreaView style={styles.safeArea}>
        <Stack.Screen
          options={{
            title: 'Profil',
            headerShown: true,
            headerStyle: { backgroundColor: 'transparent' },
            headerTintColor: '#FFFFFF',
            headerTitleStyle: { fontWeight: '700', fontSize: 20 },
            headerBackground: () => (
              <BlurView
                intensity={10}
                tint="dark"
                style={[StyleSheet.absoluteFill, Platform.OS !== 'ios' && { backgroundColor: 'rgba(0,0,0,0.1)' }]}
              />
            ),
          }}
        />

        <View style={styles.content}>
          <BlurView
            intensity={5}
            tint="extraLight"
            style={[styles.card, Platform.OS !== 'ios' && { backgroundColor: 'rgba(255,255,255,0.05)' }]}
          >
            <IconSymbol name="person.circle.fill" color={colors.primary} size={80} />
            <Text style={styles.title}>Mon Profil</Text>
            
            {userEmail && (
              <View style={styles.userInfoContainer}>
                <Text style={styles.userEmail}>{userEmail}</Text>
                {isAdmin && (
                  <View style={styles.adminBadge}>
                    <IconSymbol name="shield.checkmark.fill" color={colors.secondary} size={16} />
                    <Text style={styles.adminBadgeText}>Administrateur</Text>
                  </View>
                )}
              </View>
            )}

            <Text style={styles.subtitle}>
              Connectez-vous pour accéder à votre profil et gérer vos réservations
            </Text>

            {isAdmin && (
              <Pressable style={styles.adminButton} onPress={handleAdminPanel}>
                <IconSymbol name="shield.checkmark.fill" color={colors.card} size={24} />
                <Text style={styles.adminButtonText}>Panneau d'administration</Text>
                <IconSymbol name="chevron.right" color={colors.card} size={20} />
              </Pressable>
            )}

            <Pressable style={styles.authButton} onPress={handleAuthOptions}>
              <IconSymbol name="person.fill" color={colors.card} size={24} />
              <Text style={styles.authButtonText}>Se connecter / S'inscrire</Text>
              <IconSymbol name="chevron.right" color={colors.card} size={20} />
            </Pressable>
          </BlurView>
        </View>
      </SafeAreaView>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  card: {
    borderRadius: 20,
    padding: 32,
    alignItems: 'center',
    width: '100%',
    maxWidth: 400,
    boxShadow: '0px 8px 24px rgba(0, 0, 0, 0.3)',
    elevation: 12,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
    overflow: 'hidden',
  },
  title: {
    fontSize: 28,
    fontWeight: '800',
    color: '#FFFFFF',
    marginTop: 16,
    marginBottom: 8,
    textAlign: 'center',
  },
  userInfoContainer: {
    alignItems: 'center',
    marginBottom: 12,
  },
  userEmail: {
    fontSize: 16,
    color: '#FFFFFF',
    marginBottom: 8,
  },
  adminBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(76, 175, 80, 0.2)',
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: colors.secondary,
  },
  adminBadgeText: {
    fontSize: 12,
    fontWeight: '700',
    color: colors.secondary,
  },
  subtitle: {
    fontSize: 16,
    color: '#FFFFFF',
    textAlign: 'center',
    lineHeight: 22,
    marginBottom: 24,
  },
  adminButton: {
    backgroundColor: colors.secondary,
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '100%',
    marginBottom: 16,
    boxShadow: '0px 4px 12px rgba(76, 175, 80, 0.3)',
    elevation: 6,
  },
  adminButtonText: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.card,
    flex: 1,
    marginLeft: 12,
  },
  authButton: {
    backgroundColor: colors.primary,
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '100%',
    boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.2)',
    elevation: 6,
  },
  authButtonText: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.card,
    flex: 1,
    marginLeft: 12,
  },
});
