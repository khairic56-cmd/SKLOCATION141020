
import React from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  Pressable, 
  SafeAreaView,
  Platform,
  ImageBackground,
  Dimensions
} from 'react-native';
import { Stack, router } from 'expo-router';
import { IconSymbol } from '@/components/IconSymbol';
import { colors } from '@/styles/commonStyles';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';

const { width, height } = Dimensions.get('window');

export default function AuthOptionsScreen() {
  console.log('AuthOptionsScreen rendered');

  const handleLogin = () => {
    console.log('Login button pressed');
    router.push('/login');
  };

  const handleSignup = () => {
    console.log('Signup button pressed');
    router.push('/signup');
  };

  const handleBack = () => {
    console.log('Back button pressed');
    router.back();
  };

  return (
    <>
      <Stack.Screen
        options={{
          title: "Connexion",
          headerShown: false,
        }}
      />
      <ImageBackground
        source={require('@/assets/images/e24524a0-8894-4ab5-996d-ee7e6c73c38a.jpeg')}
        style={styles.backgroundImage}
        resizeMode="cover"
      >
        <LinearGradient
          colors={['rgba(0, 0, 0, 0.4)', 'rgba(0, 0, 0, 0.7)', 'rgba(0, 0, 0, 0.9)']}
          style={styles.overlay}
        >
          <SafeAreaView style={styles.safeArea}>
            <View style={styles.header}>
              <Pressable style={styles.backButton} onPress={handleBack}>
                <IconSymbol name="chevron.left" size={24} color="#FFFFFF" />
              </Pressable>
            </View>

            <View style={styles.content}>
              <View style={styles.logoSection}>
                <View style={styles.logoContainer}>
                  <IconSymbol name="car.fill" size={60} color="#FFFFFF" />
                </View>
                <Text style={styles.brandTitle}>SK LOCATION14</Text>
                <Text style={styles.brandSubtitle}>Location de voitures premium</Text>
              </View>

              <BlurView intensity={20} tint="dark" style={styles.optionsCard}>
                <View style={styles.welcomeSection}>
                  <Text style={styles.welcomeTitle}>Bienvenue !</Text>
                  <Text style={styles.welcomeSubtitle}>
                    Connectez-vous ou créez un compte pour accéder à nos services
                  </Text>
                </View>

                <View style={styles.buttonsContainer}>
                  <Pressable style={styles.loginButton} onPress={handleLogin}>
                    <LinearGradient
                      colors={['#2962FF', '#1E88E5']}
                      style={styles.loginButtonGradient}
                    >
                      <IconSymbol name="person.circle" size={24} color="#FFFFFF" />
                      <Text style={styles.loginButtonText}>Se connecter</Text>
                      <IconSymbol name="arrow.right" size={20} color="#FFFFFF" />
                    </LinearGradient>
                  </Pressable>

                  <Pressable style={styles.signupButton} onPress={handleSignup}>
                    <View style={styles.signupButtonContent}>
                      <IconSymbol name="person.badge.plus" size={24} color="#2962FF" />
                      <Text style={styles.signupButtonText}>Créer un compte</Text>
                      <IconSymbol name="arrow.right" size={20} color="#2962FF" />
                    </View>
                  </Pressable>
                </View>

                <View style={styles.featuresSection}>
                  <Text style={styles.featuresTitle}>Avec votre compte :</Text>
                  <View style={styles.featuresList}>
                    <View style={styles.featureItem}>
                      <IconSymbol name="checkmark.circle.fill" size={20} color="#4CAF50" />
                      <Text style={styles.featureText}>Réservations rapides</Text>
                    </View>
                    <View style={styles.featureItem}>
                      <IconSymbol name="checkmark.circle.fill" size={20} color="#4CAF50" />
                      <Text style={styles.featureText}>Historique des locations</Text>
                    </View>
                    <View style={styles.featureItem}>
                      <IconSymbol name="checkmark.circle.fill" size={20} color="#4CAF50" />
                      <Text style={styles.featureText}>Offres exclusives</Text>
                    </View>
                    <View style={styles.featureItem}>
                      <IconSymbol name="checkmark.circle.fill" size={20} color="#4CAF50" />
                      <Text style={styles.featureText}>Support prioritaire</Text>
                    </View>
                  </View>
                </View>
              </BlurView>
            </View>
          </SafeAreaView>
        </LinearGradient>
      </ImageBackground>
    </>
  );
}

const styles = StyleSheet.create({
  backgroundImage: {
    flex: 1,
  },
  overlay: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: Platform.OS === 'ios' ? 10 : 20,
    paddingBottom: 20,
  },
  backButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    alignItems: 'center',
    justifyContent: 'center',
    backdropFilter: 'blur(10px)',
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
    justifyContent: 'center',
    paddingBottom: 40,
  },
  logoSection: {
    alignItems: 'center',
    marginBottom: 40,
  },
  logoContainer: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
    backdropFilter: 'blur(10px)',
  },
  brandTitle: {
    fontSize: 36,
    fontWeight: '900',
    color: '#FFFFFF',
    marginBottom: 8,
    textAlign: 'center',
    letterSpacing: 1.5,
  },
  brandSubtitle: {
    fontSize: 18,
    color: 'rgba(255, 255, 255, 0.8)',
    textAlign: 'center',
    fontWeight: '500',
  },
  optionsCard: {
    borderRadius: 24,
    padding: 28,
    overflow: 'hidden',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
  },
  welcomeSection: {
    alignItems: 'center',
    marginBottom: 32,
  },
  welcomeTitle: {
    fontSize: 32,
    fontWeight: '800',
    color: '#FFFFFF',
    marginBottom: 12,
  },
  welcomeSubtitle: {
    fontSize: 16,
    color: 'rgba(255, 255, 255, 0.8)',
    textAlign: 'center',
    lineHeight: 24,
    paddingHorizontal: 8,
  },
  buttonsContainer: {
    gap: 16,
    marginBottom: 32,
  },
  loginButton: {
    borderRadius: 16,
    overflow: 'hidden',
  },
  loginButtonGradient: {
    paddingVertical: 18,
    paddingHorizontal: 24,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
  },
  loginButtonText: {
    fontSize: 18,
    fontWeight: '700',
    color: '#FFFFFF',
    flex: 1,
    textAlign: 'center',
  },
  signupButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    borderRadius: 16,
    overflow: 'hidden',
  },
  signupButtonContent: {
    paddingVertical: 18,
    paddingHorizontal: 24,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
  },
  signupButtonText: {
    fontSize: 18,
    fontWeight: '700',
    color: '#2962FF',
    flex: 1,
    textAlign: 'center',
  },
  featuresSection: {
    alignItems: 'center',
  },
  featuresTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: 'rgba(255, 255, 255, 0.9)',
    marginBottom: 16,
  },
  featuresList: {
    gap: 12,
    alignSelf: 'stretch',
  },
  featureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingHorizontal: 8,
  },
  featureText: {
    fontSize: 14,
    color: 'rgba(255, 255, 255, 0.8)',
    fontWeight: '500',
  },
});
