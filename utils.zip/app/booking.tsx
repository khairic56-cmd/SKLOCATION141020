
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  SafeAreaView,
  Platform,
  Alert,
  Modal,
  ScrollView,
  Dimensions,
  ImageBackground,
  TextInput,
  Linking,
} from 'react-native';
import { Stack, router } from 'expo-router';
import { IconSymbol } from '@/components/IconSymbol';
import { colors } from '@/styles/commonStyles';
import DateTimePicker from '@react-native-community/datetimepicker';
import { differenceInDays, isFriday, isSunday, format, addDays } from 'date-fns';
import { fr } from 'date-fns/locale';
import { BlurView } from 'expo-blur';
import { supabase } from '@/app/integrations/supabase/client';
import type { Tables, TablesInsert } from '@/app/integrations/supabase/types';

const { width } = Dimensions.get('window');

interface PriceCalculation {
  price: number;
  discountMessage?: string;
  isWeekendSpecial?: boolean;
}

interface BookingOption {
  id: string;
  name: string;
  description: string | null;
  price: number;
  category: string;
  selected?: boolean;
}

type BookingStep = 'auth' | 'dates' | 'pickup' | 'summary' | 'user-info' | 'payment' | 'confirmation';

export default function BookingScreen() {
  console.log('BookingScreen rendered');
  
  // Main flow state
  const [currentStep, setCurrentStep] = useState<BookingStep>('auth');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isGuest, setIsGuest] = useState(false);
  
  // Date and time states
  const [startDate, setStartDate] = useState<Date | null>(null);
  const [endDate, setEndDate] = useState<Date | null>(null);
  const [startTime, setStartTime] = useState<Date | null>(null);
  const [endTime, setEndTime] = useState<Date | null>(null);
  const [showStartDatePicker, setShowStartDatePicker] = useState(false);
  const [showEndDatePicker, setShowEndDatePicker] = useState(false);
  const [showStartTimePicker, setShowStartTimePicker] = useState(false);
  const [showEndTimePicker, setShowEndTimePicker] = useState(false);
  const [hasUserSelectedDates, setHasUserSelectedDates] = useState(false);
  
  // Pickup location states
  const [pickupLocations, setPickupLocations] = useState<Tables<'pickup_locations'>[]>([]);
  const [selectedPickupLocation, setSelectedPickupLocation] = useState<Tables<'pickup_locations'> | null>(null);
  const [pickupOption, setPickupOption] = useState<'pickup' | 'delivery'>('pickup');
  const [customDeliveryAddress, setCustomDeliveryAddress] = useState('');
  
  // Additional options states
  const [availableOptions, setAvailableOptions] = useState<BookingOption[]>([]);
  const [selectedOptions, setSelectedOptions] = useState<BookingOption[]>([]);
  
  // User information states
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [dateOfBirth, setDateOfBirth] = useState<Date | null>(null);
  const [showDateOfBirthPicker, setShowDateOfBirthPicker] = useState(false);
  
  // Price and booking states
  const [priceCalculation, setPriceCalculation] = useState<PriceCalculation>({ price: 0 });
  const [showDiscountModal, setShowDiscountModal] = useState(false);
  const [showGuestWarning, setShowGuestWarning] = useState(false);
  const [bookingId, setBookingId] = useState<string | null>(null);
  
  // Car information (would normally come from navigation params)
  const carInfo = {
    id: 'car-1',
    name: 'Peugeot 208',
    brand: 'Peugeot',
    type: 'Citadine'
  };

  useEffect(() => {
    loadPickupLocations();
    loadBookingOptions();
  }, []);

  useEffect(() => {
    if (startDate && endDate && hasUserSelectedDates) {
      calculatePrice();
    }
  }, [startDate, endDate, hasUserSelectedDates, selectedOptions]);

  const loadPickupLocations = async () => {
    try {
      const { data, error } = await supabase
        .from('pickup_locations')
        .select('*')
        .eq('is_active', true)
        .order('name');
      
      if (error) throw error;
      setPickupLocations(data || []);
    } catch (error) {
      console.error('Error loading pickup locations:', error);
      Alert.alert('Erreur', 'Impossible de charger les lieux de récupération');
    }
  };

  const loadBookingOptions = async () => {
    try {
      const { data, error } = await supabase
        .from('booking_options')
        .select('*')
        .eq('is_active', true)
        .order('category, name');
      
      if (error) throw error;
      setAvailableOptions((data || []).map(option => ({ ...option, selected: false })));
    } catch (error) {
      console.error('Error loading booking options:', error);
      Alert.alert('Erreur', 'Impossible de charger les options disponibles');
    }
  };

  const calculatePrice = () => {
    if (!startDate || !endDate) return;

    const duration = differenceInDays(endDate, startDate) + 1;
    const isWeekendBooking = isFriday(startDate) && isSunday(endDate);
    
    let basePrice = 0;
    let discountMessage: string | undefined;
    let isWeekendSpecial = false;

    if (isWeekendBooking) {
      isWeekendSpecial = true;
      if (duration === 2) {
        basePrice = 1000;
        discountMessage = "Offre spéciale weekend - 48h";
      } else if (duration === 3) {
        basePrice = 1200;
        discountMessage = "Offre spéciale weekend - 72h";
      }
    } else {
      switch (duration) {
        case 2:
          basePrice = 600;
          discountMessage = "Remise appliquée pour 2 jours";
          break;
        case 3:
          basePrice = 780;
          discountMessage = "Remise appliquée pour 3 jours";
          break;
        case 4:
          basePrice = 1000;
          discountMessage = "Remise appliquée pour 4 jours";
          break;
        case 5:
          basePrice = 1200;
          discountMessage = "Remise appliquée pour 5 jours";
          break;
        default:
          basePrice = duration * 350;
          break;
      }
    }

    // Add options price
    const optionsPrice = selectedOptions.reduce((total, option) => total + option.price, 0);
    const totalPrice = basePrice + optionsPrice;

    // Add delivery fee if applicable
    const deliveryFee = pickupOption === 'delivery' ? 25 : 0;
    const finalPrice = totalPrice + deliveryFee;

    const calculation: PriceCalculation = {
      price: finalPrice,
      discountMessage,
      isWeekendSpecial
    };

    setPriceCalculation(calculation);

    if (discountMessage && finalPrice > 0 && hasUserSelectedDates && currentStep === 'dates') {
      setTimeout(() => {
        setShowDiscountModal(true);
      }, 500);
    }
  };

  const handleLogin = () => {
    console.log('Navigate to login');
    router.push('/login');
  };

  const handleContinueAsGuest = () => {
    console.log('Continue as guest');
    setIsAuthenticated(false);
    setIsGuest(true);
    setCurrentStep('dates');
  };

  const handleAuthenticatedUser = () => {
    setIsAuthenticated(true);
    setIsGuest(false);
    setCurrentStep('dates');
  };

  const handleDatesConfirm = () => {
    if (!startDate || !endDate || !startTime || !endTime) {
      Alert.alert('Erreur', 'Veuillez sélectionner les dates et heures de début et de fin.');
      return;
    }
    setCurrentStep('pickup');
  };

  const handlePickupConfirm = () => {
    if (pickupOption === 'pickup' && !selectedPickupLocation) {
      Alert.alert('Erreur', 'Veuillez sélectionner un lieu de récupération.');
      return;
    }

    if (pickupOption === 'delivery' && !customDeliveryAddress.trim()) {
      Alert.alert('Erreur', 'Veuillez entrer une adresse de livraison.');
      return;
    }

    setCurrentStep('summary');
  };

  const handleSummaryConfirm = () => {
    if (isGuest) {
      setShowGuestWarning(true);
    } else {
      setCurrentStep('payment');
    }
  };

  const handleGuestWarningOk = () => {
    setShowGuestWarning(false);
    setCurrentStep('user-info');
  };

  const handleUserInfoSubmit = () => {
    if (!firstName.trim() || !email.trim()) {
      Alert.alert('Erreur', 'Veuillez remplir au moins le prénom et l\'adresse email.');
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      Alert.alert('Erreur', 'Veuillez entrer une adresse email valide.');
      return;
    }

    setCurrentStep('payment');
  };

  const handlePayment = async (paymentMethod: 'credit_card' | 'bank_transfer' | 'phone_confirmation') => {
    try {
      // Create booking in database
      const bookingData: TablesInsert<'bookings'> = {
        user_id: isAuthenticated ? (await supabase.auth.getUser()).data.user?.id || null : null,
        guest_email: isGuest ? email : null,
        guest_first_name: isGuest ? firstName : null,
        guest_last_name: isGuest ? lastName : null,
        car_id: carInfo.id,
        start_date: format(startDate!, 'yyyy-MM-dd'),
        end_date: format(endDate!, 'yyyy-MM-dd'),
        start_time: format(startTime!, 'HH:mm:ss'),
        end_time: format(endTime!, 'HH:mm:ss'),
        pickup_location: pickupOption === 'pickup' ? selectedPickupLocation!.name : 'Livraison à domicile',
        pickup_type: pickupOption,
        delivery_address: pickupOption === 'delivery' ? customDeliveryAddress : null,
        total_price: priceCalculation.price,
        deposit_amount: Math.round(priceCalculation.price * 0.3),
        payment_method: paymentMethod,
        additional_options: selectedOptions.map(opt => ({ id: opt.id, name: opt.name, price: opt.price }))
      };

      const { data: booking, error } = await supabase
        .from('bookings')
        .insert(bookingData)
        .select()
        .single();

      if (error) throw error;

      setBookingId(booking.id);

      // Send confirmation email
      await sendConfirmationEmail(booking);

      setCurrentStep('confirmation');

    } catch (error) {
      console.error('Error creating booking:', error);
      Alert.alert('Erreur', 'Impossible de créer la réservation. Veuillez réessayer.');
    }
  };

  const sendConfirmationEmail = async (booking: Tables<'bookings'>) => {
    try {
      const response = await fetch(`${supabase.supabaseUrl}/functions/v1/send-booking-confirmation`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${supabase.supabaseKey}`,
        },
        body: JSON.stringify({
          bookingId: booking.id,
          email: booking.guest_email || email,
          firstName: booking.guest_first_name || firstName,
          lastName: booking.guest_last_name || lastName,
          carName: carInfo.name,
          startDate: booking.start_date,
          endDate: booking.end_date,
          startTime: booking.start_time,
          endTime: booking.end_time,
          pickupLocation: booking.pickup_location,
          pickupType: booking.pickup_type,
          deliveryAddress: booking.delivery_address,
          totalPrice: booking.total_price,
          depositAmount: booking.deposit_amount,
          paymentMethod: booking.payment_method,
          additionalOptions: booking.additional_options || []
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to send confirmation email');
      }

      console.log('Confirmation email sent successfully');
    } catch (error) {
      console.error('Error sending confirmation email:', error);
      // Don't show error to user as booking was successful
    }
  };

  const toggleOption = (optionId: string) => {
    const option = availableOptions.find(opt => opt.id === optionId);
    if (!option) return;

    const isSelected = selectedOptions.some(opt => opt.id === optionId);
    
    if (isSelected) {
      setSelectedOptions(prev => prev.filter(opt => opt.id !== optionId));
    } else {
      setSelectedOptions(prev => [...prev, option]);
    }
  };

  // Date/Time picker handlers
  const handleStartDateChange = (event: any, selectedDate?: Date) => {
    setShowStartDatePicker(false);
    if (selectedDate && event.type !== 'dismissed') {
      setStartDate(selectedDate);
      setHasUserSelectedDates(true);
      if (endDate && selectedDate >= endDate) {
        setEndDate(addDays(selectedDate, 1));
      }
    }
  };

  const handleEndDateChange = (event: any, selectedDate?: Date) => {
    setShowEndDatePicker(false);
    if (selectedDate && event.type !== 'dismissed' && startDate && selectedDate > startDate) {
      setEndDate(selectedDate);
      setHasUserSelectedDates(true);
    } else if (selectedDate && startDate && selectedDate <= startDate) {
      Alert.alert('Date invalide', 'La date de fin doit être après la date de début.');
    }
  };

  const handleStartTimeChange = (event: any, selectedTime?: Date) => {
    setShowStartTimePicker(false);
    if (selectedTime && event.type !== 'dismissed') {
      setStartTime(selectedTime);
    }
  };

  const handleEndTimeChange = (event: any, selectedTime?: Date) => {
    setShowEndTimePicker(false);
    if (selectedTime && event.type !== 'dismissed') {
      setEndTime(selectedTime);
    }
  };

  const handleDateOfBirthChange = (event: any, selectedDate?: Date) => {
    setShowDateOfBirthPicker(false);
    if (selectedDate && event.type !== 'dismissed') {
      setDateOfBirth(selectedDate);
    }
  };

  const openStartDatePicker = () => setShowStartDatePicker(true);
  const openEndDatePicker = () => {
    if (!startDate) {
      Alert.alert('Sélectionnez d\'abord la date de début', 'Veuillez d\'abord choisir votre date de début avant de sélectionner la date de fin.');
      return;
    }
    setShowEndDatePicker(true);
  };
  const openStartTimePicker = () => setShowStartTimePicker(true);
  const openEndTimePicker = () => setShowEndTimePicker(true);

  // Render functions for each step
  const renderAuthStep = () => (
    <View style={styles.stepContainer}>
      <BlurView intensity={5} tint="extraLight" style={[styles.authCard, Platform.OS !== 'ios' && { backgroundColor: 'rgba(255,255,255,0.05)' }]}>
        <IconSymbol name="person.circle.fill" color={colors.primary} size={64} />
        <Text style={styles.authTitle}>Finaliser votre réservation</Text>
        <Text style={styles.authSubtitle}>
          Connectez-vous pour accéder à vos réservations ou continuez comme invité
        </Text>
        
        <Pressable style={styles.loginButton} onPress={handleLogin}>
          <IconSymbol name="person.fill" color={colors.card} size={20} />
          <Text style={styles.loginButtonText}>Se connecter</Text>
        </Pressable>
        
        <Pressable style={styles.guestButton} onPress={handleContinueAsGuest}>
          <IconSymbol name="arrow.right.circle" color={colors.primary} size={20} />
          <Text style={styles.guestButtonText}>Continuer comme invité</Text>
        </Pressable>
      </BlurView>
    </View>
  );

  const renderDatesStep = () => (
    <View style={styles.stepContainer}>
      <BlurView intensity={1} tint="extraLight" style={[styles.datePickerContainer, Platform.OS !== 'ios' && { backgroundColor: 'rgba(255,255,255,0.05)' }]}>
        <Text style={styles.sectionTitle}>Sélectionnez vos dates et heures</Text>
        
        <View style={styles.dateRow}>
          <View style={styles.dateItem}>
            <Text style={styles.dateLabel}>Date de début</Text>
            <Pressable style={styles.dateButton} onPress={openStartDatePicker}>
              <IconSymbol name="calendar" color={colors.primary} size={20} />
              <Text style={[styles.dateText, !startDate && styles.placeholderText]}>
                {startDate ? format(startDate, 'dd MMM yyyy', { locale: fr }) : 'Sélectionner'}
              </Text>
            </Pressable>
          </View>
          
          <View style={styles.dateItem}>
            <Text style={styles.dateLabel}>Date de fin</Text>
            <Pressable style={[styles.dateButton, !startDate && styles.disabledButton]} onPress={openEndDatePicker} disabled={!startDate}>
              <IconSymbol name="calendar" color={!startDate ? '#757575' : colors.primary} size={18} />
              <Text style={[styles.dateText, !endDate && styles.placeholderText, !startDate && styles.disabledText]}>
                {endDate ? format(endDate, 'dd MMM yyyy', { locale: fr }) : 'Sélectionner'}
              </Text>
            </Pressable>
          </View>
        </View>

        <View style={styles.timeRow}>
          <View style={styles.dateItem}>
            <Text style={styles.dateLabel}>Heure de début</Text>
            <Pressable style={styles.dateButton} onPress={openStartTimePicker}>
              <IconSymbol name="clock" color={colors.primary} size={20} />
              <Text style={[styles.dateText, !startTime && styles.placeholderText]}>
                {startTime ? format(startTime, 'HH:mm') : 'Sélectionner'}
              </Text>
            </Pressable>
          </View>
          
          <View style={styles.dateItem}>
            <Text style={styles.dateLabel}>Heure de fin</Text>
            <Pressable style={styles.dateButton} onPress={openEndTimePicker}>
              <IconSymbol name="clock" color={colors.primary} size={20} />
              <Text style={[styles.dateText, !endTime && styles.placeholderText]}>
                {endTime ? format(endTime, 'HH:mm') : 'Sélectionner'}
              </Text>
            </Pressable>
          </View>
        </View>

        {startDate && endDate && startTime && endTime && (
          <View style={styles.continueButtonContainer}>
            <Pressable style={styles.continueButton} onPress={handleDatesConfirm}>
              <Text style={styles.continueButtonText}>Continuer</Text>
              <IconSymbol name="arrow.right.circle.fill" color={colors.card} size={20} />
            </Pressable>
          </View>
        )}
      </BlurView>
    </View>
  );

  const renderPickupStep = () => (
    <View style={styles.stepContainer}>
      <BlurView intensity={5} tint="extraLight" style={[styles.pickupContainer, Platform.OS !== 'ios' && { backgroundColor: 'rgba(255,255,255,0.05)' }]}>
        <Text style={styles.sectionTitle}>Lieu de récupération</Text>
        
        <Pressable 
          style={[styles.pickupOptionButton, pickupOption === 'pickup' && styles.selectedPickupOption]}
          onPress={() => setPickupOption('pickup')}
        >
          <IconSymbol name="location.fill" color={pickupOption === 'pickup' ? colors.card : colors.primary} size={24} />
          <Text style={[styles.pickupOptionText, pickupOption === 'pickup' && styles.selectedPickupOptionText]}>
            Récupération en agence
          </Text>
        </Pressable>

        {pickupOption === 'pickup' && (
          <View style={styles.pickupLocationsList}>
            {pickupLocations.map((location) => (
              <Pressable
                key={location.id}
                style={[styles.locationOption, selectedPickupLocation?.id === location.id && styles.selectedLocation]}
                onPress={() => setSelectedPickupLocation(location)}
              >
                <IconSymbol 
                  name={selectedPickupLocation?.id === location.id ? "checkmark.circle.fill" : "circle"} 
                  color={selectedPickupLocation?.id === location.id ? colors.primary : '#FFFFFF'} 
                  size={20} 
                />
                <Text style={[styles.locationText, selectedPickupLocation?.id === location.id && styles.selectedLocationText]}>
                  {location.name}
                </Text>
              </Pressable>
            ))}
          </View>
        )}

        <Pressable 
          style={[styles.pickupOptionButton, pickupOption === 'delivery' && styles.selectedPickupOption]}
          onPress={() => setPickupOption('delivery')}
        >
          <IconSymbol name="car.fill" color={pickupOption === 'delivery' ? colors.card : colors.primary} size={24} />
          <Text style={[styles.pickupOptionText, pickupOption === 'delivery' && styles.selectedPickupOptionText]}>
            Livraison à domicile
          </Text>
        </Pressable>

        {pickupOption === 'delivery' && (
          <View style={styles.deliverySection}>
            <Text style={styles.deliveryWarning}>
              ⚠️ Des frais de livraison de 25€ seront ajoutés
            </Text>
            <TextInput
              style={styles.addressInput}
              value={customDeliveryAddress}
              onChangeText={setCustomDeliveryAddress}
              placeholder="Entrez votre adresse de livraison"
              placeholderTextColor="#CCCCCC"
              multiline
            />
          </View>
        )}

        <View style={styles.stepButtonsContainer}>
          <Pressable style={styles.backButton} onPress={() => setCurrentStep('dates')}>
            <IconSymbol name="chevron.left" color={colors.primary} size={20} />
            <Text style={styles.backButtonText}>Retour</Text>
          </Pressable>
          
          <Pressable style={styles.continueButton} onPress={handlePickupConfirm}>
            <Text style={styles.continueButtonText}>Continuer</Text>
            <IconSymbol name="arrow.right.circle.fill" color={colors.card} size={20} />
          </Pressable>
        </View>
      </BlurView>
    </View>
  );

  const renderSummaryStep = () => (
    <ScrollView style={styles.stepContainer}>
      <BlurView intensity={5} tint="extraLight" style={[styles.summaryContainer, Platform.OS !== 'ios' && { backgroundColor: 'rgba(255,255,255,0.05)' }]}>
        <Text style={styles.sectionTitle}>Récapitulatif de votre réservation</Text>
        
        {/* Car Information */}
        <View style={styles.summarySection}>
          <Text style={styles.summarySectionTitle}>Véhicule</Text>
          <Text style={styles.summaryText}>{carInfo.name} - {carInfo.type}</Text>
        </View>

        {/* Dates and Times */}
        <View style={styles.summarySection}>
          <Text style={styles.summarySectionTitle}>Période de location</Text>
          <Text style={styles.summaryText}>
            Du {format(startDate!, 'dd MMMM yyyy', { locale: fr })} à {format(startTime!, 'HH:mm')}
          </Text>
          <Text style={styles.summaryText}>
            Au {format(endDate!, 'dd MMMM yyyy', { locale: fr })} à {format(endTime!, 'HH:mm')}
          </Text>
          <Text style={styles.summarySubText}>
            Durée: {differenceInDays(endDate!, startDate!) + 1} jour(s)
          </Text>
        </View>

        {/* Pickup Information */}
        <View style={styles.summarySection}>
          <Text style={styles.summarySectionTitle}>
            {pickupOption === 'pickup' ? 'Lieu de récupération' : 'Livraison'}
          </Text>
          <Text style={styles.summaryText}>
            {pickupOption === 'pickup' ? selectedPickupLocation?.name : customDeliveryAddress}
          </Text>
        </View>

        {/* Additional Options */}
        <View style={styles.summarySection}>
          <Text style={styles.summarySectionTitle}>Options supplémentaires</Text>
          {availableOptions.map((option) => (
            <Pressable
              key={option.id}
              style={[styles.optionItem, selectedOptions.some(opt => opt.id === option.id) && styles.selectedOptionItem]}
              onPress={() => toggleOption(option.id)}
            >
              <IconSymbol 
                name={selectedOptions.some(opt => opt.id === option.id) ? "checkmark.square.fill" : "square"} 
                color={selectedOptions.some(opt => opt.id === option.id) ? colors.primary : '#FFFFFF'} 
                size={20} 
              />
              <View style={styles.optionContent}>
                <Text style={styles.optionName}>{option.name}</Text>
                {option.description && <Text style={styles.optionDescription}>{option.description}</Text>}
              </View>
              <Text style={styles.optionPrice}>+{option.price}€</Text>
            </Pressable>
          ))}
        </View>

        {/* Price Summary */}
        <View style={styles.priceSummarySection}>
          <Text style={styles.summarySectionTitle}>Détail des prix</Text>
          <View style={styles.priceRow}>
            <Text style={styles.priceLabel}>Location de base</Text>
            <Text style={styles.priceValue}>
              {priceCalculation.price - selectedOptions.reduce((sum, opt) => sum + opt.price, 0) - (pickupOption === 'delivery' ? 25 : 0)}€
            </Text>
          </View>
          {selectedOptions.map((option) => (
            <View key={option.id} style={styles.priceRow}>
              <Text style={styles.priceLabel}>{option.name}</Text>
              <Text style={styles.priceValue}>+{option.price}€</Text>
            </View>
          ))}
          {pickupOption === 'delivery' && (
            <View style={styles.priceRow}>
              <Text style={styles.priceLabel}>Frais de livraison</Text>
              <Text style={styles.priceValue}>+25€</Text>
            </View>
          )}
          <View style={styles.totalRow}>
            <Text style={styles.totalLabel}>Total</Text>
            <Text style={styles.totalPrice}>{priceCalculation.price}€</Text>
          </View>
          <View style={styles.depositRow}>
            <Text style={styles.depositLabel}>Acompte à verser (30%)</Text>
            <Text style={styles.depositPrice}>{Math.round(priceCalculation.price * 0.3)}€</Text>
          </View>
        </View>

        <View style={styles.stepButtonsContainer}>
          <Pressable style={styles.backButton} onPress={() => setCurrentStep('pickup')}>
            <IconSymbol name="chevron.left" color={colors.primary} size={20} />
            <Text style={styles.backButtonText}>Retour</Text>
          </Pressable>
          
          <Pressable style={styles.continueButton} onPress={handleSummaryConfirm}>
            <Text style={styles.continueButtonText}>Confirmer</Text>
            <IconSymbol name="arrow.right.circle.fill" color={colors.card} size={20} />
          </Pressable>
        </View>
      </BlurView>
    </ScrollView>
  );

  const renderUserInfoStep = () => (
    <View style={styles.stepContainer}>
      <BlurView intensity={5} tint="extraLight" style={[styles.formContainer, Platform.OS !== 'ios' && { backgroundColor: 'rgba(255,255,255,0.05)' }]}>
        <Text style={styles.sectionTitle}>Vos informations</Text>
        <Text style={styles.guestInfoText}>
          En tant qu'invité, nous avons besoin de quelques informations pour finaliser votre réservation.
        </Text>
        
        <View style={styles.inputContainer}>
          <Text style={styles.inputLabel}>Prénom *</Text>
          <TextInput
            style={styles.textInput}
            value={firstName}
            onChangeText={setFirstName}
            placeholder="Entrez votre prénom"
            placeholderTextColor="#CCCCCC"
          />
        </View>

        <View style={styles.inputContainer}>
          <Text style={styles.inputLabel}>Nom *</Text>
          <TextInput
            style={styles.textInput}
            value={lastName}
            onChangeText={setLastName}
            placeholder="Entrez votre nom"
            placeholderTextColor="#CCCCCC"
          />
        </View>

        <View style={styles.inputContainer}>
          <Text style={styles.inputLabel}>Date de naissance *</Text>
          <Pressable style={styles.dateButton} onPress={() => setShowDateOfBirthPicker(true)}>
            <IconSymbol name="calendar" color={colors.primary} size={20} />
            <Text style={[styles.dateText, !dateOfBirth && styles.placeholderText]}>
              {dateOfBirth ? format(dateOfBirth, 'dd/MM/yyyy') : 'Sélectionner'}
            </Text>
          </Pressable>
        </View>

        <View style={styles.inputContainer}>
          <Text style={styles.inputLabel}>Adresse email *</Text>
          <TextInput
            style={styles.textInput}
            value={email}
            onChangeText={setEmail}
            placeholder="exemple@email.com"
            placeholderTextColor="#CCCCCC"
            keyboardType="email-address"
            autoCapitalize="none"
          />
        </View>

        <View style={styles.stepButtonsContainer}>
          <Pressable style={styles.backButton} onPress={() => setCurrentStep('summary')}>
            <IconSymbol name="chevron.left" color={colors.primary} size={20} />
            <Text style={styles.backButtonText}>Retour</Text>
          </Pressable>

          <Pressable style={styles.continueButton} onPress={handleUserInfoSubmit}>
            <Text style={styles.continueButtonText}>Continuer</Text>
            <IconSymbol name="arrow.right.circle.fill" color={colors.card} size={20} />
          </Pressable>
        </View>
      </BlurView>
    </View>
  );

  const renderPaymentStep = () => (
    <View style={styles.stepContainer}>
      <BlurView intensity={5} tint="extraLight" style={[styles.paymentContainer, Platform.OS !== 'ios' && { backgroundColor: 'rgba(255,255,255,0.05)' }]}>
        <Text style={styles.sectionTitle}>Paiement de l'acompte</Text>
        <Text style={styles.paymentSubtitle}>
          Montant à régler: {Math.round(priceCalculation.price * 0.3)}€ (30% du total)
        </Text>
        
        <View style={styles.paymentOptionsContainer}>
          <Pressable style={styles.paymentOption} onPress={() => handlePayment('credit_card')}>
            <IconSymbol name="creditcard.fill" color={colors.primary} size={24} />
            <View style={styles.paymentOptionContent}>
              <Text style={styles.paymentOptionTitle}>Payer par carte bancaire</Text>
              <Text style={styles.paymentOptionSubtitle}>Paiement sécurisé en ligne</Text>
            </View>
            <IconSymbol name="chevron.right" color={colors.primary} size={20} />
          </Pressable>

          <Pressable style={styles.paymentOption} onPress={() => handlePayment('bank_transfer')}>
            <IconSymbol name="building.columns.fill" color={colors.primary} size={24} />
            <View style={styles.paymentOptionContent}>
              <Text style={styles.paymentOptionTitle}>Paiement par virement</Text>
              <Text style={styles.paymentOptionSubtitle}>Coordonnées bancaires par email</Text>
            </View>
            <IconSymbol name="chevron.right" color={colors.primary} size={20} />
          </Pressable>

          <Pressable style={styles.paymentOption} onPress={() => handlePayment('phone_confirmation')}>
            <IconSymbol name="phone.fill" color={colors.secondary} size={24} />
            <View style={styles.paymentOptionContent}>
              <Text style={styles.paymentOptionTitle}>Confirmer par téléphone</Text>
              <Text style={styles.paymentOptionSubtitle}>Appeler le 066145612</Text>
            </View>
            <IconSymbol name="phone.circle.fill" color={colors.secondary} size={20} />
          </Pressable>
        </View>

        <Pressable style={styles.backButton} onPress={() => setCurrentStep(isGuest ? 'user-info' : 'summary')}>
          <IconSymbol name="chevron.left" color={colors.primary} size={20} />
          <Text style={styles.backButtonText}>Retour</Text>
        </Pressable>
      </BlurView>
    </View>
  );

  const renderConfirmationStep = () => (
    <View style={styles.stepContainer}>
      <BlurView intensity={5} tint="extraLight" style={[styles.confirmationContainer, Platform.OS !== 'ios' && { backgroundColor: 'rgba(255,255,255,0.05)' }]}>
        <IconSymbol name="checkmark.circle.fill" color={colors.secondary} size={80} />
        <Text style={styles.confirmationTitle}>Réservation confirmée !</Text>
        <Text style={styles.confirmationSubtitle}>
          Votre réservation a été enregistrée avec succès.
        </Text>
        
        <View style={styles.confirmationDetails}>
          <Text style={styles.confirmationLabel}>Référence de réservation:</Text>
          <Text style={styles.confirmationValue}>{bookingId?.slice(-8).toUpperCase()}</Text>
          
          <Text style={styles.confirmationLabel}>Email de confirmation:</Text>
          <Text style={styles.confirmationValue}>{email}</Text>
          
          <Text style={styles.confirmationLabel}>Montant de l'acompte:</Text>
          <Text style={styles.confirmationValue}>{Math.round(priceCalculation.price * 0.3)}€</Text>
        </View>

        <Text style={styles.confirmationNote}>
          Un email de confirmation avec tous les détails de votre réservation vous a été envoyé.
        </Text>

        <Pressable style={styles.homeButton} onPress={() => router.push('/(tabs)/(home)')}>
          <Text style={styles.homeButtonText}>Retour à l'accueil</Text>
          <IconSymbol name="house.fill" color={colors.card} size={20} />
        </Pressable>
      </BlurView>
    </View>
  );

  const renderCurrentStep = () => {
    switch (currentStep) {
      case 'auth':
        return renderAuthStep();
      case 'dates':
        return renderDatesStep();
      case 'pickup':
        return renderPickupStep();
      case 'summary':
        return renderSummaryStep();
      case 'user-info':
        return renderUserInfoStep();
      case 'payment':
        return renderPaymentStep();
      case 'confirmation':
        return renderConfirmationStep();
      default:
        return renderAuthStep();
    }
  };

  return (
    <ImageBackground 
      source={require('@/assets/images/285c86af-6344-4f73-beac-dbfa2112b685.jpeg')}
      style={styles.container}
      resizeMode="cover"
    >
      <SafeAreaView style={styles.safeArea}>
        <Stack.Screen
          options={{
            title: "Réservation",
            headerShown: true,
            headerStyle: { backgroundColor: 'transparent' },
            headerTintColor: '#FFFFFF',
            headerTitleStyle: { fontWeight: '700', fontSize: 20 },
            headerLeft: () => (
              <Pressable onPress={() => router.back()} style={styles.headerBackButton}>
                <IconSymbol name="chevron.left" color="#FFFFFF" size={24} />
              </Pressable>
            ),
            headerBackground: () => (
              <BlurView 
                intensity={10} 
                tint="dark" 
                style={[StyleSheet.absoluteFill, Platform.OS !== 'ios' && { backgroundColor: 'rgba(0,0,0,0.1)' }]} 
              />
            ),
          }}
        />
        
        <ScrollView style={styles.scrollView} contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
          {renderCurrentStep()}
        </ScrollView>

        {/* Date and Time Pickers */}
        {showStartDatePicker && (
          <DateTimePicker
            value={startDate || new Date()}
            mode="date"
            display={Platform.OS === 'ios' ? 'spinner' : 'default'}
            onChange={handleStartDateChange}
            minimumDate={new Date()}
            locale="fr-FR"
          />
        )}

        {showEndDatePicker && startDate && (
          <DateTimePicker
            value={endDate || addDays(startDate, 1)}
            mode="date"
            display={Platform.OS === 'ios' ? 'spinner' : 'default'}
            onChange={handleEndDateChange}
            minimumDate={addDays(startDate, 1)}
            locale="fr-FR"
          />
        )}

        {showStartTimePicker && (
          <DateTimePicker
            value={startTime || new Date()}
            mode="time"
            display={Platform.OS === 'ios' ? 'spinner' : 'default'}
            onChange={handleStartTimeChange}
            locale="fr-FR"
          />
        )}

        {showEndTimePicker && (
          <DateTimePicker
            value={endTime || new Date()}
            mode="time"
            display={Platform.OS === 'ios' ? 'spinner' : 'default'}
            onChange={handleEndTimeChange}
            locale="fr-FR"
          />
        )}

        {showDateOfBirthPicker && (
          <DateTimePicker
            value={dateOfBirth || new Date(2000, 0, 1)}
            mode="date"
            display={Platform.OS === 'ios' ? 'spinner' : 'default'}
            onChange={handleDateOfBirthChange}
            maximumDate={new Date()}
            locale="fr-FR"
          />
        )}

        {/* Modals */}
        <Modal visible={showDiscountModal} transparent={true} animationType="fade" onRequestClose={() => setShowDiscountModal(false)}>
          <View style={styles.modalOverlay}>
            <BlurView intensity={5} tint="extraLight" style={[styles.modalContent, Platform.OS !== 'ios' && { backgroundColor: 'rgba(255,255,255,0.05)' }]}>
              <IconSymbol name="tag.fill" color={colors.secondary} size={48} />
              <Text style={styles.modalTitle}>Remise appliquée !</Text>
              <Text style={styles.modalMessage}>{priceCalculation.discountMessage}</Text>
              <Text style={styles.modalPrice}>Prix final: {priceCalculation.price}€</Text>
              <Pressable style={styles.modalButton} onPress={() => setShowDiscountModal(false)}>
                <Text style={styles.modalButtonText}>Parfait !</Text>
              </Pressable>
            </BlurView>
          </View>
        </Modal>

        <Modal visible={showGuestWarning} transparent={true} animationType="fade" onRequestClose={() => setShowGuestWarning(false)}>
          <View style={styles.modalOverlay}>
            <BlurView intensity={5} tint="extraLight" style={[styles.modalContent, Platform.OS !== 'ios' && { backgroundColor: 'rgba(255,255,255,0.05)' }]}>
              <IconSymbol name="exclamationmark.triangle.fill" color="#FF4444" size={48} />
              <Text style={[styles.modalTitle, { color: '#FF4444' }]}>Informations requises</Text>
              <Text style={styles.modalMessage}>
                En tant qu'invité, vous devez soit créer un compte soit entrer vos informations personnelles (nom, prénom, date de naissance et adresse email) pour confirmer la réservation.
              </Text>
              <View style={styles.guestWarningButtons}>
                <Pressable style={styles.createAccountButton} onPress={() => { setShowGuestWarning(false); router.push('/signup'); }}>
                  <Text style={styles.createAccountButtonText}>Créer un compte</Text>
                </Pressable>
                <Pressable style={styles.continueGuestButton} onPress={handleGuestWarningOk}>
                  <Text style={styles.continueGuestButtonText}>Entrer mes informations</Text>
                </Pressable>
              </View>
            </BlurView>
          </View>
        </Modal>
      </SafeAreaView>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: 20,
  },
  headerBackButton: {
    padding: 8,
    marginLeft: -8,
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
    borderRadius: 20,
  },
  stepContainer: {
    flex: 1,
    justifyContent: 'center',
    paddingHorizontal: 20,
    paddingVertical: 20,
  },
  
  // Auth Step Styles
  authCard: {
    borderRadius: 20,
    padding: 32,
    alignItems: 'center',
    width: '100%',
    maxWidth: 400,
    alignSelf: 'center',
    boxShadow: '0px 8px 24px rgba(0, 0, 0, 0.3)',
    elevation: 12,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
    overflow: 'hidden',
  },
  authTitle: {
    fontSize: 24,
    fontWeight: '800',
    color: '#FFFFFF',
    textAlign: 'center',
    marginTop: 16,
    marginBottom: 8,
  },
  authSubtitle: {
    fontSize: 16,
    color: '#FFFFFF',
    textAlign: 'center',
    lineHeight: 22,
    marginBottom: 32,
  },
  loginButton: {
    backgroundColor: colors.primary,
    paddingVertical: 16,
    paddingHorizontal: 32,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
    marginBottom: 16,
  },
  loginButtonText: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.card,
    marginLeft: 8,
  },
  guestButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    paddingVertical: 16,
    paddingHorizontal: 32,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: 'rgba(255, 255, 255, 0.15)',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
  },
  guestButtonText: {
    fontSize: 16,
    fontWeight: '700',
    color: '#FFFFFF',
    marginLeft: 8,
  },

  // Date Step Styles
  datePickerContainer: {
    borderRadius: 16,
    padding: 24,
    boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.3)',
    elevation: 8,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
    overflow: 'hidden',
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#FFFFFF',
    marginBottom: 20,
    textAlign: 'center',
  },
  dateRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 16,
    marginBottom: 20,
  },
  timeRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 16,
  },
  dateItem: {
    flex: 1,
  },
  dateLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#FFFFFF',
    marginBottom: 8,
  },
  dateButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    borderWidth: 2,
    borderColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  disabledButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderColor: 'rgba(255, 255, 255, 0.1)',
  },
  dateText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
    marginLeft: 8,
  },
  placeholderText: {
    color: '#CCCCCC',
    fontStyle: 'italic',
  },
  disabledText: {
    color: '#CCCCCC',
    opacity: 0.5,
  },
  continueButtonContainer: {
    marginTop: 24,
    alignItems: 'center',
  },
  continueButton: {
    backgroundColor: colors.primary,
    paddingVertical: 16,
    paddingHorizontal: 32,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    minWidth: 200,
    boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.2)',
    elevation: 6,
  },
  continueButtonText: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.card,
    marginRight: 8,
  },

  // Pickup Step Styles
  pickupContainer: {
    borderRadius: 16,
    padding: 24,
    boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.3)',
    elevation: 8,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
    overflow: 'hidden',
  },
  pickupOptionButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    borderWidth: 2,
    borderColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  selectedPickupOption: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },
  pickupOptionText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
    marginLeft: 12,
  },
  selectedPickupOptionText: {
    color: colors.card,
  },
  pickupLocationsList: {
    marginBottom: 16,
  },
  locationOption: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.15)',
    borderRadius: 8,
    padding: 12,
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  selectedLocation: {
    backgroundColor: 'rgba(33, 150, 243, 0.2)',
    borderColor: colors.primary,
  },
  locationText: {
    fontSize: 14,
    color: '#FFFFFF',
    marginLeft: 12,
    flex: 1,
  },
  selectedLocationText: {
    fontWeight: '600',
    color: '#FFFFFF',
  },
  deliverySection: {
    marginBottom: 16,
  },
  deliveryWarning: {
    fontSize: 14,
    color: '#FFFFFF',
    backgroundColor: 'rgba(255, 183, 77, 0.1)',
    padding: 12,
    borderRadius: 8,
    marginBottom: 12,
    textAlign: 'center',
  },
  addressInput: {
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    borderWidth: 2,
    borderColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 12,
    padding: 16,
    fontSize: 16,
    color: '#FFFFFF',
    minHeight: 80,
    textAlignVertical: 'top',
  },

  // Summary Step Styles
  summaryContainer: {
    borderRadius: 16,
    padding: 24,
    boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.3)',
    elevation: 8,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
    overflow: 'hidden',
  },
  summarySection: {
    marginBottom: 20,
    padding: 16,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
  },
  summarySectionTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#FFFFFF',
    marginBottom: 8,
  },
  summaryText: {
    fontSize: 14,
    color: '#FFFFFF',
    marginBottom: 4,
  },
  summarySubText: {
    fontSize: 12,
    color: '#CCCCCC',
    fontStyle: 'italic',
  },
  optionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 8,
    marginBottom: 8,
  },
  selectedOptionItem: {
    backgroundColor: 'rgba(33, 150, 243, 0.2)',
  },
  optionContent: {
    flex: 1,
    marginLeft: 12,
  },
  optionName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  optionDescription: {
    fontSize: 12,
    color: '#CCCCCC',
  },
  optionPrice: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.primary,
  },
  priceSummarySection: {
    marginBottom: 20,
    padding: 16,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
  },
  priceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  priceLabel: {
    fontSize: 14,
    color: '#FFFFFF',
  },
  priceValue: {
    fontSize: 14,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  totalRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderTopWidth: 2,
    borderTopColor: 'rgba(255, 255, 255, 0.2)',
    paddingTop: 12,
    marginTop: 12,
  },
  totalLabel: {
    fontSize: 16,
    fontWeight: '700',
    color: '#FFFFFF',
  },
  totalPrice: {
    fontSize: 20,
    fontWeight: '800',
    color: colors.primary,
  },
  depositRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 8,
  },
  depositLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.secondary,
  },
  depositPrice: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.secondary,
  },

  // User Info Step Styles
  formContainer: {
    borderRadius: 16,
    padding: 24,
    boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.3)',
    elevation: 8,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
    overflow: 'hidden',
  },
  guestInfoText: {
    fontSize: 14,
    color: '#FFFFFF',
    textAlign: 'center',
    marginBottom: 20,
    lineHeight: 20,
  },
  inputContainer: {
    marginBottom: 20,
  },
  inputLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
    marginBottom: 8,
  },
  textInput: {
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    borderWidth: 2,
    borderColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 12,
    padding: 16,
    fontSize: 16,
    color: '#FFFFFF',
    fontWeight: '500',
  },

  // Payment Step Styles
  paymentContainer: {
    borderRadius: 16,
    padding: 24,
    boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.3)',
    elevation: 8,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
    overflow: 'hidden',
  },
  paymentSubtitle: {
    fontSize: 16,
    color: colors.primary,
    textAlign: 'center',
    fontWeight: '600',
    marginBottom: 24,
  },
  paymentOptionsContainer: {
    marginBottom: 24,
  },
  paymentOption: {
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    borderWidth: 2,
    borderColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 12,
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  paymentOptionContent: {
    flex: 1,
    marginLeft: 16,
  },
  paymentOptionTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  paymentOptionSubtitle: {
    fontSize: 14,
    color: '#FFFFFF',
  },

  // Confirmation Step Styles
  confirmationContainer: {
    borderRadius: 16,
    padding: 32,
    alignItems: 'center',
    boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.3)',
    elevation: 8,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
    overflow: 'hidden',
  },
  confirmationTitle: {
    fontSize: 24,
    fontWeight: '800',
    color: '#FFFFFF',
    textAlign: 'center',
    marginTop: 16,
    marginBottom: 8,
  },
  confirmationSubtitle: {
    fontSize: 16,
    color: '#FFFFFF',
    textAlign: 'center',
    marginBottom: 24,
  },
  confirmationDetails: {
    width: '100%',
    marginBottom: 24,
  },
  confirmationLabel: {
    fontSize: 14,
    color: '#CCCCCC',
    marginBottom: 4,
  },
  confirmationValue: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
    marginBottom: 16,
  },
  confirmationNote: {
    fontSize: 14,
    color: '#FFFFFF',
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: 24,
  },
  homeButton: {
    backgroundColor: colors.primary,
    paddingVertical: 16,
    paddingHorizontal: 32,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  homeButtonText: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.card,
    marginRight: 8,
  },

  // Common Button Styles
  stepButtonsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 24,
    gap: 16,
  },
  backButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: 'rgba(255, 255, 255, 0.15)',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
  },
  backButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
    marginLeft: 8,
  },

  // Modal Styles
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  modalContent: {
    borderRadius: 20,
    padding: 32,
    alignItems: 'center',
    width: '100%',
    maxWidth: 350,
    boxShadow: '0px 8px 24px rgba(0, 0, 0, 0.3)',
    elevation: 12,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
    overflow: 'hidden',
  },
  modalTitle: {
    fontSize: 22,
    fontWeight: '800',
    color: '#FFFFFF',
    textAlign: 'center',
    marginTop: 16,
    marginBottom: 8,
  },
  modalMessage: {
    fontSize: 16,
    color: '#FFFFFF',
    textAlign: 'center',
    lineHeight: 22,
    marginBottom: 16,
  },
  modalPrice: {
    fontSize: 20,
    fontWeight: '700',
    color: colors.primary,
    textAlign: 'center',
    marginBottom: 24,
  },
  modalButton: {
    backgroundColor: colors.primary,
    paddingVertical: 14,
    paddingHorizontal: 32,
    borderRadius: 12,
    width: '100%',
  },
  modalButtonText: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.card,
    textAlign: 'center',
  },
  guestWarningButtons: {
    flexDirection: 'column',
    width: '100%',
    gap: 12,
  },
  createAccountButton: {
    backgroundColor: colors.primary,
    paddingVertical: 14,
    paddingHorizontal: 32,
    borderRadius: 12,
  },
  createAccountButtonText: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.card,
    textAlign: 'center',
  },
  continueGuestButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    paddingVertical: 14,
    paddingHorizontal: 32,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: 'rgba(255, 255, 255, 0.15)',
  },
  continueGuestButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
    textAlign: 'center',
  },
});
