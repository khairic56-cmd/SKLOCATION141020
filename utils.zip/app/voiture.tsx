
import React, { useState, useEffect } from "react";
import { 
  ScrollView, 
  StyleSheet, 
  View, 
  Text, 
  Image, 
  Pressable,
  Platform,
  Dimensions,
  FlatList,
  ImageBackground,
  ActivityIndicator
} from "react-native";
import { Stack, router } from "expo-router";
import { IconSymbol } from "@/components/IconSymbol";
import { colors } from "@/styles/commonStyles";
import { SafeAreaView } from "react-native-safe-area-context";
import { BlurView } from 'expo-blur';
import { Calendar } from 'react-native-calendars';
import { format, addDays, parseISO } from 'date-fns';
import { supabase } from '@/app/integrations/supabase/client';
import type { Tables } from '@/app/integrations/supabase/types';

const { width } = Dimensions.get('window');

interface Car {
  id: string;
  name: string;
  brand: string;
  price: string;
  images: string[];
  type: string;
  transmission: string;
  fuel: string;
  seats: number;
}

const cars: Car[] = [
  {
    id: 'car-1',
    name: 'Cayenne S',
    brand: 'Porsche',
    price: '350€/jour',
    images: [
      require('@/assets/images/90cb31da-bdcd-4fe4-9d01-7a58cea652ad.jpeg'),
      require('@/assets/images/52f02172-45c1-4f21-8752-b4735d6cda5c.jpeg'),
      require('@/assets/images/ca1cbb8c-94b0-4214-9ef9-b12f1ee7456a.jpeg'),
      require('@/assets/images/6ffafd1d-a2b5-4ad9-b566-b7137772eeb4.jpeg'),
    ],
    type: 'SUV Sport',
    transmission: 'Automatique',
    fuel: 'Essence',
    seats: 5,
  },
];

export default function VoitureScreen() {
  console.log('VoitureScreen rendered');
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [showCalendar, setShowCalendar] = useState(false);
  const [bookings, setBookings] = useState<Tables<'bookings'>[]>([]);
  const [loadingBookings, setLoadingBookings] = useState(true);

  useEffect(() => {
    loadBookings();
  }, []);

  const loadBookings = async () => {
    try {
      setLoadingBookings(true);
      console.log('Loading bookings from database...');
      
      // Fetch all confirmed bookings for this car
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('car_id', 'car-1')
        .in('booking_status', ['confirmed', 'pending'])
        .order('start_date', { ascending: true });

      if (error) {
        console.error('Error loading bookings:', error);
        throw error;
      }

      console.log('Loaded bookings:', data);
      setBookings(data || []);
    } catch (error) {
      console.error('Error loading bookings:', error);
    } finally {
      setLoadingBookings(false);
    }
  };

  const handleReservation = (carId: string) => {
    console.log('Navigating to booking page for car:', carId);
    router.push('/booking');
  };

  const renderImageItem = ({ item, index }: { item: any; index: number }) => (
    <View style={styles.imageContainer}>
      <Image source={item} style={styles.carImage} />
    </View>
  );

  const onImageScroll = (event: any) => {
    const slideSize = width - 40;
    const index = Math.round(event.nativeEvent.contentOffset.x / slideSize);
    setCurrentImageIndex(index);
  };

  const getMarkedDates = () => {
    const markedDates: any = {};
    
    bookings.forEach(booking => {
      try {
        const startDate = parseISO(booking.start_date);
        const endDate = parseISO(booking.end_date);
        
        // Mark all dates in the booking period
        let currentDate = new Date(startDate);
        while (currentDate <= endDate) {
          const dateString = format(currentDate, 'yyyy-MM-dd');
          markedDates[dateString] = {
            color: '#FF6B6B',
            textColor: 'white',
            startingDay: currentDate.getTime() === startDate.getTime(),
            endingDay: currentDate.getTime() === endDate.getTime(),
          };
          currentDate = addDays(currentDate, 1);
        }
      } catch (error) {
        console.error('Error parsing booking dates:', error);
      }
    });

    return markedDates;
  };

  const renderAvailabilityCalendar = () => (
    <BlurView 
      intensity={5} 
      tint="extraLight" 
      style={[
        styles.calendarContainer,
        Platform.OS !== 'ios' && { backgroundColor: 'rgba(255,255,255,0.05)' }
      ]}
    >
      <View style={styles.calendarHeader}>
        <Text style={styles.calendarTitle}>Disponibilités</Text>
        <Pressable 
          style={styles.toggleButton}
          onPress={() => setShowCalendar(!showCalendar)}
        >
          <IconSymbol 
            name={showCalendar ? "chevron.up" : "chevron.down"} 
            color="#2196F3" 
            size={20} 
          />
        </Pressable>
      </View>
      
      {showCalendar && (
        <View style={styles.calendarWrapper}>
          {loadingBookings ? (
            <View style={styles.loadingContainer}>
              <ActivityIndicator size="large" color="#2196F3" />
              <Text style={styles.loadingText}>Chargement des réservations...</Text>
            </View>
          ) : (
            <>
              <Calendar
                markedDates={getMarkedDates()}
                markingType="period"
                theme={{
                  backgroundColor: 'transparent',
                  calendarBackground: 'transparent',
                  textSectionTitleColor: '#FFFFFF',
                  selectedDayBackgroundColor: '#2196F3',
                  selectedDayTextColor: '#FFFFFF',
                  todayTextColor: '#2196F3',
                  dayTextColor: '#FFFFFF',
                  textDisabledColor: '#BDBDBD',
                  dotColor: '#2196F3',
                  selectedDotColor: '#FFFFFF',
                  arrowColor: '#FFFFFF',
                  monthTextColor: '#FFFFFF',
                  indicatorColor: '#2196F3',
                  textDayFontWeight: '500',
                  textMonthFontWeight: '700',
                  textDayHeaderFontWeight: '600',
                  textDayFontSize: 16,
                  textMonthFontSize: 18,
                  textDayHeaderFontSize: 14,
                }}
                firstDay={1}
                hideExtraDays={true}
                disableMonthChange={false}
                hideDayNames={false}
                showWeekNumbers={false}
                onPressArrowLeft={subtractMonth => subtractMonth()}
                onPressArrowRight={addMonth => addMonth()}
              />
              
              <View style={styles.legendContainer}>
                <View style={styles.legendItem}>
                  <View style={[styles.legendColor, { backgroundColor: '#FF6B6B' }]} />
                  <Text style={styles.legendText}>Réservé</Text>
                </View>
                <View style={styles.legendItem}>
                  <View style={[styles.legendColor, { backgroundColor: 'transparent', borderWidth: 1, borderColor: '#FFFFFF' }]} />
                  <Text style={styles.legendText}>Disponible</Text>
                </View>
              </View>
              
              {bookings.length > 0 && (
                <View style={styles.bookingsInfo}>
                  <Text style={styles.bookingsInfoText}>
                    {bookings.length} réservation{bookings.length > 1 ? 's' : ''} en cours
                  </Text>
                </View>
              )}
            </>
          )}
        </View>
      )}
    </BlurView>
  );

  const renderCarCard = (car: Car) => (
    <View key={car.id} style={styles.carCard}>
      <View style={styles.imageSection}>
        <FlatList
          data={car.images}
          renderItem={renderImageItem}
          horizontal
          pagingEnabled
          showsHorizontalScrollIndicator={false}
          onMomentumScrollEnd={onImageScroll}
          snapToInterval={width - 40}
          decelerationRate="fast"
          contentContainerStyle={styles.imageList}
        />
        
        {/* Image indicators */}
        <View style={styles.imageIndicators}>
          {car.images.map((_, index) => (
            <View
              key={index}
              style={[
                styles.indicator,
                index === currentImageIndex && styles.activeIndicator
              ]}
            />
          ))}
        </View>
      </View>
      
      {/* Calendrier de disponibilité placé juste après la photo */}
      {renderAvailabilityCalendar()}
      
      <BlurView 
        intensity={5} 
        tint="extraLight" 
        style={[
          styles.carInfo,
          Platform.OS !== 'ios' && { backgroundColor: 'rgba(255,255,255,0.05)' }
        ]}
      >
        <View style={styles.carHeader}>
          <Text style={styles.carName}>{car.name}</Text>
          <Text style={styles.carPrice}>{car.price}</Text>
        </View>
        <Text style={styles.carBrand}>{car.brand}</Text>
        
        <View style={styles.carDetails}>
          <View style={styles.detailItem}>
            <IconSymbol name="car.fill" color="#2196F3" size={16} />
            <Text style={styles.detailText}>{car.type}</Text>
          </View>
          <View style={styles.detailItem}>
            <IconSymbol name="gear" color="#2196F3" size={16} />
            <Text style={styles.detailText}>{car.transmission}</Text>
          </View>
          <View style={styles.detailItem}>
            <IconSymbol name="fuelpump.fill" color="#2196F3" size={16} />
            <Text style={styles.detailText}>{car.fuel}</Text>
          </View>
          <View style={styles.detailItem}>
            <IconSymbol name="person.2.fill" color="#2196F3" size={16} />
            <Text style={styles.detailText}>{car.seats} places</Text>
          </View>
        </View>
        
        <Pressable 
          style={styles.reserveButton}
          onPress={() => handleReservation(car.id)}
        >
          <Text style={styles.reserveButtonText}>Réserver</Text>
          <IconSymbol name="arrow.right" color="#FFFFFF" size={16} />
        </Pressable>
      </BlurView>
    </View>
  );

  return (
    <ImageBackground 
      source={require('@/assets/images/285c86af-6344-4f73-beac-dbfa2112b685.jpeg')}
      style={styles.container}
      resizeMode="cover"
    >
      <SafeAreaView style={styles.safeArea}>
        <Stack.Screen
          options={{
            title: "Nos Voitures",
            headerShown: true,
            headerStyle: {
              backgroundColor: 'transparent',
            },
            headerTintColor: '#FFFFFF',
            headerTitleStyle: {
              fontWeight: '700',
              fontSize: 20,
            },
            headerLeft: () => (
              <Pressable
                onPress={() => router.back()}
                style={styles.backButton}
              >
                <IconSymbol name="chevron.left" color="#FFFFFF" size={24} />
              </Pressable>
            ),
            headerBackground: () => (
              <BlurView 
                intensity={10} 
                tint="dark" 
                style={[
                  StyleSheet.absoluteFill,
                  Platform.OS !== 'ios' && { backgroundColor: 'rgba(0,0,0,0.1)' }
                ]} 
              />
            ),
          }}
        />
        
        <ScrollView 
          style={styles.scrollView}
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
        >
          <BlurView 
            intensity={8} 
            tint="extraLight" 
            style={[
              styles.header,
              Platform.OS !== 'ios' && { backgroundColor: 'rgba(255,255,255,0.03)' }
            ]}
          >
            <Text style={styles.title}>Choisissez votre véhicule</Text>
            <Text style={styles.subtitle}>
              Découvrez notre sélection de voitures premium
            </Text>
          </BlurView>
          
          <View style={styles.carsContainer}>
            {cars.map(renderCarCard)}
          </View>
        </ScrollView>
      </SafeAreaView>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: 20,
  },
  backButton: {
    padding: 8,
    marginLeft: -8,
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
    borderRadius: 20,
  },
  header: {
    marginHorizontal: 20,
    marginTop: 20,
    paddingHorizontal: 20,
    paddingVertical: 24,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
    overflow: 'hidden',
  },
  title: {
    fontSize: 28,
    fontWeight: '800',
    color: '#FFFFFF',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: '#E3F2FD',
    lineHeight: 22,
  },
  calendarContainer: {
    marginHorizontal: 20,
    marginTop: 20,
    borderRadius: 16,
    padding: 20,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
    overflow: 'hidden',
    boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.3)',
    elevation: 8,
  },
  calendarHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  calendarTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#FFFFFF',
  },
  toggleButton: {
    padding: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 8,
  },
  calendarWrapper: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
  },
  loadingContainer: {
    paddingVertical: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  loadingText: {
    fontSize: 14,
    color: '#FFFFFF',
    marginTop: 12,
  },
  legendContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 16,
    gap: 20,
  },
  legendItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  legendColor: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 8,
  },
  legendText: {
    fontSize: 14,
    color: '#FFFFFF',
    fontWeight: '500',
  },
  bookingsInfo: {
    marginTop: 12,
    padding: 12,
    backgroundColor: 'rgba(33, 150, 243, 0.2)',
    borderRadius: 8,
    alignItems: 'center',
  },
  bookingsInfoText: {
    fontSize: 14,
    color: '#FFFFFF',
    fontWeight: '600',
  },
  carsContainer: {
    paddingHorizontal: 20,
    paddingTop: 20,
  },
  carCard: {
    borderRadius: 16,
    marginBottom: 20,
    boxShadow: '0px 8px 24px rgba(0, 0, 0, 0.3)',
    elevation: 12,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
  },
  imageSection: {
    position: 'relative',
  },
  imageList: {
    paddingHorizontal: 0,
  },
  imageContainer: {
    width: width - 40,
  },
  carImage: {
    width: '100%',
    height: 250,
    resizeMode: 'cover',
  },
  imageIndicators: {
    position: 'absolute',
    bottom: 16,
    left: 0,
    right: 0,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  indicator: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(255, 255, 255, 0.5)',
    marginHorizontal: 4,
  },
  activeIndicator: {
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    width: 12,
    height: 8,
    borderRadius: 4,
  },
  carInfo: {
    padding: 20,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
    overflow: 'hidden',
  },
  carHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 4,
  },
  carName: {
    fontSize: 20,
    fontWeight: '700',
    color: '#FFFFFF',
    flex: 1,
  },
  carPrice: {
    fontSize: 18,
    fontWeight: '800',
    color: '#2196F3',
  },
  carBrand: {
    fontSize: 14,
    color: '#E3F2FD',
    marginBottom: 16,
  },
  carDetails: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: 20,
  },
  detailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 16,
    marginBottom: 8,
    minWidth: '45%',
  },
  detailText: {
    fontSize: 14,
    color: '#FFFFFF',
    marginLeft: 6,
  },
  reserveButton: {
    backgroundColor: '#2196F3',
    paddingVertical: 14,
    paddingHorizontal: 24,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  reserveButtonText: {
    fontSize: 16,
    fontWeight: '700',
    color: '#FFFFFF',
    marginRight: 8,
  },
});
