
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  SafeAreaView,
  Platform,
  Alert,
  ScrollView,
  ImageBackground,
  Modal,
} from 'react-native';
import { Stack, router, useLocalSearchParams } from 'expo-router';
import { IconSymbol } from '@/components/IconSymbol';
import { colors } from '@/styles/commonStyles';
import { BlurView } from 'expo-blur';
import { supabase } from '@/app/integrations/supabase/client';
import type { Tables } from '@/app/integrations/supabase/types';
import { differenceInDays, format } from 'date-fns';
import { fr } from 'date-fns/locale';

interface BookingOption {
  id: string;
  name: string;
  description: string | null;
  price: number;
  category: string;
  selected?: boolean;
}

export default function BookingSummaryScreen() {
  const params = useLocalSearchParams();
  const [availableOptions, setAvailableOptions] = useState<BookingOption[]>([]);
  const [selectedOptions, setSelectedOptions] = useState<BookingOption[]>([]);
  const [showGuestWarning, setShowGuestWarning] = useState(false);
  const [loading, setLoading] = useState(true);

  // Extract booking data from params
  const startDate = new Date(params.startDate as string);
  const endDate = new Date(params.endDate as string);
  const startTime = params.startTime as string;
  const endTime = params.endTime as string;
  const pickupOption = params.pickupOption as 'pickup' | 'delivery';
  const pickupLocation = params.pickupLocation as string;
  const deliveryAddress = params.deliveryAddress as string;
  const deliveryFee = parseInt(params.deliveryFee as string) || 0;
  const isGuest = params.isGuest === 'true';

  // Car information (would normally come from navigation params)
  const carInfo = {
    id: 'car-1',
    name: 'Peugeot 208',
    brand: 'Peugeot',
    type: 'Citadine'
  };

  useEffect(() => {
    loadBookingOptions();
  }, []);

  const loadBookingOptions = async () => {
    try {
      const { data, error } = await supabase
        .from('booking_options')
        .select('*')
        .eq('is_active', true)
        .order('category, name');
      
      if (error) throw error;
      setAvailableOptions((data || []).map(option => ({ ...option, selected: false })));
    } catch (error) {
      console.error('Error loading booking options:', error);
      Alert.alert('Erreur', 'Impossible de charger les options disponibles');
    } finally {
      setLoading(false);
    }
  };

  const calculatePrice = () => {
    const duration = differenceInDays(endDate, startDate) + 1;
    let basePrice = 0;

    // Calculate base price based on duration
    switch (duration) {
      case 2:
        basePrice = 600;
        break;
      case 3:
        basePrice = 780;
        break;
      case 4:
        basePrice = 1000;
        break;
      case 5:
        basePrice = 1200;
        break;
      default:
        basePrice = duration * 350;
        break;
    }

    // Add options price
    const optionsPrice = selectedOptions.reduce((total, option) => total + option.price, 0);
    
    // Add delivery fee
    const totalPrice = basePrice + optionsPrice + deliveryFee;

    return {
      basePrice,
      optionsPrice,
      deliveryFee,
      totalPrice,
      depositAmount: Math.round(totalPrice * 0.3)
    };
  };

  const toggleOption = (optionId: string) => {
    const option = availableOptions.find(opt => opt.id === optionId);
    if (!option) return;

    const isSelected = selectedOptions.some(opt => opt.id === optionId);
    
    if (isSelected) {
      setSelectedOptions(prev => prev.filter(opt => opt.id !== optionId));
    } else {
      setSelectedOptions(prev => [...prev, option]);
    }
  };

  const handleConfirm = () => {
    if (isGuest) {
      setShowGuestWarning(true);
    } else {
      navigateToPayment();
    }
  };

  const handleGuestWarningOk = () => {
    setShowGuestWarning(false);
    navigateToUserInfo();
  };

  const navigateToUserInfo = () => {
    const priceData = calculatePrice();
    router.push({
      pathname: '/user-info',
      params: {
        ...params,
        selectedOptions: JSON.stringify(selectedOptions),
        ...priceData,
      },
    });
  };

  const navigateToPayment = () => {
    const priceData = calculatePrice();
    router.push({
      pathname: '/payment',
      params: {
        ...params,
        selectedOptions: JSON.stringify(selectedOptions),
        ...priceData,
      },
    });
  };

  const priceData = calculatePrice();

  if (loading) {
    return (
      <ImageBackground 
        source={require('@/assets/images/285c86af-6344-4f73-beac-dbfa2112b685.jpeg')}
        style={styles.container}
        resizeMode="cover"
      >
        <SafeAreaView style={styles.safeArea}>
          <View style={styles.loadingContainer}>
            <Text style={styles.loadingText}>Chargement...</Text>
          </View>
        </SafeAreaView>
      </ImageBackground>
    );
  }

  return (
    <ImageBackground 
      source={require('@/assets/images/285c86af-6344-4f73-beac-dbfa2112b685.jpeg')}
      style={styles.container}
      resizeMode="cover"
    >
      <SafeAreaView style={styles.safeArea}>
        <Stack.Screen
          options={{
            title: "Récapitulatif",
            headerShown: true,
            headerStyle: { backgroundColor: 'transparent' },
            headerTintColor: '#FFFFFF',
            headerTitleStyle: { fontWeight: '700', fontSize: 20 },
            headerLeft: () => (
              <Pressable onPress={() => router.back()} style={styles.headerBackButton}>
                <IconSymbol name="chevron.left" color="#FFFFFF" size={24} />
              </Pressable>
            ),
            headerBackground: () => (
              <BlurView 
                intensity={10} 
                tint="dark" 
                style={[StyleSheet.absoluteFill, Platform.OS !== 'ios' && { backgroundColor: 'rgba(0,0,0,0.1)' }]} 
              />
            ),
          }}
        />
        
        <ScrollView style={styles.scrollView} contentContainerStyle={styles.scrollContent}>
          <BlurView intensity={5} tint="extraLight" style={[styles.summaryContainer, Platform.OS !== 'ios' && { backgroundColor: 'rgba(255,255,255,0.05)' }]}>
            <Text style={styles.sectionTitle}>Récapitulatif de votre réservation</Text>
            
            {/* Car Information */}
            <View style={styles.summarySection}>
              <Text style={styles.summarySectionTitle}>Véhicule</Text>
              <Text style={styles.summaryText}>{carInfo.name} - {carInfo.type}</Text>
            </View>

            {/* Dates and Times */}
            <View style={styles.summarySection}>
              <Text style={styles.summarySectionTitle}>Période de location</Text>
              <Text style={styles.summaryText}>
                Du {format(startDate, 'dd MMMM yyyy', { locale: fr })} à {startTime}
              </Text>
              <Text style={styles.summaryText}>
                Au {format(endDate, 'dd MMMM yyyy', { locale: fr })} à {endTime}
              </Text>
              <Text style={styles.summarySubText}>
                Durée: {differenceInDays(endDate, startDate) + 1} jour(s)
              </Text>
            </View>

            {/* Pickup Information */}
            <View style={styles.summarySection}>
              <Text style={styles.summarySectionTitle}>
                {pickupOption === 'pickup' ? 'Lieu de récupération' : 'Livraison'}
              </Text>
              <Text style={styles.summaryText}>
                {pickupOption === 'pickup' ? pickupLocation : deliveryAddress}
              </Text>
              {pickupOption === 'delivery' && (
                <Text style={styles.deliveryFeeText}>
                  Frais de livraison: +{deliveryFee}€
                </Text>
              )}
            </View>

            {/* Additional Options */}
            <View style={styles.summarySection}>
              <Text style={styles.summarySectionTitle}>Options supplémentaires</Text>
              <Text style={styles.optionsSubtitle}>
                Sélectionnez les options que vous souhaitez ajouter à votre réservation :
              </Text>
              
              {availableOptions.map((option) => (
                <Pressable
                  key={option.id}
                  style={[styles.optionItem, selectedOptions.some(opt => opt.id === option.id) && styles.selectedOptionItem]}
                  onPress={() => toggleOption(option.id)}
                >
                  <IconSymbol 
                    name={selectedOptions.some(opt => opt.id === option.id) ? "checkmark.square.fill" : "square"} 
                    color={selectedOptions.some(opt => opt.id === option.id) ? colors.primary : '#FFFFFF'} 
                    size={20} 
                  />
                  <View style={styles.optionContent}>
                    <Text style={styles.optionName}>{option.name}</Text>
                    {option.description && <Text style={styles.optionDescription}>{option.description}</Text>}
                  </View>
                  <Text style={styles.optionPrice}>+{option.price}€</Text>
                </Pressable>
              ))}
            </View>

            {/* Price Summary */}
            <View style={styles.priceSummarySection}>
              <Text style={styles.summarySectionTitle}>Détail des prix</Text>
              
              <View style={styles.priceRow}>
                <Text style={styles.priceLabel}>Location de base</Text>
                <Text style={styles.priceValue}>{priceData.basePrice}€</Text>
              </View>
              
              {selectedOptions.map((option) => (
                <View key={option.id} style={styles.priceRow}>
                  <Text style={styles.priceLabel}>{option.name}</Text>
                  <Text style={styles.priceValue}>+{option.price}€</Text>
                </View>
              ))}
              
              {deliveryFee > 0 && (
                <View style={styles.priceRow}>
                  <Text style={styles.priceLabel}>Frais de livraison</Text>
                  <Text style={styles.priceValue}>+{deliveryFee}€</Text>
                </View>
              )}
              
              <View style={styles.totalRow}>
                <Text style={styles.totalLabel}>Total</Text>
                <Text style={styles.totalPrice}>{priceData.totalPrice}€</Text>
              </View>
              
              <View style={styles.depositRow}>
                <Text style={styles.depositLabel}>Acompte à verser (30%)</Text>
                <Text style={styles.depositPrice}>{priceData.depositAmount}€</Text>
              </View>
            </View>

            <View style={styles.buttonContainer}>
              <Pressable style={styles.backButton} onPress={() => router.back()}>
                <IconSymbol name="chevron.left" color={colors.primary} size={20} />
                <Text style={styles.backButtonText}>Retour</Text>
              </Pressable>
              
              <Pressable style={styles.continueButton} onPress={handleConfirm}>
                <Text style={styles.continueButtonText}>Confirmer</Text>
                <IconSymbol name="arrow.right.circle.fill" color={colors.card} size={20} />
              </Pressable>
            </View>
          </BlurView>
        </ScrollView>

        {/* Guest Warning Modal */}
        <Modal visible={showGuestWarning} transparent={true} animationType="fade" onRequestClose={() => setShowGuestWarning(false)}>
          <View style={styles.modalOverlay}>
            <BlurView intensity={5} tint="extraLight" style={[styles.modalContent, Platform.OS !== 'ios' && { backgroundColor: 'rgba(255,255,255,0.05)' }]}>
              <IconSymbol name="exclamationmark.triangle.fill" color="#FF4444" size={48} />
              <Text style={[styles.modalTitle, { color: '#FF4444' }]}>Informations requises</Text>
              <Text style={styles.modalMessage}>
                En tant qu'invité, vous devez soit créer un compte soit entrer vos informations personnelles (nom, prénom, date de naissance et adresse email) pour confirmer la réservation.
              </Text>
              <View style={styles.guestWarningButtons}>
                <Pressable style={styles.createAccountButton} onPress={() => { setShowGuestWarning(false); router.push('/signup'); }}>
                  <Text style={styles.createAccountButtonText}>Créer un compte</Text>
                </Pressable>
                <Pressable style={styles.continueGuestButton} onPress={handleGuestWarningOk}>
                  <Text style={styles.continueGuestButtonText}>Entrer mes informations</Text>
                </Pressable>
              </View>
            </BlurView>
          </View>
        </Modal>
      </SafeAreaView>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
  },
  headerBackButton: {
    padding: 8,
    marginLeft: -8,
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
    borderRadius: 20,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    fontSize: 18,
    color: '#FFFFFF',
    fontWeight: '600',
  },
  summaryContainer: {
    borderRadius: 16,
    padding: 24,
    boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.3)',
    elevation: 8,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
    overflow: 'hidden',
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#FFFFFF',
    marginBottom: 24,
    textAlign: 'center',
  },
  summarySection: {
    marginBottom: 20,
    padding: 16,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
  },
  summarySectionTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#FFFFFF',
    marginBottom: 8,
  },
  summaryText: {
    fontSize: 14,
    color: '#FFFFFF',
    marginBottom: 4,
  },
  summarySubText: {
    fontSize: 12,
    color: '#CCCCCC',
    fontStyle: 'italic',
  },
  deliveryFeeText: {
    fontSize: 14,
    color: colors.secondary,
    fontWeight: '600',
    marginTop: 4,
  },
  optionsSubtitle: {
    fontSize: 14,
    color: '#CCCCCC',
    marginBottom: 16,
    lineHeight: 20,
  },
  optionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 8,
    marginBottom: 8,
  },
  selectedOptionItem: {
    backgroundColor: 'rgba(33, 150, 243, 0.2)',
  },
  optionContent: {
    flex: 1,
    marginLeft: 12,
  },
  optionName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  optionDescription: {
    fontSize: 12,
    color: '#CCCCCC',
    marginTop: 2,
  },
  optionPrice: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.primary,
  },
  priceSummarySection: {
    marginBottom: 20,
    padding: 16,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
  },
  priceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  priceLabel: {
    fontSize: 14,
    color: '#FFFFFF',
  },
  priceValue: {
    fontSize: 14,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  totalRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderTopWidth: 2,
    borderTopColor: 'rgba(255, 255, 255, 0.2)',
    paddingTop: 12,
    marginTop: 12,
  },
  totalLabel: {
    fontSize: 16,
    fontWeight: '700',
    color: '#FFFFFF',
  },
  totalPrice: {
    fontSize: 20,
    fontWeight: '800',
    color: colors.primary,
  },
  depositRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 8,
  },
  depositLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.secondary,
  },
  depositPrice: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.secondary,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    gap: 16,
    marginTop: 24,
  },
  backButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: 'rgba(255, 255, 255, 0.15)',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
  },
  backButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
    marginLeft: 8,
  },
  continueButton: {
    backgroundColor: colors.primary,
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    flex: 2,
  },
  continueButtonText: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.card,
    marginRight: 8,
  },
  
  // Modal Styles
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  modalContent: {
    borderRadius: 20,
    padding: 32,
    alignItems: 'center',
    width: '100%',
    maxWidth: 350,
    boxShadow: '0px 8px 24px rgba(0, 0, 0, 0.3)',
    elevation: 12,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
    overflow: 'hidden',
  },
  modalTitle: {
    fontSize: 22,
    fontWeight: '800',
    color: '#FFFFFF',
    textAlign: 'center',
    marginTop: 16,
    marginBottom: 8,
  },
  modalMessage: {
    fontSize: 16,
    color: '#FFFFFF',
    textAlign: 'center',
    lineHeight: 22,
    marginBottom: 24,
  },
  guestWarningButtons: {
    flexDirection: 'column',
    width: '100%',
    gap: 12,
  },
  createAccountButton: {
    backgroundColor: colors.primary,
    paddingVertical: 14,
    paddingHorizontal: 32,
    borderRadius: 12,
  },
  createAccountButtonText: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.card,
    textAlign: 'center',
  },
  continueGuestButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    paddingVertical: 14,
    paddingHorizontal: 32,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: 'rgba(255, 255, 255, 0.15)',
  },
  continueGuestButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
    textAlign: 'center',
  },
});
