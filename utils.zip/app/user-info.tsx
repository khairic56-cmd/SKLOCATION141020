
import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  SafeAreaView,
  Platform,
  Alert,
  ScrollView,
  ImageBackground,
  TextInput,
} from 'react-native';
import { Stack, router, useLocalSearchParams } from 'expo-router';
import { IconSymbol } from '@/components/IconSymbol';
import { colors } from '@/styles/commonStyles';
import { BlurView } from 'expo-blur';
import DateTimePicker from '@react-native-community/datetimepicker';
import { format } from 'date-fns';

export default function UserInfoScreen() {
  const params = useLocalSearchParams();
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [dateOfBirth, setDateOfBirth] = useState<Date | null>(null);
  const [showDateOfBirthPicker, setShowDateOfBirthPicker] = useState(false);

  const handleDateOfBirthChange = (event: any, selectedDate?: Date) => {
    setShowDateOfBirthPicker(false);
    if (selectedDate && event.type !== 'dismissed') {
      setDateOfBirth(selectedDate);
    }
  };

  const handleSubmit = () => {
    if (!firstName.trim() || !lastName.trim() || !email.trim() || !dateOfBirth) {
      Alert.alert('Erreur', 'Veuillez remplir tous les champs obligatoires.');
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      Alert.alert('Erreur', 'Veuillez entrer une adresse email valide.');
      return;
    }

    // Navigate to payment with user information
    router.push({
      pathname: '/payment',
      params: {
        ...params,
        firstName,
        lastName,
        email,
        dateOfBirth: dateOfBirth.toISOString(),
      },
    });
  };

  return (
    <ImageBackground 
      source={require('@/assets/images/285c86af-6344-4f73-beac-dbfa2112b685.jpeg')}
      style={styles.container}
      resizeMode="cover"
    >
      <SafeAreaView style={styles.safeArea}>
        <Stack.Screen
          options={{
            title: "Vos informations",
            headerShown: true,
            headerStyle: { backgroundColor: 'transparent' },
            headerTintColor: '#FFFFFF',
            headerTitleStyle: { fontWeight: '700', fontSize: 20 },
            headerLeft: () => (
              <Pressable onPress={() => router.back()} style={styles.headerBackButton}>
                <IconSymbol name="chevron.left" color="#FFFFFF" size={24} />
              </Pressable>
            ),
            headerBackground: () => (
              <BlurView 
                intensity={10} 
                tint="dark" 
                style={[StyleSheet.absoluteFill, Platform.OS !== 'ios' && { backgroundColor: 'rgba(0,0,0,0.1)' }]} 
              />
            ),
          }}
        />
        
        <ScrollView style={styles.scrollView} contentContainerStyle={styles.scrollContent}>
          <BlurView intensity={5} tint="extraLight" style={[styles.formContainer, Platform.OS !== 'ios' && { backgroundColor: 'rgba(255,255,255,0.05)' }]}>
            <Text style={styles.sectionTitle}>Vos informations personnelles</Text>
            
            <Text style={styles.guestInfoText}>
              En tant qu'invité, nous avons besoin de quelques informations pour finaliser votre réservation et vous envoyer la confirmation.
            </Text>
            
            <View style={styles.inputContainer}>
              <Text style={styles.inputLabel}>Prénom *</Text>
              <TextInput
                style={styles.textInput}
                value={firstName}
                onChangeText={setFirstName}
                placeholder="Entrez votre prénom"
                placeholderTextColor="#CCCCCC"
                autoCapitalize="words"
              />
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.inputLabel}>Nom *</Text>
              <TextInput
                style={styles.textInput}
                value={lastName}
                onChangeText={setLastName}
                placeholder="Entrez votre nom"
                placeholderTextColor="#CCCCCC"
                autoCapitalize="words"
              />
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.inputLabel}>Date de naissance *</Text>
              <Pressable style={styles.dateButton} onPress={() => setShowDateOfBirthPicker(true)}>
                <IconSymbol name="calendar" color={colors.primary} size={20} />
                <Text style={[styles.dateText, !dateOfBirth && styles.placeholderText]}>
                  {dateOfBirth ? format(dateOfBirth, 'dd/MM/yyyy') : 'Sélectionner votre date de naissance'}
                </Text>
              </Pressable>
              <Text style={styles.fieldNote}>
                Requis pour la location de véhicule (minimum 21 ans)
              </Text>
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.inputLabel}>Adresse email *</Text>
              <TextInput
                style={styles.textInput}
                value={email}
                onChangeText={setEmail}
                placeholder="exemple@email.com"
                placeholderTextColor="#CCCCCC"
                keyboardType="email-address"
                autoCapitalize="none"
                autoCorrect={false}
              />
              <Text style={styles.fieldNote}>
                Votre confirmation de réservation sera envoyée à cette adresse
              </Text>
            </View>

            <View style={styles.privacyNotice}>
              <IconSymbol name="lock.fill" color={colors.primary} size={16} />
              <Text style={styles.privacyText}>
                Vos informations personnelles sont sécurisées et ne seront utilisées que pour votre réservation.
              </Text>
            </View>

            <View style={styles.buttonContainer}>
              <Pressable style={styles.backButton} onPress={() => router.back()}>
                <IconSymbol name="chevron.left" color={colors.primary} size={20} />
                <Text style={styles.backButtonText}>Retour</Text>
              </Pressable>

              <Pressable style={styles.continueButton} onPress={handleSubmit}>
                <Text style={styles.continueButtonText}>Continuer</Text>
                <IconSymbol name="arrow.right.circle.fill" color={colors.card} size={20} />
              </Pressable>
            </View>
          </BlurView>
        </ScrollView>

        {/* Date of Birth Picker */}
        {showDateOfBirthPicker && (
          <DateTimePicker
            value={dateOfBirth || new Date(2000, 0, 1)}
            mode="date"
            display={Platform.OS === 'ios' ? 'spinner' : 'default'}
            onChange={handleDateOfBirthChange}
            maximumDate={new Date()}
            locale="fr-FR"
          />
        )}
      </SafeAreaView>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
  },
  headerBackButton: {
    padding: 8,
    marginLeft: -8,
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
    borderRadius: 20,
  },
  formContainer: {
    borderRadius: 16,
    padding: 24,
    boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.3)',
    elevation: 8,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
    overflow: 'hidden',
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#FFFFFF',
    marginBottom: 16,
    textAlign: 'center',
  },
  guestInfoText: {
    fontSize: 14,
    color: '#FFFFFF',
    textAlign: 'center',
    marginBottom: 24,
    lineHeight: 20,
    backgroundColor: 'rgba(33, 150, 243, 0.1)',
    padding: 16,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: 'rgba(33, 150, 243, 0.2)',
  },
  inputContainer: {
    marginBottom: 20,
  },
  inputLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
    marginBottom: 8,
  },
  textInput: {
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    borderWidth: 2,
    borderColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 12,
    padding: 16,
    fontSize: 16,
    color: '#FFFFFF',
    fontWeight: '500',
  },
  dateButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    borderWidth: 2,
    borderColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
  },
  dateText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
    marginLeft: 12,
    flex: 1,
  },
  placeholderText: {
    color: '#CCCCCC',
    fontStyle: 'italic',
  },
  fieldNote: {
    fontSize: 12,
    color: '#CCCCCC',
    marginTop: 4,
    fontStyle: 'italic',
  },
  privacyNotice: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    backgroundColor: 'rgba(76, 175, 80, 0.1)',
    padding: 12,
    borderRadius: 8,
    marginBottom: 24,
    borderWidth: 1,
    borderColor: 'rgba(76, 175, 80, 0.2)',
  },
  privacyText: {
    fontSize: 12,
    color: '#FFFFFF',
    marginLeft: 8,
    flex: 1,
    lineHeight: 16,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    gap: 16,
    marginTop: 24,
  },
  backButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: 'rgba(255, 255, 255, 0.15)',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
  },
  backButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
    marginLeft: 8,
  },
  continueButton: {
    backgroundColor: colors.primary,
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    flex: 2,
  },
  continueButtonText: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.card,
    marginRight: 8,
  },
});
