
import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  SafeAreaView,
  Platform,
  Alert,
  ScrollView,
  ImageBackground,
  Linking,
} from 'react-native';
import { Stack, router, useLocalSearchParams } from 'expo-router';
import { IconSymbol } from '@/components/IconSymbol';
import { colors } from '@/styles/commonStyles';
import { BlurView } from 'expo-blur';
import { supabase } from '@/app/integrations/supabase/client';
import type { TablesInsert } from '@/app/integrations/supabase/types';
import { format } from 'date-fns';

export default function PaymentScreen() {
  const params = useLocalSearchParams();
  const [processing, setProcessing] = useState(false);

  // Extract all booking data from params
  const startDate = new Date(params.startDate as string);
  const endDate = new Date(params.endDate as string);
  const startTime = params.startTime as string;
  const endTime = params.endTime as string;
  const pickupOption = params.pickupOption as 'pickup' | 'delivery';
  const pickupLocation = params.pickupLocation as string;
  const deliveryAddress = params.deliveryAddress as string;
  const totalPrice = parseFloat(params.totalPrice as string);
  const depositAmount = parseFloat(params.depositAmount as string);
  const selectedOptions = JSON.parse(params.selectedOptions as string || '[]');
  const isGuest = params.isGuest === 'true';
  
  // User information (for guests)
  const firstName = params.firstName as string;
  const lastName = params.lastName as string;
  const email = params.email as string;
  const dateOfBirth = params.dateOfBirth ? new Date(params.dateOfBirth as string) : null;

  // Car information
  const carInfo = {
    id: 'car-1',
    name: 'Peugeot 208',
    brand: 'Peugeot',
    type: 'Citadine'
  };

  const handlePayment = async (paymentMethod: 'credit_card' | 'bank_transfer' | 'phone_confirmation') => {
    if (processing) return;
    
    setProcessing(true);
    
    try {
      // Get current user if authenticated
      const { data: { user } } = await supabase.auth.getUser();
      
      // Create booking in database
      const bookingData: TablesInsert<'bookings'> = {
        user_id: user?.id || null,
        guest_email: isGuest ? email : null,
        guest_first_name: isGuest ? firstName : null,
        guest_last_name: isGuest ? lastName : null,
        car_id: carInfo.id,
        start_date: format(startDate, 'yyyy-MM-dd'),
        end_date: format(endDate, 'yyyy-MM-dd'),
        start_time: startTime,
        end_time: endTime,
        pickup_location: pickupLocation,
        pickup_type: pickupOption,
        delivery_address: deliveryAddress || null,
        total_price: totalPrice,
        deposit_amount: depositAmount,
        payment_method: paymentMethod,
        additional_options: selectedOptions
      };

      const { data: booking, error } = await supabase
        .from('bookings')
        .insert(bookingData)
        .select()
        .single();

      if (error) throw error;

      // Send confirmation email
      await sendConfirmationEmail(booking);

      // Navigate to confirmation page
      router.push({
        pathname: '/booking-confirmation',
        params: {
          bookingId: booking.id,
          email: isGuest ? email : user?.email,
          totalPrice: totalPrice.toString(),
          depositAmount: depositAmount.toString(),
          paymentMethod,
        },
      });

    } catch (error) {
      console.error('Error creating booking:', error);
      Alert.alert('Erreur', 'Impossible de créer la réservation. Veuillez réessayer.');
    } finally {
      setProcessing(false);
    }
  };

  const sendConfirmationEmail = async (booking: any) => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      const response = await fetch(`${supabase.supabaseUrl}/functions/v1/send-booking-confirmation`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session?.access_token || supabase.supabaseKey}`,
        },
        body: JSON.stringify({
          bookingId: booking.id,
          email: booking.guest_email || email,
          firstName: booking.guest_first_name || firstName,
          lastName: booking.guest_last_name || lastName,
          carName: carInfo.name,
          startDate: booking.start_date,
          endDate: booking.end_date,
          startTime: booking.start_time,
          endTime: booking.end_time,
          pickupLocation: booking.pickup_location,
          pickupType: booking.pickup_type,
          deliveryAddress: booking.delivery_address,
          totalPrice: booking.total_price,
          depositAmount: booking.deposit_amount,
          paymentMethod: booking.payment_method,
          additionalOptions: booking.additional_options || []
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to send confirmation email');
      }

      console.log('Confirmation email sent successfully');
    } catch (error) {
      console.error('Error sending confirmation email:', error);
      // Don't show error to user as booking was successful
    }
  };

  const handleCreditCardPayment = () => {
    Alert.alert(
      'Paiement par carte bancaire',
      `Vous allez être redirigé vers notre plateforme de paiement sécurisée pour régler l'acompte de ${depositAmount}€.\n\nCette fonctionnalité sera bientôt disponible.`,
      [
        { text: 'Annuler', style: 'cancel' },
        { text: 'Continuer', onPress: () => handlePayment('credit_card') }
      ]
    );
  };

  const handleBankTransfer = () => {
    Alert.alert(
      'Paiement par virement bancaire',
      `Les coordonnées bancaires pour effectuer le virement de ${depositAmount}€ vous seront envoyées par email.\n\nIBAN: FR76 1234 5678 9012 3456 7890 123\nBIC: ABCDEFGH\nBénéficiaire: SK LOCATION14`,
      [
        { text: 'Annuler', style: 'cancel' },
        { text: 'Confirmer', onPress: () => handlePayment('bank_transfer') }
      ]
    );
  };

  const handlePhoneConfirmation = () => {
    Alert.alert(
      'Confirmation par téléphone',
      `Vous allez être redirigé vers l'application téléphone pour appeler notre service client au 066145612.\n\nIls finaliseront votre réservation et prendront le paiement de l'acompte de ${depositAmount}€.`,
      [
        { text: 'Annuler', style: 'cancel' },
        { text: 'Appeler', onPress: () => {
          handlePayment('phone_confirmation');
          const phoneNumber = '066145612';
          const url = `tel:${phoneNumber}`;
          
          Linking.canOpenURL(url)
            .then((supported) => {
              if (supported) {
                return Linking.openURL(url);
              } else {
                Alert.alert('Erreur', 'Impossible d\'ouvrir l\'application téléphone.');
              }
            })
            .catch((err) => {
              console.error('Error opening phone app:', err);
              Alert.alert('Erreur', 'Impossible d\'ouvrir l\'application téléphone.');
            });
        }}
      ]
    );
  };

  return (
    <ImageBackground 
      source={require('@/assets/images/285c86af-6344-4f73-beac-dbfa2112b685.jpeg')}
      style={styles.container}
      resizeMode="cover"
    >
      <SafeAreaView style={styles.safeArea}>
        <Stack.Screen
          options={{
            title: "Paiement",
            headerShown: true,
            headerStyle: { backgroundColor: 'transparent' },
            headerTintColor: '#FFFFFF',
            headerTitleStyle: { fontWeight: '700', fontSize: 20 },
            headerLeft: () => (
              <Pressable onPress={() => router.back()} style={styles.headerBackButton}>
                <IconSymbol name="chevron.left" color="#FFFFFF" size={24} />
              </Pressable>
            ),
            headerBackground: () => (
              <BlurView 
                intensity={10} 
                tint="dark" 
                style={[StyleSheet.absoluteFill, Platform.OS !== 'ios' && { backgroundColor: 'rgba(0,0,0,0.1)' }]} 
              />
            ),
          }}
        />
        
        <ScrollView style={styles.scrollView} contentContainerStyle={styles.scrollContent}>
          <BlurView intensity={5} tint="extraLight" style={[styles.paymentContainer, Platform.OS !== 'ios' && { backgroundColor: 'rgba(255,255,255,0.05)' }]}>
            <Text style={styles.sectionTitle}>Paiement de l'acompte</Text>
            
            <View style={styles.summaryCard}>
              <Text style={styles.summaryTitle}>Récapitulatif du paiement</Text>
              <View style={styles.summaryRow}>
                <Text style={styles.summaryLabel}>Montant total:</Text>
                <Text style={styles.summaryValue}>{totalPrice}€</Text>
              </View>
              <View style={styles.summaryRow}>
                <Text style={styles.summaryLabel}>Acompte à régler (30%):</Text>
                <Text style={styles.summaryValueHighlight}>{depositAmount}€</Text>
              </View>
              <View style={styles.summaryRow}>
                <Text style={styles.summaryLabel}>Solde à régler à la récupération:</Text>
                <Text style={styles.summaryValue}>{totalPrice - depositAmount}€</Text>
              </View>
            </View>
            
            <Text style={styles.paymentSubtitle}>
              Choisissez votre mode de paiement pour l'acompte de {depositAmount}€
            </Text>
            
            <View style={styles.paymentOptionsContainer}>
              <Pressable 
                style={[styles.paymentOption, processing && styles.disabledOption]} 
                onPress={handleCreditCardPayment}
                disabled={processing}
              >
                <IconSymbol name="creditcard.fill" color={colors.primary} size={24} />
                <View style={styles.paymentOptionContent}>
                  <Text style={styles.paymentOptionTitle}>Payer par carte bancaire</Text>
                  <Text style={styles.paymentOptionSubtitle}>Paiement sécurisé en ligne</Text>
                  <Text style={styles.paymentOptionNote}>Traitement immédiat</Text>
                </View>
                <IconSymbol name="chevron.right" color={colors.primary} size={20} />
              </Pressable>

              <Pressable 
                style={[styles.paymentOption, processing && styles.disabledOption]} 
                onPress={handleBankTransfer}
                disabled={processing}
              >
                <IconSymbol name="building.columns.fill" color={colors.primary} size={24} />
                <View style={styles.paymentOptionContent}>
                  <Text style={styles.paymentOptionTitle}>Paiement par virement</Text>
                  <Text style={styles.paymentOptionSubtitle}>Coordonnées bancaires par email</Text>
                  <Text style={styles.paymentOptionNote}>Délai: 1-2 jours ouvrés</Text>
                </View>
                <IconSymbol name="chevron.right" color={colors.primary} size={20} />
              </Pressable>

              <Pressable 
                style={[styles.paymentOption, processing && styles.disabledOption]} 
                onPress={handlePhoneConfirmation}
                disabled={processing}
              >
                <IconSymbol name="phone.fill" color={colors.secondary} size={24} />
                <View style={styles.paymentOptionContent}>
                  <Text style={styles.paymentOptionTitle}>Confirmer par téléphone</Text>
                  <Text style={styles.paymentOptionSubtitle}>Appeler le 066145612</Text>
                  <Text style={styles.paymentOptionNote}>Paiement par téléphone</Text>
                </View>
                <IconSymbol name="phone.circle.fill" color={colors.secondary} size={20} />
              </Pressable>
            </View>

            <View style={styles.securityNotice}>
              <IconSymbol name="shield.checkmark.fill" color={colors.secondary} size={20} />
              <Text style={styles.securityText}>
                Tous nos paiements sont sécurisés. Vos données bancaires ne sont jamais stockées sur nos serveurs.
              </Text>
            </View>

            <Pressable 
              style={[styles.backButton, processing && styles.disabledOption]} 
              onPress={() => router.back()}
              disabled={processing}
            >
              <IconSymbol name="chevron.left" color={colors.primary} size={20} />
              <Text style={styles.backButtonText}>Modifier la réservation</Text>
            </Pressable>
          </BlurView>
        </ScrollView>
      </SafeAreaView>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
  },
  headerBackButton: {
    padding: 8,
    marginLeft: -8,
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
    borderRadius: 20,
  },
  paymentContainer: {
    borderRadius: 16,
    padding: 24,
    boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.3)',
    elevation: 8,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
    overflow: 'hidden',
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#FFFFFF',
    marginBottom: 20,
    textAlign: 'center',
  },
  summaryCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.15)',
  },
  summaryTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#FFFFFF',
    marginBottom: 12,
    textAlign: 'center',
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  summaryLabel: {
    fontSize: 14,
    color: '#FFFFFF',
  },
  summaryValue: {
    fontSize: 14,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  summaryValueHighlight: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.primary,
  },
  paymentSubtitle: {
    fontSize: 16,
    color: '#FFFFFF',
    textAlign: 'center',
    fontWeight: '600',
    marginBottom: 24,
    lineHeight: 22,
  },
  paymentOptionsContainer: {
    marginBottom: 24,
  },
  paymentOption: {
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    borderWidth: 2,
    borderColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 12,
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  disabledOption: {
    opacity: 0.5,
  },
  paymentOptionContent: {
    flex: 1,
    marginLeft: 16,
  },
  paymentOptionTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  paymentOptionSubtitle: {
    fontSize: 14,
    color: '#FFFFFF',
    marginBottom: 2,
  },
  paymentOptionNote: {
    fontSize: 12,
    color: '#CCCCCC',
    fontStyle: 'italic',
  },
  securityNotice: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    backgroundColor: 'rgba(76, 175, 80, 0.1)',
    padding: 12,
    borderRadius: 8,
    marginBottom: 24,
    borderWidth: 1,
    borderColor: 'rgba(76, 175, 80, 0.2)',
  },
  securityText: {
    fontSize: 12,
    color: '#FFFFFF',
    marginLeft: 8,
    flex: 1,
    lineHeight: 16,
  },
  backButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: 'rgba(255, 255, 255, 0.15)',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  backButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
    marginLeft: 8,
  },
});
