
import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  Pressable, 
  SafeAreaView,
  Platform,
  TextInput,
  Alert,
  KeyboardAvoidingView,
  ScrollView,
  ImageBackground
} from 'react-native';
import { Stack, router } from 'expo-router';
import { IconSymbol } from '@/components/IconSymbol';
import { colors } from '@/styles/commonStyles';
import DateTimePicker from '@react-native-community/datetimepicker';

export default function SignupScreen() {
  console.log('SignupScreen rendered');
  
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [birthDate, setBirthDate] = useState<Date | null>(null);
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSignup = async () => {
    console.log('Signup attempt with:', { firstName, lastName, email, birthDate });
    
    if (!firstName || !lastName || !email || !birthDate) {
      Alert.alert('Erreur', 'Veuillez remplir tous les champs obligatoires');
      return;
    }

    if (!email.includes('@')) {
      Alert.alert('Erreur', 'Veuillez entrer une adresse email valide');
      return;
    }

    // Check if user is at least 18 years old
    const today = new Date();
    const age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    
    if (age < 18 || (age === 18 && monthDiff < 0) || 
        (age === 18 && monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      Alert.alert('Erreur', 'Vous devez avoir au moins 18 ans pour créer un compte');
      return;
    }

    setLoading(true);
    
    try {
      // TODO: Implement Supabase signup
      console.log('Signup logic would be implemented here with Supabase');
      
      // Simulate signup delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      Alert.alert(
        'Fonctionnalité à venir', 
        'Pour activer la création de compte et l\'envoi d\'emails automatiques, veuillez connecter Supabase en appuyant sur le bouton Supabase dans l\'interface. Un email sera automatiquement envoyé à votre adresse avec un lien pour créer votre mot de passe.',
        [
          { text: 'OK', onPress: () => router.back() }
        ]
      );
    } catch (error) {
      console.log('Signup error:', error);
      Alert.alert('Erreur', 'Une erreur est survenue lors de la création du compte');
    } finally {
      setLoading(false);
    }
  };

  const handleDateChange = (event: any, selectedDate?: Date) => {
    console.log('Date picker event:', event.type, selectedDate);
    
    if (Platform.OS === 'android') {
      setShowDatePicker(false);
    }
    
    if (event.type === 'set' && selectedDate) {
      setBirthDate(selectedDate);
      if (Platform.OS === 'ios') {
        setShowDatePicker(false);
      }
    } else if (event.type === 'dismissed') {
      setShowDatePicker(false);
    }
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('fr-FR');
  };

  const handleDatePress = () => {
    console.log('Date field pressed, opening calendar');
    setShowDatePicker(true);
  };

  const handleBack = () => {
    console.log('Back button pressed');
    router.back();
  };

  return (
    <>
      <Stack.Screen
        options={{
          title: "Créer un compte",
          headerShown: false,
        }}
      />
      <ImageBackground
        source={require('../assets/images/f22ff4a4-6dad-4a7d-bb7f-854c718d51e9.jpeg')}
        style={styles.backgroundImage}
        resizeMode="cover"
      >
        <View style={styles.overlay}>
          <SafeAreaView style={styles.safeArea}>
            <KeyboardAvoidingView 
              style={styles.keyboardView}
              behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
            >
              <ScrollView contentContainerStyle={styles.scrollContent}>
                <View style={styles.header}>
                  <Pressable style={styles.backButton} onPress={handleBack}>
                    <IconSymbol name="chevron.left" size={24} color={colors.card} />
                  </Pressable>
                  <Text style={styles.title}>Créer un compte</Text>
                </View>

                <View style={styles.content}>
                  <View style={styles.welcomeSection}>
                    <IconSymbol name="person.badge.plus" size={60} color={colors.card} />
                    <Text style={styles.welcomeTitle}>Rejoignez-nous !</Text>
                    <Text style={styles.welcomeSubtitle}>
                      Créez votre compte SK LOC14 en quelques étapes
                    </Text>
                  </View>

                  <View style={styles.formContainer}>
                    <View style={styles.inputContainer}>
                      <IconSymbol name="person" size={20} color={colors.textSecondary} />
                      <TextInput
                        style={styles.input}
                        placeholder="Prénom *"
                        placeholderTextColor={colors.textSecondary}
                        value={firstName}
                        onChangeText={setFirstName}
                        autoCapitalize="words"
                        autoCorrect={false}
                      />
                    </View>

                    <View style={styles.inputContainer}>
                      <IconSymbol name="person" size={20} color={colors.textSecondary} />
                      <TextInput
                        style={styles.input}
                        placeholder="Nom *"
                        placeholderTextColor={colors.textSecondary}
                        value={lastName}
                        onChangeText={setLastName}
                        autoCapitalize="words"
                        autoCorrect={false}
                      />
                    </View>

                    <View style={styles.inputContainer}>
                      <IconSymbol name="envelope" size={20} color={colors.textSecondary} />
                      <TextInput
                        style={styles.input}
                        placeholder="Adresse email *"
                        placeholderTextColor={colors.textSecondary}
                        value={email}
                        onChangeText={setEmail}
                        keyboardType="email-address"
                        autoCapitalize="none"
                        autoCorrect={false}
                      />
                    </View>

                    <Pressable 
                      style={[styles.inputContainer, !birthDate && styles.inputContainerEmpty]} 
                      onPress={handleDatePress}
                    >
                      <IconSymbol name="calendar" size={20} color={colors.textSecondary} />
                      <Text style={[styles.dateText, !birthDate && styles.placeholderText]}>
                        {birthDate ? formatDate(birthDate) : 'Date de naissance *'}
                      </Text>
                      <IconSymbol name="chevron.down" size={16} color={colors.textSecondary} />
                    </Pressable>

                    {showDatePicker && (
                      <View style={styles.datePickerContainer}>
                        <DateTimePicker
                          value={birthDate || new Date(2000, 0, 1)}
                          mode="date"
                          display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                          onChange={handleDateChange}
                          maximumDate={new Date()}
                          minimumDate={new Date(1900, 0, 1)}
                          style={styles.datePicker}
                        />
                        {Platform.OS === 'ios' && (
                          <View style={styles.datePickerButtons}>
                            <Pressable 
                              style={styles.datePickerButton}
                              onPress={() => setShowDatePicker(false)}
                            >
                              <Text style={styles.datePickerButtonText}>Annuler</Text>
                            </Pressable>
                            <Pressable 
                              style={[styles.datePickerButton, styles.datePickerConfirmButton]}
                              onPress={() => setShowDatePicker(false)}
                            >
                              <Text style={[styles.datePickerButtonText, styles.datePickerConfirmText]}>Confirmer</Text>
                            </Pressable>
                          </View>
                        )}
                      </View>
                    )}

                    <View style={styles.infoContainer}>
                      <IconSymbol name="info.circle" size={16} color={colors.card} />
                      <Text style={styles.infoText}>
                        Un email sera envoyé à votre adresse avec un lien pour créer votre mot de passe
                      </Text>
                    </View>

                    <Pressable 
                      style={[styles.signupButton, loading && styles.signupButtonDisabled]} 
                      onPress={handleSignup}
                      disabled={loading}
                    >
                      {loading ? (
                        <Text style={styles.signupButtonText}>Création...</Text>
                      ) : (
                        <>
                          <Text style={styles.signupButtonText}>Créer mon compte</Text>
                          <IconSymbol name="arrow.right" size={20} color={colors.primary} />
                        </>
                      )}
                    </Pressable>
                  </View>

                  <View style={styles.footer}>
                    <Text style={styles.footerText}>Déjà un compte ?</Text>
                    <Pressable onPress={() => router.replace('/login')}>
                      <Text style={styles.loginLink}>Se connecter</Text>
                    </Pressable>
                  </View>
                </View>
              </ScrollView>
            </KeyboardAvoidingView>
          </SafeAreaView>
        </View>
      </ImageBackground>
    </>
  );
}

const styles = StyleSheet.create({
  backgroundImage: {
    flex: 1,
  },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
  },
  safeArea: {
    flex: 1,
  },
  keyboardView: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: Platform.OS === 'ios' ? 10 : 20,
    paddingBottom: 20,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    flex: 1,
    fontSize: 24,
    fontWeight: '800',
    color: colors.card,
    textAlign: 'center',
    marginRight: 40,
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
    justifyContent: 'center',
  },
  welcomeSection: {
    alignItems: 'center',
    marginBottom: 40,
  },
  welcomeTitle: {
    fontSize: 28,
    fontWeight: '800',
    color: colors.card,
    marginTop: 16,
    marginBottom: 8,
  },
  welcomeSubtitle: {
    fontSize: 16,
    color: colors.card,
    textAlign: 'center',
    opacity: 0.9,
  },
  formContainer: {
    gap: 16,
    marginBottom: 30,
  },
  inputContainer: {
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    borderRadius: 15,
    paddingHorizontal: 16,
    paddingVertical: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    boxShadow: '0px 2px 10px rgba(0, 0, 0, 0.1)',
    elevation: 2,
  },
  inputContainerEmpty: {
    borderWidth: 1,
    borderColor: 'rgba(0, 0, 0, 0.1)',
  },
  input: {
    flex: 1,
    fontSize: 16,
    color: colors.text,
  },
  dateText: {
    flex: 1,
    fontSize: 16,
    color: colors.text,
  },
  placeholderText: {
    color: colors.textSecondary,
  },
  datePickerContainer: {
    backgroundColor: 'rgba(255, 255, 255, 0.98)',
    borderRadius: 15,
    padding: 16,
    boxShadow: '0px 4px 20px rgba(0, 0, 0, 0.15)',
    elevation: 8,
  },
  datePicker: {
    backgroundColor: 'transparent',
  },
  datePickerButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 16,
    gap: 12,
  },
  datePickerButton: {
    flex: 1,
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 10,
    backgroundColor: 'rgba(0, 0, 0, 0.05)',
    alignItems: 'center',
  },
  datePickerConfirmButton: {
    backgroundColor: colors.primary,
  },
  datePickerButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
  },
  datePickerConfirmText: {
    color: colors.card,
  },
  infoContainer: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 8,
    paddingHorizontal: 4,
  },
  infoText: {
    flex: 1,
    fontSize: 12,
    color: colors.card,
    opacity: 0.9,
    lineHeight: 16,
  },
  signupButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 25,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
    boxShadow: '0px 4px 15px rgba(0, 0, 0, 0.1)',
    elevation: 4,
    marginTop: 8,
  },
  signupButtonDisabled: {
    opacity: 0.7,
  },
  signupButtonText: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.primary,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
  },
  footerText: {
    fontSize: 14,
    color: colors.card,
    opacity: 0.9,
  },
  loginLink: {
    fontSize: 14,
    color: colors.card,
    fontWeight: '700',
    textDecorationLine: 'underline',
  },
});
