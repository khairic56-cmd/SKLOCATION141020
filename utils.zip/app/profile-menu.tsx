
import React from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  Pressable, 
  SafeAreaView,
  Platform,
  Alert,
  ImageBackground
} from 'react-native';
import { Stack, router } from 'expo-router';
import { IconSymbol } from '@/components/IconSymbol';
import { colors } from '@/styles/commonStyles';

export default function ProfileMenuScreen() {
  console.log('ProfileMenuScreen rendered');

  const handleCreateAccount = () => {
    console.log('Create account pressed - redirecting to signup');
    router.push('/signup');
  };

  const handleEditProfile = () => {
    console.log('Edit profile pressed');
    // TODO: Navigate to edit profile screen
    Alert.alert('À venir', 'Fonctionnalité de modification du profil à venir');
  };

  const handleMyBookings = () => {
    console.log('My bookings pressed');
    // TODO: Navigate to bookings screen
    Alert.alert('À venir', 'Fonctionnalité de mes réservations à venir');
  };

  const handleSettings = () => {
    console.log('Settings pressed');
    // TODO: Navigate to settings screen
    Alert.alert('À venir', 'Fonctionnalité de paramètres à venir');
  };

  const handleLogout = () => {
    console.log('Logout pressed');
    Alert.alert(
      'Déconnexion',
      'Êtes-vous sûr de vouloir vous déconnecter ?',
      [
        { text: 'Annuler', style: 'cancel' },
        { 
          text: 'Déconnexion', 
          style: 'destructive',
          onPress: () => {
            // TODO: Implement Supabase logout
            console.log('Logout logic would be implemented here with Supabase');
            router.replace('/(tabs)/(home)');
          }
        }
      ]
    );
  };

  const handleBack = () => {
    console.log('Back button pressed');
    router.back();
  };

  return (
    <>
      <Stack.Screen
        options={{
          title: "Profil",
          headerShown: false,
        }}
      />
      <ImageBackground
        source={require('../assets/images/6c8547c5-5035-48c3-9c6d-44b96a891742.jpeg')}
        style={styles.backgroundImage}
        resizeMode="cover"
      >
        <View style={styles.overlay}>
          <SafeAreaView style={styles.safeArea}>
            <View style={styles.header}>
              <Pressable style={styles.backButton} onPress={handleBack}>
                <IconSymbol name="chevron.left" size={24} color={colors.card} />
              </Pressable>
              <Text style={styles.title}>Mon Profil</Text>
            </View>

            <View style={styles.content}>
              <View style={styles.profileSection}>
                <View style={styles.avatar}>
                  <IconSymbol name="person.fill" size={40} color={colors.primary} />
                </View>
                <Text style={styles.userName}>Utilisateur Invité</Text>
                <Text style={styles.userEmail}>Créez votre compte pour plus de fonctionnalités</Text>
              </View>

              <View style={styles.menuContainer}>
                <Pressable style={[styles.menuItem, styles.createAccountItem]} onPress={handleCreateAccount}>
                  <View style={styles.menuItemLeft}>
                    <View style={[styles.menuIcon, styles.createAccountIcon]}>
                      <IconSymbol name="person.badge.plus" size={24} color={colors.card} />
                    </View>
                    <Text style={[styles.menuItemText, styles.createAccountText]}>Créer un compte</Text>
                  </View>
                  <IconSymbol name="chevron.right" size={20} color={colors.card} />
                </Pressable>

                <Pressable style={styles.menuItem} onPress={handleEditProfile}>
                  <View style={styles.menuItemLeft}>
                    <View style={styles.menuIcon}>
                      <IconSymbol name="person.circle" size={24} color={colors.primary} />
                    </View>
                    <Text style={styles.menuItemText}>Modifier le profil</Text>
                  </View>
                  <IconSymbol name="chevron.right" size={20} color={colors.textSecondary} />
                </Pressable>

                <Pressable style={styles.menuItem} onPress={handleMyBookings}>
                  <View style={styles.menuItemLeft}>
                    <View style={styles.menuIcon}>
                      <IconSymbol name="car.fill" size={24} color={colors.primary} />
                    </View>
                    <Text style={styles.menuItemText}>Mes réservations</Text>
                  </View>
                  <IconSymbol name="chevron.right" size={20} color={colors.textSecondary} />
                </Pressable>

                <Pressable style={styles.menuItem} onPress={handleSettings}>
                  <View style={styles.menuItemLeft}>
                    <View style={styles.menuIcon}>
                      <IconSymbol name="gearshape.fill" size={24} color={colors.primary} />
                    </View>
                    <Text style={styles.menuItemText}>Paramètres</Text>
                  </View>
                  <IconSymbol name="chevron.right" size={20} color={colors.textSecondary} />
                </Pressable>

                <View style={styles.separator} />

                <Pressable style={styles.menuItem} onPress={handleLogout}>
                  <View style={styles.menuItemLeft}>
                    <View style={[styles.menuIcon, styles.logoutIcon]}>
                      <IconSymbol name="arrow.right.square" size={24} color={colors.card} />
                    </View>
                    <Text style={[styles.menuItemText, styles.logoutText]}>Déconnexion</Text>
                  </View>
                  <IconSymbol name="chevron.right" size={20} color={colors.secondary} />
                </Pressable>
              </View>

              <View style={styles.footer}>
                <Text style={styles.footerText}>SK LOC14 - Version 1.0.0</Text>
              </View>
            </View>
          </SafeAreaView>
        </View>
      </ImageBackground>
    </>
  );
}

const styles = StyleSheet.create({
  backgroundImage: {
    flex: 1,
  },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
  },
  safeArea: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: Platform.OS === 'ios' ? 10 : 20,
    paddingBottom: 20,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    flex: 1,
    fontSize: 24,
    fontWeight: '800',
    color: colors.card,
    textAlign: 'center',
    marginRight: 40,
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
  },
  profileSection: {
    alignItems: 'center',
    marginBottom: 40,
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: colors.card,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
    boxShadow: '0px 4px 15px rgba(0, 0, 0, 0.1)',
    elevation: 4,
  },
  userName: {
    fontSize: 24,
    fontWeight: '800',
    color: colors.card,
    marginBottom: 4,
  },
  userEmail: {
    fontSize: 16,
    color: colors.card,
    opacity: 0.8,
    textAlign: 'center',
  },
  menuContainer: {
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    borderRadius: 20,
    padding: 8,
    marginBottom: 30,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 16,
    paddingHorizontal: 16,
    borderRadius: 12,
    marginVertical: 2,
  },
  createAccountItem: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderWidth: 2,
    borderColor: colors.primary,
  },
  menuItemLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  menuIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.card,
    alignItems: 'center',
    justifyContent: 'center',
  },
  createAccountIcon: {
    backgroundColor: colors.primary,
  },
  logoutIcon: {
    backgroundColor: colors.secondary,
  },
  menuItemText: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.card,
  },
  createAccountText: {
    color: colors.card,
    fontWeight: '700',
  },
  logoutText: {
    color: colors.card,
  },
  separator: {
    height: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    marginVertical: 8,
    marginHorizontal: 16,
  },
  footer: {
    alignItems: 'center',
    marginTop: 'auto',
    paddingBottom: 20,
  },
  footerText: {
    fontSize: 12,
    color: colors.card,
    opacity: 0.6,
  },
});
