
import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  Pressable, 
  SafeAreaView,
  Platform,
  TextInput,
  Alert,
  KeyboardAvoidingView,
  ScrollView,
  ImageBackground,
  Animated,
  Dimensions
} from 'react-native';
import { Stack, router } from 'expo-router';
import { IconSymbol } from '@/components/IconSymbol';
import { colors } from '@/styles/commonStyles';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';

const { width, height } = Dimensions.get('window');

export default function LoginScreen() {
  console.log('LoginScreen rendered');
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [emailFocused, setEmailFocused] = useState(false);
  const [passwordFocused, setPasswordFocused] = useState(false);

  const handleLogin = async () => {
    console.log('Login attempt with email:', email);
    
    if (!email || !password) {
      Alert.alert('Erreur', 'Veuillez remplir tous les champs');
      return;
    }

    if (!email.includes('@')) {
      Alert.alert('Erreur', 'Veuillez entrer une adresse email valide');
      return;
    }

    setLoading(true);
    
    try {
      // TODO: Implement Supabase login
      console.log('Login logic would be implemented here with Supabase');
      
      // Simulate login delay
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      Alert.alert(
        'Connexion réussie !', 
        'Bienvenue dans SK LOCATION14',
        [
          { text: 'Continuer', onPress: () => router.replace('/(tabs)/(home)') }
        ]
      );
    } catch (error) {
      console.log('Login error:', error);
      Alert.alert('Erreur', 'Une erreur est survenue lors de la connexion');
    } finally {
      setLoading(false);
    }
  };

  const handleForgotPassword = () => {
    console.log('Forgot password pressed');
    router.push('/forgot-password');
  };

  const handleBack = () => {
    console.log('Back button pressed');
    router.back();
  };

  const handleSocialLogin = (provider: string) => {
    console.log(`${provider} login pressed`);
    Alert.alert(
      'Fonctionnalité à venir', 
      `La connexion via ${provider} sera bientôt disponible !`
    );
  };

  return (
    <>
      <Stack.Screen
        options={{
          title: "Connexion",
          headerShown: false,
        }}
      />
      <ImageBackground
        source={require('@/assets/images/e24524a0-8894-4ab5-996d-ee7e6c73c38a.jpeg')}
        style={styles.backgroundImage}
        resizeMode="cover"
      >
        <LinearGradient
          colors={['rgba(0, 0, 0, 0.4)', 'rgba(0, 0, 0, 0.7)', 'rgba(0, 0, 0, 0.9)']}
          style={styles.overlay}
        >
          <SafeAreaView style={styles.safeArea}>
            <KeyboardAvoidingView 
              style={styles.keyboardView}
              behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
            >
              <ScrollView 
                contentContainerStyle={styles.scrollContent}
                showsVerticalScrollIndicator={false}
              >
                <View style={styles.header}>
                  <Pressable style={styles.backButton} onPress={handleBack}>
                    <IconSymbol name="chevron.left" size={24} color="#FFFFFF" />
                  </Pressable>
                </View>

                <View style={styles.content}>
                  <View style={styles.logoSection}>
                    <View style={styles.logoContainer}>
                      <IconSymbol name="car.fill" size={50} color="#FFFFFF" />
                    </View>
                    <Text style={styles.brandTitle}>SK LOCATION14</Text>
                    <Text style={styles.brandSubtitle}>Location de voitures premium</Text>
                  </View>

                  <BlurView intensity={20} tint="dark" style={styles.formCard}>
                    <View style={styles.welcomeSection}>
                      <Text style={styles.welcomeTitle}>Bon retour !</Text>
                      <Text style={styles.welcomeSubtitle}>
                        Connectez-vous pour accéder à nos véhicules
                      </Text>
                    </View>

                    <View style={styles.formContainer}>
                      <View style={[
                        styles.inputContainer,
                        emailFocused && styles.inputContainerFocused
                      ]}>
                        <IconSymbol name="envelope" size={20} color="#FFFFFF" />
                        <TextInput
                          style={styles.input}
                          placeholder="Adresse email"
                          placeholderTextColor="rgba(255, 255, 255, 0.7)"
                          value={email}
                          onChangeText={setEmail}
                          keyboardType="email-address"
                          autoCapitalize="none"
                          autoCorrect={false}
                          onFocus={() => setEmailFocused(true)}
                          onBlur={() => setEmailFocused(false)}
                        />
                      </View>

                      <View style={[
                        styles.inputContainer,
                        passwordFocused && styles.inputContainerFocused
                      ]}>
                        <IconSymbol name="lock" size={20} color="#FFFFFF" />
                        <TextInput
                          style={styles.input}
                          placeholder="Mot de passe"
                          placeholderTextColor="rgba(255, 255, 255, 0.7)"
                          value={password}
                          onChangeText={setPassword}
                          secureTextEntry={!showPassword}
                          autoCapitalize="none"
                          autoCorrect={false}
                          onFocus={() => setPasswordFocused(true)}
                          onBlur={() => setPasswordFocused(false)}
                        />
                        <Pressable onPress={() => setShowPassword(!showPassword)}>
                          <IconSymbol 
                            name={showPassword ? "eye.slash" : "eye"} 
                            size={20} 
                            color="rgba(255, 255, 255, 0.7)" 
                          />
                        </Pressable>
                      </View>

                      <Pressable style={styles.forgotPasswordButton} onPress={handleForgotPassword}>
                        <Text style={styles.forgotPasswordText}>Mot de passe oublié ?</Text>
                      </Pressable>

                      <Pressable 
                        style={[styles.loginButton, loading && styles.loginButtonDisabled]} 
                        onPress={handleLogin}
                        disabled={loading}
                      >
                        <LinearGradient
                          colors={['#2962FF', '#1E88E5']}
                          style={styles.loginButtonGradient}
                        >
                          {loading ? (
                            <View style={styles.loadingContainer}>
                              <Text style={styles.loginButtonText}>Connexion...</Text>
                              <View style={styles.loadingDot} />
                            </View>
                          ) : (
                            <>
                              <Text style={styles.loginButtonText}>Se connecter</Text>
                              <IconSymbol name="arrow.right" size={20} color="#FFFFFF" />
                            </>
                          )}
                        </LinearGradient>
                      </Pressable>
                    </View>

                    <View style={styles.divider}>
                      <View style={styles.dividerLine} />
                      <Text style={styles.dividerText}>ou</Text>
                      <View style={styles.dividerLine} />
                    </View>

                    <View style={styles.socialContainer}>
                      <Pressable 
                        style={styles.socialButton} 
                        onPress={() => handleSocialLogin('Google')}
                      >
                        <IconSymbol name="globe" size={20} color="#FFFFFF" />
                        <Text style={styles.socialButtonText}>Google</Text>
                      </Pressable>

                      <Pressable 
                        style={styles.socialButton} 
                        onPress={() => handleSocialLogin('Apple')}
                      >
                        <IconSymbol name="apple.logo" size={20} color="#FFFFFF" />
                        <Text style={styles.socialButtonText}>Apple</Text>
                      </Pressable>
                    </View>

                    <View style={styles.footer}>
                      <Text style={styles.footerText}>Pas encore de compte ?</Text>
                      <Pressable onPress={() => router.replace('/signup')}>
                        <Text style={styles.signupLink}>Créer un compte</Text>
                      </Pressable>
                    </View>
                  </BlurView>
                </View>
              </ScrollView>
            </KeyboardAvoidingView>
          </SafeAreaView>
        </LinearGradient>
      </ImageBackground>
    </>
  );
}

const styles = StyleSheet.create({
  backgroundImage: {
    flex: 1,
  },
  overlay: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
  },
  keyboardView: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    minHeight: height,
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: Platform.OS === 'ios' ? 10 : 20,
    paddingBottom: 20,
  },
  backButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    alignItems: 'center',
    justifyContent: 'center',
    backdropFilter: 'blur(10px)',
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
    justifyContent: 'center',
    paddingBottom: 40,
  },
  logoSection: {
    alignItems: 'center',
    marginBottom: 40,
  },
  logoContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
    backdropFilter: 'blur(10px)',
  },
  brandTitle: {
    fontSize: 32,
    fontWeight: '900',
    color: '#FFFFFF',
    marginBottom: 8,
    textAlign: 'center',
    letterSpacing: 1,
  },
  brandSubtitle: {
    fontSize: 16,
    color: 'rgba(255, 255, 255, 0.8)',
    textAlign: 'center',
    fontWeight: '500',
  },
  formCard: {
    borderRadius: 24,
    padding: 24,
    overflow: 'hidden',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
  },
  welcomeSection: {
    alignItems: 'center',
    marginBottom: 32,
  },
  welcomeTitle: {
    fontSize: 28,
    fontWeight: '800',
    color: '#FFFFFF',
    marginBottom: 8,
  },
  welcomeSubtitle: {
    fontSize: 16,
    color: 'rgba(255, 255, 255, 0.8)',
    textAlign: 'center',
    lineHeight: 22,
  },
  formContainer: {
    gap: 20,
    marginBottom: 24,
  },
  inputContainer: {
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    borderRadius: 16,
    paddingHorizontal: 16,
    paddingVertical: 16,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  inputContainerFocused: {
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderColor: '#2962FF',
    boxShadow: '0px 0px 20px rgba(41, 98, 255, 0.3)',
  },
  input: {
    flex: 1,
    fontSize: 16,
    color: '#FFFFFF',
    fontWeight: '500',
  },
  forgotPasswordButton: {
    alignSelf: 'flex-end',
    paddingVertical: 4,
  },
  forgotPasswordText: {
    fontSize: 14,
    color: 'rgba(255, 255, 255, 0.8)',
    fontWeight: '600',
  },
  loginButton: {
    borderRadius: 16,
    overflow: 'hidden',
    marginTop: 8,
  },
  loginButtonGradient: {
    paddingVertical: 18,
    paddingHorizontal: 24,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
  },
  loginButtonDisabled: {
    opacity: 0.7,
  },
  loginButtonText: {
    fontSize: 18,
    fontWeight: '700',
    color: '#FFFFFF',
  },
  loadingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  loadingDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#FFFFFF',
  },
  divider: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 24,
    gap: 16,
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
  },
  dividerText: {
    fontSize: 14,
    color: 'rgba(255, 255, 255, 0.7)',
    fontWeight: '500',
  },
  socialContainer: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 24,
  },
  socialButton: {
    flex: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    borderRadius: 12,
    paddingVertical: 14,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  socialButtonText: {
    fontSize: 16,
    color: '#FFFFFF',
    fontWeight: '600',
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
    paddingTop: 8,
  },
  footerText: {
    fontSize: 14,
    color: 'rgba(255, 255, 255, 0.8)',
  },
  signupLink: {
    fontSize: 14,
    color: '#2962FF',
    fontWeight: '700',
  },
});
