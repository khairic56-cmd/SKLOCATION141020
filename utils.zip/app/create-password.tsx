
import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  Pressable, 
  SafeAreaView,
  Platform,
  TextInput,
  Alert,
  KeyboardAvoidingView,
  ScrollView
} from 'react-native';
import { Stack, router } from 'expo-router';
import { IconSymbol } from '@/components/IconSymbol';
import { colors } from '@/styles/commonStyles';
import { LinearGradient } from 'expo-linear-gradient';

export default function CreatePasswordScreen() {
  console.log('CreatePasswordScreen rendered');
  
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const validatePassword = (pwd: string) => {
    const minLength = pwd.length >= 8;
    const hasUpperCase = /[A-Z]/.test(pwd);
    const hasLowerCase = /[a-z]/.test(pwd);
    const hasNumbers = /\d/.test(pwd);
    const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(pwd);
    
    return {
      minLength,
      hasUpperCase,
      hasLowerCase,
      hasNumbers,
      hasSpecialChar,
      isValid: minLength && hasUpperCase && hasLowerCase && hasNumbers && hasSpecialChar
    };
  };

  const passwordValidation = validatePassword(password);

  const handleCreatePassword = async () => {
    console.log('Create password attempt');
    
    if (!password || !confirmPassword) {
      Alert.alert('Erreur', 'Veuillez remplir tous les champs');
      return;
    }

    if (!passwordValidation.isValid) {
      Alert.alert('Erreur', 'Le mot de passe ne respecte pas les critères de sécurité');
      return;
    }

    if (password !== confirmPassword) {
      Alert.alert('Erreur', 'Les mots de passe ne correspondent pas');
      return;
    }

    setLoading(true);
    
    try {
      // TODO: Implement Supabase password creation
      console.log('Password creation logic would be implemented here with Supabase');
      
      // Simulate password creation delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      Alert.alert(
        'Mot de passe créé !', 
        'Votre mot de passe a été créé avec succès. Vous allez être redirigé vers la page de connexion.',
        [
          { 
            text: 'OK', 
            onPress: () => {
              router.replace('/login');
            }
          }
        ]
      );
    } catch (error) {
      console.log('Create password error:', error);
      Alert.alert('Erreur', 'Une erreur est survenue lors de la création du mot de passe');
    } finally {
      setLoading(false);
    }
  };

  const handleBack = () => {
    console.log('Back button pressed');
    router.back();
  };

  return (
    <>
      <Stack.Screen
        options={{
          title: "Créer un mot de passe",
          headerShown: false,
        }}
      />
      <LinearGradient
        colors={[colors.primary, colors.secondary]}
        style={styles.container}
      >
        <SafeAreaView style={styles.safeArea}>
          <KeyboardAvoidingView 
            style={styles.keyboardView}
            behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          >
            <ScrollView contentContainerStyle={styles.scrollContent}>
              <View style={styles.header}>
                <Pressable style={styles.backButton} onPress={handleBack}>
                  <IconSymbol name="chevron.left" size={24} color={colors.card} />
                </Pressable>
                <Text style={styles.title}>Créer un mot de passe</Text>
              </View>

              <View style={styles.content}>
                <View style={styles.welcomeSection}>
                  <IconSymbol name="lock.shield" size={60} color={colors.card} />
                  <Text style={styles.welcomeTitle}>Sécurisez votre compte</Text>
                  <Text style={styles.welcomeSubtitle}>
                    Créez un mot de passe fort pour protéger votre compte SK LOC14
                  </Text>
                </View>

                <View style={styles.formContainer}>
                  <View style={styles.inputContainer}>
                    <IconSymbol name="lock" size={20} color={colors.textSecondary} />
                    <TextInput
                      style={styles.input}
                      placeholder="Nouveau mot de passe"
                      placeholderTextColor={colors.textSecondary}
                      value={password}
                      onChangeText={setPassword}
                      secureTextEntry={!showPassword}
                      autoCapitalize="none"
                      autoCorrect={false}
                    />
                    <Pressable onPress={() => setShowPassword(!showPassword)}>
                      <IconSymbol 
                        name={showPassword ? "eye.slash" : "eye"} 
                        size={20} 
                        color={colors.textSecondary} 
                      />
                    </Pressable>
                  </View>

                  <View style={styles.inputContainer}>
                    <IconSymbol name="lock" size={20} color={colors.textSecondary} />
                    <TextInput
                      style={styles.input}
                      placeholder="Confirmer le mot de passe"
                      placeholderTextColor={colors.textSecondary}
                      value={confirmPassword}
                      onChangeText={setConfirmPassword}
                      secureTextEntry={!showConfirmPassword}
                      autoCapitalize="none"
                      autoCorrect={false}
                    />
                    <Pressable onPress={() => setShowConfirmPassword(!showConfirmPassword)}>
                      <IconSymbol 
                        name={showConfirmPassword ? "eye.slash" : "eye"} 
                        size={20} 
                        color={colors.textSecondary} 
                      />
                    </Pressable>
                  </View>

                  <View style={styles.validationContainer}>
                    <Text style={styles.validationTitle}>Critères de sécurité :</Text>
                    
                    <View style={styles.validationItem}>
                      <IconSymbol 
                        name={passwordValidation.minLength ? "checkmark.circle.fill" : "circle"} 
                        size={16} 
                        color={passwordValidation.minLength ? colors.accent : colors.card} 
                      />
                      <Text style={[
                        styles.validationText,
                        passwordValidation.minLength && styles.validationTextValid
                      ]}>
                        Au moins 8 caractères
                      </Text>
                    </View>

                    <View style={styles.validationItem}>
                      <IconSymbol 
                        name={passwordValidation.hasUpperCase ? "checkmark.circle.fill" : "circle"} 
                        size={16} 
                        color={passwordValidation.hasUpperCase ? colors.accent : colors.card} 
                      />
                      <Text style={[
                        styles.validationText,
                        passwordValidation.hasUpperCase && styles.validationTextValid
                      ]}>
                        Une lettre majuscule
                      </Text>
                    </View>

                    <View style={styles.validationItem}>
                      <IconSymbol 
                        name={passwordValidation.hasLowerCase ? "checkmark.circle.fill" : "circle"} 
                        size={16} 
                        color={passwordValidation.hasLowerCase ? colors.accent : colors.card} 
                      />
                      <Text style={[
                        styles.validationText,
                        passwordValidation.hasLowerCase && styles.validationTextValid
                      ]}>
                        Une lettre minuscule
                      </Text>
                    </View>

                    <View style={styles.validationItem}>
                      <IconSymbol 
                        name={passwordValidation.hasNumbers ? "checkmark.circle.fill" : "circle"} 
                        size={16} 
                        color={passwordValidation.hasNumbers ? colors.accent : colors.card} 
                      />
                      <Text style={[
                        styles.validationText,
                        passwordValidation.hasNumbers && styles.validationTextValid
                      ]}>
                        Un chiffre
                      </Text>
                    </View>

                    <View style={styles.validationItem}>
                      <IconSymbol 
                        name={passwordValidation.hasSpecialChar ? "checkmark.circle.fill" : "circle"} 
                        size={16} 
                        color={passwordValidation.hasSpecialChar ? colors.accent : colors.card} 
                      />
                      <Text style={[
                        styles.validationText,
                        passwordValidation.hasSpecialChar && styles.validationTextValid
                      ]}>
                        Un caractère spécial
                      </Text>
                    </View>
                  </View>

                  <Pressable 
                    style={[
                      styles.createButton, 
                      (loading || !passwordValidation.isValid) && styles.createButtonDisabled
                    ]} 
                    onPress={handleCreatePassword}
                    disabled={loading || !passwordValidation.isValid}
                  >
                    {loading ? (
                      <Text style={styles.createButtonText}>Création...</Text>
                    ) : (
                      <>
                        <Text style={styles.createButtonText}>Créer le mot de passe</Text>
                        <IconSymbol name="arrow.right" size={20} color={colors.primary} />
                      </>
                    )}
                  </Pressable>
                </View>
              </View>
            </ScrollView>
          </KeyboardAvoidingView>
        </SafeAreaView>
      </LinearGradient>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
  },
  keyboardView: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: Platform.OS === 'ios' ? 10 : 20,
    paddingBottom: 20,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    flex: 1,
    fontSize: 20,
    fontWeight: '800',
    color: colors.card,
    textAlign: 'center',
    marginRight: 40,
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
    justifyContent: 'center',
  },
  welcomeSection: {
    alignItems: 'center',
    marginBottom: 40,
  },
  welcomeTitle: {
    fontSize: 28,
    fontWeight: '800',
    color: colors.card,
    marginTop: 16,
    marginBottom: 8,
  },
  welcomeSubtitle: {
    fontSize: 16,
    color: colors.card,
    textAlign: 'center',
    opacity: 0.9,
    lineHeight: 22,
  },
  formContainer: {
    gap: 20,
  },
  inputContainer: {
    backgroundColor: colors.card,
    borderRadius: 15,
    paddingHorizontal: 16,
    paddingVertical: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    boxShadow: '0px 2px 10px rgba(0, 0, 0, 0.1)',
    elevation: 2,
  },
  input: {
    flex: 1,
    fontSize: 16,
    color: colors.text,
  },
  validationContainer: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 15,
    padding: 16,
    gap: 8,
  },
  validationTitle: {
    fontSize: 14,
    fontWeight: '700',
    color: colors.card,
    marginBottom: 4,
  },
  validationItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  validationText: {
    fontSize: 12,
    color: colors.card,
    opacity: 0.7,
  },
  validationTextValid: {
    opacity: 1,
    fontWeight: '600',
  },
  createButton: {
    backgroundColor: colors.card,
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 25,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
    boxShadow: '0px 4px 15px rgba(0, 0, 0, 0.1)',
    elevation: 4,
    marginTop: 8,
  },
  createButtonDisabled: {
    opacity: 0.5,
  },
  createButtonText: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.primary,
  },
});
