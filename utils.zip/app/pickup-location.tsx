
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  SafeAreaView,
  Platform,
  Alert,
  ScrollView,
  ImageBackground,
  TextInput,
} from 'react-native';
import { Stack, router, useLocalSearchParams } from 'expo-router';
import { IconSymbol } from '@/components/IconSymbol';
import { colors } from '@/styles/commonStyles';
import { BlurView } from 'expo-blur';
import { supabase } from '@/app/integrations/supabase/client';
import type { Tables } from '@/app/integrations/supabase/types';

export default function PickupLocationScreen() {
  const params = useLocalSearchParams();
  const [pickupLocations, setPickupLocations] = useState<Tables<'pickup_locations'>[]>([]);
  const [selectedPickupLocation, setSelectedPickupLocation] = useState<Tables<'pickup_locations'> | null>(null);
  const [pickupOption, setPickupOption] = useState<'pickup' | 'delivery'>('pickup');
  const [customDeliveryAddress, setCustomDeliveryAddress] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadPickupLocations();
  }, []);

  const loadPickupLocations = async () => {
    try {
      const { data, error } = await supabase
        .from('pickup_locations')
        .select('*')
        .eq('is_active', true)
        .order('name');
      
      if (error) throw error;
      setPickupLocations(data || []);
    } catch (error) {
      console.error('Error loading pickup locations:', error);
      Alert.alert('Erreur', 'Impossible de charger les lieux de récupération');
    } finally {
      setLoading(false);
    }
  };

  const handleConfirm = () => {
    if (pickupOption === 'pickup' && !selectedPickupLocation) {
      Alert.alert('Erreur', 'Veuillez sélectionner un lieu de récupération.');
      return;
    }

    if (pickupOption === 'delivery' && !customDeliveryAddress.trim()) {
      Alert.alert('Erreur', 'Veuillez entrer une adresse de livraison.');
      return;
    }

    // Navigate to summary page with pickup information
    const pickupData = {
      pickupOption,
      pickupLocation: pickupOption === 'pickup' ? selectedPickupLocation?.name : 'Livraison à domicile',
      deliveryAddress: pickupOption === 'delivery' ? customDeliveryAddress : null,
      deliveryFee: pickupOption === 'delivery' ? 25 : 0,
    };

    router.push({
      pathname: '/booking-summary',
      params: {
        ...params,
        ...pickupData,
      },
    });
  };

  if (loading) {
    return (
      <ImageBackground 
        source={require('@/assets/images/285c86af-6344-4f73-beac-dbfa2112b685.jpeg')}
        style={styles.container}
        resizeMode="cover"
      >
        <SafeAreaView style={styles.safeArea}>
          <View style={styles.loadingContainer}>
            <Text style={styles.loadingText}>Chargement...</Text>
          </View>
        </SafeAreaView>
      </ImageBackground>
    );
  }

  return (
    <ImageBackground 
      source={require('@/assets/images/285c86af-6344-4f73-beac-dbfa2112b685.jpeg')}
      style={styles.container}
      resizeMode="cover"
    >
      <SafeAreaView style={styles.safeArea}>
        <Stack.Screen
          options={{
            title: "Lieu de récupération",
            headerShown: true,
            headerStyle: { backgroundColor: 'transparent' },
            headerTintColor: '#FFFFFF',
            headerTitleStyle: { fontWeight: '700', fontSize: 20 },
            headerLeft: () => (
              <Pressable onPress={() => router.back()} style={styles.headerBackButton}>
                <IconSymbol name="chevron.left" color="#FFFFFF" size={24} />
              </Pressable>
            ),
            headerBackground: () => (
              <BlurView 
                intensity={10} 
                tint="dark" 
                style={[StyleSheet.absoluteFill, Platform.OS !== 'ios' && { backgroundColor: 'rgba(0,0,0,0.1)' }]} 
              />
            ),
          }}
        />
        
        <ScrollView style={styles.scrollView} contentContainerStyle={styles.scrollContent}>
          <BlurView intensity={5} tint="extraLight" style={[styles.container, Platform.OS !== 'ios' && { backgroundColor: 'rgba(255,255,255,0.05)' }]}>
            <Text style={styles.sectionTitle}>Choisissez votre mode de récupération</Text>
            
            {/* Pickup Option */}
            <Pressable 
              style={[styles.pickupOptionButton, pickupOption === 'pickup' && styles.selectedPickupOption]}
              onPress={() => setPickupOption('pickup')}
            >
              <IconSymbol 
                name="location.fill" 
                color={pickupOption === 'pickup' ? colors.card : colors.primary} 
                size={24} 
              />
              <Text style={[styles.pickupOptionText, pickupOption === 'pickup' && styles.selectedPickupOptionText]}>
                Récupération en agence
              </Text>
            </Pressable>

            {pickupOption === 'pickup' && (
              <View style={styles.pickupLocationsList}>
                <Text style={styles.locationsTitle}>Sélectionnez une agence :</Text>
                {pickupLocations.map((location) => (
                  <Pressable
                    key={location.id}
                    style={[styles.locationOption, selectedPickupLocation?.id === location.id && styles.selectedLocation]}
                    onPress={() => setSelectedPickupLocation(location)}
                  >
                    <IconSymbol 
                      name={selectedPickupLocation?.id === location.id ? "checkmark.circle.fill" : "circle"} 
                      color={selectedPickupLocation?.id === location.id ? colors.primary : '#FFFFFF'} 
                      size={20} 
                    />
                    <View style={styles.locationInfo}>
                      <Text style={[styles.locationName, selectedPickupLocation?.id === location.id && styles.selectedLocationText]}>
                        {location.name}
                      </Text>
                      <Text style={styles.locationAddress}>
                        {location.address}, {location.city}
                      </Text>
                      {location.phone && (
                        <Text style={styles.locationPhone}>
                          📞 {location.phone}
                        </Text>
                      )}
                    </View>
                  </Pressable>
                ))}
              </View>
            )}

            {/* Delivery Option */}
            <Pressable 
              style={[styles.pickupOptionButton, pickupOption === 'delivery' && styles.selectedPickupOption]}
              onPress={() => setPickupOption('delivery')}
            >
              <IconSymbol 
                name="car.fill" 
                color={pickupOption === 'delivery' ? colors.card : colors.primary} 
                size={24} 
              />
              <Text style={[styles.pickupOptionText, pickupOption === 'delivery' && styles.selectedPickupOptionText]}>
                Livraison à domicile
              </Text>
            </Pressable>

            {pickupOption === 'delivery' && (
              <View style={styles.deliverySection}>
                <Text style={styles.deliveryWarning}>
                  ⚠️ Des frais de livraison de 25€ seront ajoutés à votre réservation
                </Text>
                <Text style={styles.deliveryNote}>
                  Notre équipe vous livrera le véhicule à l'adresse indiquée dans un rayon de 30km autour de Caen.
                </Text>
                <TextInput
                  style={styles.addressInput}
                  value={customDeliveryAddress}
                  onChangeText={setCustomDeliveryAddress}
                  placeholder="Entrez votre adresse complète de livraison"
                  placeholderTextColor="#CCCCCC"
                  multiline
                />
              </View>
            )}

            <View style={styles.buttonContainer}>
              <Pressable style={styles.backButton} onPress={() => router.back()}>
                <IconSymbol name="chevron.left" color={colors.primary} size={20} />
                <Text style={styles.backButtonText}>Retour</Text>
              </Pressable>
              
              <Pressable style={styles.continueButton} onPress={handleConfirm}>
                <Text style={styles.continueButtonText}>Continuer</Text>
                <IconSymbol name="arrow.right.circle.fill" color={colors.card} size={20} />
              </Pressable>
            </View>
          </BlurView>
        </ScrollView>
      </SafeAreaView>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
  },
  headerBackButton: {
    padding: 8,
    marginLeft: -8,
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
    borderRadius: 20,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    fontSize: 18,
    color: '#FFFFFF',
    fontWeight: '600',
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#FFFFFF',
    marginBottom: 24,
    textAlign: 'center',
  },
  pickupOptionButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    borderWidth: 2,
    borderColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  selectedPickupOption: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },
  pickupOptionText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
    marginLeft: 12,
  },
  selectedPickupOptionText: {
    color: colors.card,
  },
  pickupLocationsList: {
    marginBottom: 24,
  },
  locationsTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
    marginBottom: 12,
  },
  locationOption: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.15)',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  selectedLocation: {
    backgroundColor: 'rgba(33, 150, 243, 0.2)',
    borderColor: colors.primary,
  },
  locationInfo: {
    flex: 1,
    marginLeft: 12,
  },
  locationName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  selectedLocationText: {
    color: '#FFFFFF',
  },
  locationAddress: {
    fontSize: 14,
    color: '#CCCCCC',
    marginBottom: 2,
  },
  locationPhone: {
    fontSize: 12,
    color: '#CCCCCC',
  },
  deliverySection: {
    marginBottom: 24,
  },
  deliveryWarning: {
    fontSize: 14,
    color: '#FFFFFF',
    backgroundColor: 'rgba(255, 183, 77, 0.2)',
    padding: 12,
    borderRadius: 8,
    marginBottom: 12,
    textAlign: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255, 183, 77, 0.3)',
  },
  deliveryNote: {
    fontSize: 14,
    color: '#FFFFFF',
    marginBottom: 16,
    lineHeight: 20,
  },
  addressInput: {
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    borderWidth: 2,
    borderColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 12,
    padding: 16,
    fontSize: 16,
    color: '#FFFFFF',
    minHeight: 100,
    textAlignVertical: 'top',
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    gap: 16,
    marginTop: 24,
  },
  backButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: 'rgba(255, 255, 255, 0.15)',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
  },
  backButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
    marginLeft: 8,
  },
  continueButton: {
    backgroundColor: colors.primary,
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    flex: 2,
  },
  continueButtonText: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.card,
    marginRight: 8,
  },
});
