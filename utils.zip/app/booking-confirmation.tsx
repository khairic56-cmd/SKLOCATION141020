
import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  SafeAreaView,
  Platform,
  ScrollView,
  ImageBackground,
  Linking,
} from 'react-native';
import { Stack, router, useLocalSearchParams } from 'expo-router';
import { IconSymbol } from '@/components/IconSymbol';
import { colors } from '@/styles/commonStyles';
import { BlurView } from 'expo-blur';

export default function BookingConfirmationScreen() {
  const params = useLocalSearchParams();
  
  const bookingId = params.bookingId as string;
  const email = params.email as string;
  const totalPrice = parseFloat(params.totalPrice as string);
  const depositAmount = parseFloat(params.depositAmount as string);
  const paymentMethod = params.paymentMethod as string;

  const getPaymentMethodText = (method: string) => {
    switch (method) {
      case 'credit_card':
        return 'Carte bancaire';
      case 'bank_transfer':
        return 'Virement bancaire';
      case 'phone_confirmation':
        return 'Confirmation téléphonique';
      default:
        return method;
    }
  };

  const handleCallSupport = () => {
    const phoneNumber = '066145612';
    const url = `tel:${phoneNumber}`;
    
    Linking.canOpenURL(url)
      .then((supported) => {
        if (supported) {
          return Linking.openURL(url);
        } else {
          console.log('Cannot open phone app');
        }
      })
      .catch((err) => console.error('Error opening phone app:', err));
  };

  const handleEmailSupport = () => {
    const email = 'contact@sklocation14.fr';
    const subject = `Réservation ${bookingId.slice(-8).toUpperCase()}`;
    const url = `mailto:${email}?subject=${encodeURIComponent(subject)}`;
    
    Linking.canOpenURL(url)
      .then((supported) => {
        if (supported) {
          return Linking.openURL(url);
        } else {
          console.log('Cannot open email app');
        }
      })
      .catch((err) => console.error('Error opening email app:', err));
  };

  return (
    <ImageBackground 
      source={require('@/assets/images/285c86af-6344-4f73-beac-dbfa2112b685.jpeg')}
      style={styles.container}
      resizeMode="cover"
    >
      <SafeAreaView style={styles.safeArea}>
        <Stack.Screen
          options={{
            title: "Confirmation",
            headerShown: true,
            headerStyle: { backgroundColor: 'transparent' },
            headerTintColor: '#FFFFFF',
            headerTitleStyle: { fontWeight: '700', fontSize: 20 },
            headerLeft: () => null, // Remove back button on confirmation page
            headerBackground: () => (
              <BlurView 
                intensity={10} 
                tint="dark" 
                style={[StyleSheet.absoluteFill, Platform.OS !== 'ios' && { backgroundColor: 'rgba(0,0,0,0.1)' }]} 
              />
            ),
          }}
        />
        
        <ScrollView style={styles.scrollView} contentContainerStyle={styles.scrollContent}>
          <BlurView intensity={5} tint="extraLight" style={[styles.confirmationContainer, Platform.OS !== 'ios' && { backgroundColor: 'rgba(255,255,255,0.05)' }]}>
            <IconSymbol name="checkmark.circle.fill" color={colors.secondary} size={80} />
            
            <Text style={styles.confirmationTitle}>Réservation confirmée !</Text>
            <Text style={styles.confirmationSubtitle}>
              Votre réservation a été enregistrée avec succès.
            </Text>
            
            <View style={styles.confirmationDetails}>
              <View style={styles.detailRow}>
                <Text style={styles.confirmationLabel}>Référence de réservation:</Text>
                <Text style={styles.confirmationValue}>{bookingId.slice(-8).toUpperCase()}</Text>
              </View>
              
              <View style={styles.detailRow}>
                <Text style={styles.confirmationLabel}>Email de confirmation:</Text>
                <Text style={styles.confirmationValue}>{email}</Text>
              </View>
              
              <View style={styles.detailRow}>
                <Text style={styles.confirmationLabel}>Mode de paiement:</Text>
                <Text style={styles.confirmationValue}>{getPaymentMethodText(paymentMethod)}</Text>
              </View>
              
              <View style={styles.detailRow}>
                <Text style={styles.confirmationLabel}>Montant total:</Text>
                <Text style={styles.confirmationValue}>{totalPrice}€</Text>
              </View>
              
              <View style={styles.detailRow}>
                <Text style={styles.confirmationLabel}>Acompte versé:</Text>
                <Text style={styles.confirmationValueHighlight}>{depositAmount}€</Text>
              </View>
              
              <View style={styles.detailRow}>
                <Text style={styles.confirmationLabel}>Solde restant:</Text>
                <Text style={styles.confirmationValue}>{totalPrice - depositAmount}€</Text>
              </View>
            </View>

            <View style={styles.emailNotice}>
              <IconSymbol name="envelope.fill" color={colors.primary} size={24} />
              <Text style={styles.emailNoticeText}>
                Un email de confirmation avec tous les détails de votre réservation vous a été envoyé à l'adresse {email}.
              </Text>
            </View>

            <View style={styles.importantInfo}>
              <Text style={styles.importantTitle}>Informations importantes</Text>
              <View style={styles.infoList}>
                <Text style={styles.infoItem}>
                  • Veuillez vous présenter avec une pièce d'identité valide et votre permis de conduire
                </Text>
                <Text style={styles.infoItem}>
                  • Le solde restant ({totalPrice - depositAmount}€) sera à régler lors de la récupération du véhicule
                </Text>
                <Text style={styles.infoItem}>
                  • En cas d'annulation, veuillez nous contacter au moins 24h à l'avance
                </Text>
                <Text style={styles.infoItem}>
                  • Le véhicule doit être rendu avec le même niveau de carburant
                </Text>
              </View>
            </View>

            <View style={styles.contactSection}>
              <Text style={styles.contactTitle}>Besoin d'aide ?</Text>
              <Text style={styles.contactSubtitle}>
                Notre équipe est à votre disposition pour toute question
              </Text>
              
              <View style={styles.contactButtons}>
                <Pressable style={styles.contactButton} onPress={handleCallSupport}>
                  <IconSymbol name="phone.fill" color={colors.card} size={20} />
                  <Text style={styles.contactButtonText}>066145612</Text>
                </Pressable>
                
                <Pressable style={styles.contactButton} onPress={handleEmailSupport}>
                  <IconSymbol name="envelope.fill" color={colors.card} size={20} />
                  <Text style={styles.contactButtonText}>Nous écrire</Text>
                </Pressable>
              </View>
            </View>

            <View style={styles.actionButtons}>
              <Pressable style={styles.homeButton} onPress={() => router.push('/(tabs)/(home)')}>
                <IconSymbol name="house.fill" color={colors.card} size={20} />
                <Text style={styles.homeButtonText}>Retour à l'accueil</Text>
              </Pressable>
              
              <Pressable style={styles.bookingsButton} onPress={() => router.push('/profile-menu')}>
                <IconSymbol name="calendar" color={colors.primary} size={20} />
                <Text style={styles.bookingsButtonText}>Mes réservations</Text>
              </Pressable>
            </View>
          </BlurView>
        </ScrollView>
      </SafeAreaView>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
  },
  confirmationContainer: {
    borderRadius: 16,
    padding: 32,
    alignItems: 'center',
    boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.3)',
    elevation: 8,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
    overflow: 'hidden',
  },
  confirmationTitle: {
    fontSize: 24,
    fontWeight: '800',
    color: '#FFFFFF',
    textAlign: 'center',
    marginTop: 16,
    marginBottom: 8,
  },
  confirmationSubtitle: {
    fontSize: 16,
    color: '#FFFFFF',
    textAlign: 'center',
    marginBottom: 24,
    lineHeight: 22,
  },
  confirmationDetails: {
    width: '100%',
    marginBottom: 24,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 16,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  confirmationLabel: {
    fontSize: 14,
    color: '#CCCCCC',
    flex: 1,
  },
  confirmationValue: {
    fontSize: 14,
    fontWeight: '600',
    color: '#FFFFFF',
    textAlign: 'right',
    flex: 1,
  },
  confirmationValueHighlight: {
    fontSize: 14,
    fontWeight: '700',
    color: colors.primary,
    textAlign: 'right',
    flex: 1,
  },
  emailNotice: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    backgroundColor: 'rgba(33, 150, 243, 0.1)',
    padding: 16,
    borderRadius: 12,
    marginBottom: 24,
    borderWidth: 1,
    borderColor: 'rgba(33, 150, 243, 0.2)',
    width: '100%',
  },
  emailNoticeText: {
    fontSize: 14,
    color: '#FFFFFF',
    marginLeft: 12,
    flex: 1,
    lineHeight: 20,
  },
  importantInfo: {
    width: '100%',
    marginBottom: 24,
    backgroundColor: 'rgba(255, 183, 77, 0.1)',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: 'rgba(255, 183, 77, 0.2)',
  },
  importantTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#FFFFFF',
    marginBottom: 12,
  },
  infoList: {
    gap: 8,
  },
  infoItem: {
    fontSize: 14,
    color: '#FFFFFF',
    lineHeight: 20,
  },
  contactSection: {
    width: '100%',
    alignItems: 'center',
    marginBottom: 24,
  },
  contactTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#FFFFFF',
    marginBottom: 8,
  },
  contactSubtitle: {
    fontSize: 14,
    color: '#CCCCCC',
    textAlign: 'center',
    marginBottom: 16,
  },
  contactButtons: {
    flexDirection: 'row',
    gap: 12,
    width: '100%',
  },
  contactButton: {
    backgroundColor: colors.primary,
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
  },
  contactButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.card,
    marginLeft: 8,
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 12,
    width: '100%',
  },
  homeButton: {
    backgroundColor: colors.primary,
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    flex: 2,
  },
  homeButtonText: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.card,
    marginLeft: 8,
  },
  bookingsButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: 'rgba(255, 255, 255, 0.15)',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
  },
  bookingsButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
    marginLeft: 8,
  },
});
