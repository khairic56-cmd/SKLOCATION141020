
import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  Pressable, 
  SafeAreaView,
  Platform,
  TextInput,
  Alert,
  KeyboardAvoidingView,
  ScrollView
} from 'react-native';
import { Stack, router } from 'expo-router';
import { IconSymbol } from '@/components/IconSymbol';
import { colors } from '@/styles/commonStyles';
import { LinearGradient } from 'expo-linear-gradient';

export default function ForgotPasswordScreen() {
  console.log('ForgotPasswordScreen rendered');
  
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [emailSent, setEmailSent] = useState(false);

  const handleResetPassword = async () => {
    console.log('Reset password attempt with email:', email);
    
    if (!email) {
      Alert.alert('Erreur', 'Veuillez entrer votre adresse email');
      return;
    }

    if (!email.includes('@')) {
      Alert.alert('Erreur', 'Veuillez entrer une adresse email valide');
      return;
    }

    setLoading(true);
    
    try {
      // TODO: Implement Supabase password reset
      console.log('Password reset logic would be implemented here with Supabase');
      
      // Simulate email sending delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setEmailSent(true);
      
      Alert.alert(
        'Fonctionnalité à venir', 
        'Pour activer la réinitialisation de mot de passe, veuillez connecter Supabase. Un email sera automatiquement envoyé avec un lien de réinitialisation.',
        [
          { text: 'OK', onPress: () => router.back() }
        ]
      );
    } catch (error) {
      console.log('Reset password error:', error);
      Alert.alert('Erreur', 'Une erreur est survenue lors de l\'envoi de l\'email');
    } finally {
      setLoading(false);
    }
  };

  const handleBack = () => {
    console.log('Back button pressed');
    router.back();
  };

  return (
    <>
      <Stack.Screen
        options={{
          title: "Mot de passe oublié",
          headerShown: false,
        }}
      />
      <LinearGradient
        colors={[colors.primary, colors.secondary]}
        style={styles.container}
      >
        <SafeAreaView style={styles.safeArea}>
          <KeyboardAvoidingView 
            style={styles.keyboardView}
            behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          >
            <ScrollView contentContainerStyle={styles.scrollContent}>
              <View style={styles.header}>
                <Pressable style={styles.backButton} onPress={handleBack}>
                  <IconSymbol name="chevron.left" size={24} color={colors.card} />
                </Pressable>
                <Text style={styles.title}>Mot de passe oublié</Text>
              </View>

              <View style={styles.content}>
                <View style={styles.welcomeSection}>
                  <IconSymbol name="key.fill" size={60} color={colors.card} />
                  <Text style={styles.welcomeTitle}>
                    {emailSent ? 'Email envoyé !' : 'Récupération'}
                  </Text>
                  <Text style={styles.welcomeSubtitle}>
                    {emailSent 
                      ? 'Vérifiez votre boîte email et suivez les instructions pour réinitialiser votre mot de passe'
                      : 'Entrez votre adresse email pour recevoir un lien de réinitialisation'
                    }
                  </Text>
                </View>

                {!emailSent && (
                  <View style={styles.formContainer}>
                    <View style={styles.inputContainer}>
                      <IconSymbol name="envelope" size={20} color={colors.textSecondary} />
                      <TextInput
                        style={styles.input}
                        placeholder="Adresse email"
                        placeholderTextColor={colors.textSecondary}
                        value={email}
                        onChangeText={setEmail}
                        keyboardType="email-address"
                        autoCapitalize="none"
                        autoCorrect={false}
                      />
                    </View>

                    <Pressable 
                      style={[styles.resetButton, loading && styles.resetButtonDisabled]} 
                      onPress={handleResetPassword}
                      disabled={loading}
                    >
                      {loading ? (
                        <Text style={styles.resetButtonText}>Envoi...</Text>
                      ) : (
                        <>
                          <Text style={styles.resetButtonText}>Envoyer le lien</Text>
                          <IconSymbol name="paperplane.fill" size={20} color={colors.primary} />
                        </>
                      )}
                    </Pressable>
                  </View>
                )}

                {emailSent && (
                  <View style={styles.successContainer}>
                    <View style={styles.successIcon}>
                      <IconSymbol name="checkmark.circle.fill" size={80} color={colors.accent} />
                    </View>
                    <Pressable 
                      style={styles.backToLoginButton}
                      onPress={() => router.replace('/login')}
                    >
                      <Text style={styles.backToLoginText}>Retour à la connexion</Text>
                    </Pressable>
                  </View>
                )}

                <View style={styles.footer}>
                  <Text style={styles.footerText}>Vous vous souvenez de votre mot de passe ?</Text>
                  <Pressable onPress={() => router.replace('/login')}>
                    <Text style={styles.loginLink}>Se connecter</Text>
                  </Pressable>
                </View>
              </View>
            </ScrollView>
          </KeyboardAvoidingView>
        </SafeAreaView>
      </LinearGradient>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
  },
  keyboardView: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: Platform.OS === 'ios' ? 10 : 20,
    paddingBottom: 20,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    flex: 1,
    fontSize: 20,
    fontWeight: '800',
    color: colors.card,
    textAlign: 'center',
    marginRight: 40,
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
    justifyContent: 'center',
  },
  welcomeSection: {
    alignItems: 'center',
    marginBottom: 40,
  },
  welcomeTitle: {
    fontSize: 28,
    fontWeight: '800',
    color: colors.card,
    marginTop: 16,
    marginBottom: 8,
  },
  welcomeSubtitle: {
    fontSize: 16,
    color: colors.card,
    textAlign: 'center',
    opacity: 0.9,
    lineHeight: 22,
    paddingHorizontal: 10,
  },
  formContainer: {
    gap: 20,
    marginBottom: 30,
  },
  inputContainer: {
    backgroundColor: colors.card,
    borderRadius: 15,
    paddingHorizontal: 16,
    paddingVertical: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    boxShadow: '0px 2px 10px rgba(0, 0, 0, 0.1)',
    elevation: 2,
  },
  input: {
    flex: 1,
    fontSize: 16,
    color: colors.text,
  },
  resetButton: {
    backgroundColor: colors.card,
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 25,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
    boxShadow: '0px 4px 15px rgba(0, 0, 0, 0.1)',
    elevation: 4,
  },
  resetButtonDisabled: {
    opacity: 0.7,
  },
  resetButtonText: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.primary,
  },
  successContainer: {
    alignItems: 'center',
    gap: 30,
    marginBottom: 30,
  },
  successIcon: {
    alignItems: 'center',
  },
  backToLoginButton: {
    backgroundColor: colors.card,
    paddingVertical: 16,
    paddingHorizontal: 32,
    borderRadius: 25,
    boxShadow: '0px 4px 15px rgba(0, 0, 0, 0.1)',
    elevation: 4,
  },
  backToLoginText: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.primary,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
    flexWrap: 'wrap',
  },
  footerText: {
    fontSize: 14,
    color: colors.card,
    opacity: 0.9,
  },
  loginLink: {
    fontSize: 14,
    color: colors.card,
    fontWeight: '700',
    textDecorationLine: 'underline',
  },
});
