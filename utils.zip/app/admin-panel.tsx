
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  SafeAreaView,
  Platform,
  Alert,
  ScrollView,
  ImageBackground,
  TextInput,
  Modal,
  ActivityIndicator,
} from 'react-native';
import { Stack, router } from 'expo-router';
import { IconSymbol } from '@/components/IconSymbol';
import { colors } from '@/styles/commonStyles';
import { BlurView } from 'expo-blur';
import { supabase } from '@/app/integrations/supabase/client';
import { format, parseISO } from 'date-fns';
import { fr } from 'date-fns/locale';
import type { Tables } from '@/app/integrations/supabase/types';

export default function AdminPanelScreen() {
  console.log('AdminPanelScreen rendered');
  
  const [isAdmin, setIsAdmin] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [bookings, setBookings] = useState<Tables<'bookings'>[]>([]);
  const [selectedBooking, setSelectedBooking] = useState<Tables<'bookings'> | null>(null);
  const [showEditModal, setShowEditModal] = useState(false);
  
  // Edit form states
  const [editStartDate, setEditStartDate] = useState('');
  const [editEndDate, setEditEndDate] = useState('');
  const [editStartTime, setEditStartTime] = useState('');
  const [editEndTime, setEditEndTime] = useState('');
  const [editBookingStatus, setEditBookingStatus] = useState('');
  const [editPaymentStatus, setEditPaymentStatus] = useState('');
  const [editPickupLocation, setEditPickupLocation] = useState('');

  useEffect(() => {
    checkAdminAccess();
  }, []);

  useEffect(() => {
    if (isAdmin) {
      loadBookings();
    }
  }, [isAdmin]);

  const checkAdminAccess = async () => {
    try {
      setIsLoading(true);
      
      // Get current user
      const { data: { user }, error: userError } = await supabase.auth.getUser();
      
      if (userError || !user) {
        Alert.alert('Accès refusé', 'Vous devez être connecté pour accéder au panneau d\'administration.');
        router.back();
        return;
      }

      // Check if user is admin
      const { data: adminData, error: adminError } = await supabase
        .from('admin_users')
        .select('*')
        .eq('email', user.email)
        .single();

      if (adminError || !adminData) {
        Alert.alert('Accès refusé', 'Vous n\'avez pas les permissions d\'administrateur.');
        router.back();
        return;
      }

      setIsAdmin(true);
    } catch (error) {
      console.error('Error checking admin access:', error);
      Alert.alert('Erreur', 'Impossible de vérifier les permissions d\'administrateur.');
      router.back();
    } finally {
      setIsLoading(false);
    }
  };

  const loadBookings = async () => {
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setBookings(data || []);
    } catch (error) {
      console.error('Error loading bookings:', error);
      Alert.alert('Erreur', 'Impossible de charger les réservations.');
    }
  };

  const handleEditBooking = (booking: Tables<'bookings'>) => {
    setSelectedBooking(booking);
    setEditStartDate(booking.start_date);
    setEditEndDate(booking.end_date);
    setEditStartTime(booking.start_time);
    setEditEndTime(booking.end_time);
    setEditBookingStatus(booking.booking_status);
    setEditPaymentStatus(booking.payment_status);
    setEditPickupLocation(booking.pickup_location);
    setShowEditModal(true);
  };

  const handleSaveBooking = async () => {
    if (!selectedBooking) return;

    try {
      const { error } = await supabase
        .from('bookings')
        .update({
          start_date: editStartDate,
          end_date: editEndDate,
          start_time: editStartTime,
          end_time: editEndTime,
          booking_status: editBookingStatus,
          payment_status: editPaymentStatus,
          pickup_location: editPickupLocation,
          updated_at: new Date().toISOString(),
        })
        .eq('id', selectedBooking.id);

      if (error) throw error;

      Alert.alert('Succès', 'La réservation a été mise à jour avec succès.');
      setShowEditModal(false);
      loadBookings();
    } catch (error) {
      console.error('Error updating booking:', error);
      Alert.alert('Erreur', 'Impossible de mettre à jour la réservation.');
    }
  };

  const handleDeleteBooking = async (bookingId: string) => {
    Alert.alert(
      'Confirmer la suppression',
      'Êtes-vous sûr de vouloir supprimer cette réservation ?',
      [
        { text: 'Annuler', style: 'cancel' },
        {
          text: 'Supprimer',
          style: 'destructive',
          onPress: async () => {
            try {
              const { error } = await supabase
                .from('bookings')
                .delete()
                .eq('id', bookingId);

              if (error) throw error;

              Alert.alert('Succès', 'La réservation a été supprimée.');
              loadBookings();
            } catch (error) {
              console.error('Error deleting booking:', error);
              Alert.alert('Erreur', 'Impossible de supprimer la réservation.');
            }
          },
        },
      ]
    );
  };

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'confirmed':
      case 'confirmé':
        return colors.secondary;
      case 'pending':
      case 'en attente':
        return '#FFB74D';
      case 'cancelled':
      case 'annulé':
        return '#FF4444';
      case 'completed':
      case 'terminé':
        return '#4CAF50';
      default:
        return '#FFFFFF';
    }
  };

  const renderBookingCard = (booking: Tables<'bookings'>) => (
    <BlurView
      key={booking.id}
      intensity={5}
      tint="extraLight"
      style={[styles.bookingCard, Platform.OS !== 'ios' && { backgroundColor: 'rgba(255,255,255,0.05)' }]}
    >
      <View style={styles.bookingHeader}>
        <View style={styles.bookingIdContainer}>
          <IconSymbol name="number" color={colors.primary} size={16} />
          <Text style={styles.bookingId}>#{booking.id.slice(-8).toUpperCase()}</Text>
        </View>
        <View style={[styles.statusBadge, { backgroundColor: getStatusColor(booking.booking_status) }]}>
          <Text style={styles.statusText}>{booking.booking_status}</Text>
        </View>
      </View>

      <View style={styles.bookingInfo}>
        <View style={styles.infoRow}>
          <IconSymbol name="person.fill" color="#FFFFFF" size={16} />
          <Text style={styles.infoText}>
            {booking.guest_first_name || 'N/A'} {booking.guest_last_name || ''}
          </Text>
        </View>

        <View style={styles.infoRow}>
          <IconSymbol name="envelope.fill" color="#FFFFFF" size={16} />
          <Text style={styles.infoText}>{booking.guest_email || 'N/A'}</Text>
        </View>

        <View style={styles.infoRow}>
          <IconSymbol name="car.fill" color="#FFFFFF" size={16} />
          <Text style={styles.infoText}>Voiture ID: {booking.car_id}</Text>
        </View>

        <View style={styles.infoRow}>
          <IconSymbol name="calendar" color="#FFFFFF" size={16} />
          <Text style={styles.infoText}>
            {format(parseISO(booking.start_date), 'dd MMM yyyy', { locale: fr })} - {format(parseISO(booking.end_date), 'dd MMM yyyy', { locale: fr })}
          </Text>
        </View>

        <View style={styles.infoRow}>
          <IconSymbol name="clock" color="#FFFFFF" size={16} />
          <Text style={styles.infoText}>
            {booking.start_time} - {booking.end_time}
          </Text>
        </View>

        <View style={styles.infoRow}>
          <IconSymbol name="location.fill" color="#FFFFFF" size={16} />
          <Text style={styles.infoText}>{booking.pickup_location}</Text>
        </View>

        <View style={styles.infoRow}>
          <IconSymbol name="eurosign" color={colors.primary} size={16} />
          <Text style={[styles.infoText, { color: colors.primary, fontWeight: '700' }]}>
            {booking.total_price}€
          </Text>
        </View>

        <View style={styles.infoRow}>
          <IconSymbol name="creditcard.fill" color="#FFFFFF" size={16} />
          <Text style={styles.infoText}>
            Paiement: {booking.payment_status} ({booking.payment_method || 'N/A'})
          </Text>
        </View>
      </View>

      <View style={styles.bookingActions}>
        <Pressable
          style={[styles.actionButton, styles.editButton]}
          onPress={() => handleEditBooking(booking)}
        >
          <IconSymbol name="pencil" color={colors.card} size={16} />
          <Text style={styles.actionButtonText}>Modifier</Text>
        </Pressable>

        <Pressable
          style={[styles.actionButton, styles.deleteButton]}
          onPress={() => handleDeleteBooking(booking.id)}
        >
          <IconSymbol name="trash" color={colors.card} size={16} />
          <Text style={styles.actionButtonText}>Supprimer</Text>
        </Pressable>
      </View>
    </BlurView>
  );

  if (isLoading) {
    return (
      <ImageBackground
        source={require('@/assets/images/285c86af-6344-4f73-beac-dbfa2112b685.jpeg')}
        style={styles.container}
        resizeMode="cover"
      >
        <SafeAreaView style={styles.safeArea}>
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color={colors.primary} />
            <Text style={styles.loadingText}>Vérification des permissions...</Text>
          </View>
        </SafeAreaView>
      </ImageBackground>
    );
  }

  return (
    <ImageBackground
      source={require('@/assets/images/285c86af-6344-4f73-beac-dbfa2112b685.jpeg')}
      style={styles.container}
      resizeMode="cover"
    >
      <SafeAreaView style={styles.safeArea}>
        <Stack.Screen
          options={{
            title: 'Panneau d\'administration',
            headerShown: true,
            headerStyle: { backgroundColor: 'transparent' },
            headerTintColor: '#FFFFFF',
            headerTitleStyle: { fontWeight: '700', fontSize: 20 },
            headerLeft: () => (
              <Pressable onPress={() => router.back()} style={styles.headerBackButton}>
                <IconSymbol name="chevron.left" color="#FFFFFF" size={24} />
              </Pressable>
            ),
            headerBackground: () => (
              <BlurView
                intensity={10}
                tint="dark"
                style={[StyleSheet.absoluteFill, Platform.OS !== 'ios' && { backgroundColor: 'rgba(0,0,0,0.1)' }]}
              />
            ),
          }}
        />

        <ScrollView style={styles.scrollView} contentContainerStyle={styles.scrollContent}>
          <BlurView
            intensity={5}
            tint="extraLight"
            style={[styles.headerCard, Platform.OS !== 'ios' && { backgroundColor: 'rgba(255,255,255,0.05)' }]}
          >
            <IconSymbol name="shield.checkmark.fill" color={colors.primary} size={48} />
            <Text style={styles.headerTitle}>Panneau d'administration</Text>
            <Text style={styles.headerSubtitle}>
              Gérez toutes les réservations de la plateforme
            </Text>
            <Pressable style={styles.refreshButton} onPress={loadBookings}>
              <IconSymbol name="arrow.clockwise" color={colors.card} size={16} />
              <Text style={styles.refreshButtonText}>Actualiser</Text>
            </Pressable>
          </BlurView>

          <View style={styles.statsContainer}>
            <BlurView
              intensity={5}
              tint="extraLight"
              style={[styles.statCard, Platform.OS !== 'ios' && { backgroundColor: 'rgba(255,255,255,0.05)' }]}
            >
              <Text style={styles.statNumber}>{bookings.length}</Text>
              <Text style={styles.statLabel}>Total réservations</Text>
            </BlurView>

            <BlurView
              intensity={5}
              tint="extraLight"
              style={[styles.statCard, Platform.OS !== 'ios' && { backgroundColor: 'rgba(255,255,255,0.05)' }]}
            >
              <Text style={styles.statNumber}>
                {bookings.filter(b => b.booking_status.toLowerCase() === 'confirmed' || b.booking_status.toLowerCase() === 'confirmé').length}
              </Text>
              <Text style={styles.statLabel}>Confirmées</Text>
            </BlurView>

            <BlurView
              intensity={5}
              tint="extraLight"
              style={[styles.statCard, Platform.OS !== 'ios' && { backgroundColor: 'rgba(255,255,255,0.05)' }]}
            >
              <Text style={styles.statNumber}>
                {bookings.filter(b => b.booking_status.toLowerCase() === 'pending' || b.booking_status.toLowerCase() === 'en attente').length}
              </Text>
              <Text style={styles.statLabel}>En attente</Text>
            </BlurView>
          </View>

          <View style={styles.bookingsContainer}>
            <Text style={styles.sectionTitle}>Toutes les réservations</Text>
            {bookings.length === 0 ? (
              <BlurView
                intensity={5}
                tint="extraLight"
                style={[styles.emptyState, Platform.OS !== 'ios' && { backgroundColor: 'rgba(255,255,255,0.05)' }]}
              >
                <IconSymbol name="tray" color="#FFFFFF" size={48} />
                <Text style={styles.emptyStateText}>Aucune réservation trouvée</Text>
              </BlurView>
            ) : (
              bookings.map(renderBookingCard)
            )}
          </View>
        </ScrollView>

        {/* Edit Modal */}
        <Modal
          visible={showEditModal}
          transparent={true}
          animationType="slide"
          onRequestClose={() => setShowEditModal(false)}
        >
          <View style={styles.modalOverlay}>
            <BlurView
              intensity={10}
              tint="extraLight"
              style={[styles.modalContent, Platform.OS !== 'ios' && { backgroundColor: 'rgba(255,255,255,0.1)' }]}
            >
              <ScrollView showsVerticalScrollIndicator={false}>
                <Text style={styles.modalTitle}>Modifier la réservation</Text>

                <View style={styles.inputContainer}>
                  <Text style={styles.inputLabel}>Date de début</Text>
                  <TextInput
                    style={styles.textInput}
                    value={editStartDate}
                    onChangeText={setEditStartDate}
                    placeholder="YYYY-MM-DD"
                    placeholderTextColor="#CCCCCC"
                  />
                </View>

                <View style={styles.inputContainer}>
                  <Text style={styles.inputLabel}>Date de fin</Text>
                  <TextInput
                    style={styles.textInput}
                    value={editEndDate}
                    onChangeText={setEditEndDate}
                    placeholder="YYYY-MM-DD"
                    placeholderTextColor="#CCCCCC"
                  />
                </View>

                <View style={styles.inputContainer}>
                  <Text style={styles.inputLabel}>Heure de début</Text>
                  <TextInput
                    style={styles.textInput}
                    value={editStartTime}
                    onChangeText={setEditStartTime}
                    placeholder="HH:MM:SS"
                    placeholderTextColor="#CCCCCC"
                  />
                </View>

                <View style={styles.inputContainer}>
                  <Text style={styles.inputLabel}>Heure de fin</Text>
                  <TextInput
                    style={styles.textInput}
                    value={editEndTime}
                    onChangeText={setEditEndTime}
                    placeholder="HH:MM:SS"
                    placeholderTextColor="#CCCCCC"
                  />
                </View>

                <View style={styles.inputContainer}>
                  <Text style={styles.inputLabel}>Statut de réservation</Text>
                  <View style={styles.statusButtons}>
                    {['Confirmé', 'En attente', 'Annulé', 'Terminé'].map((status) => (
                      <Pressable
                        key={status}
                        style={[
                          styles.statusButton,
                          editBookingStatus === status && styles.statusButtonActive,
                        ]}
                        onPress={() => setEditBookingStatus(status)}
                      >
                        <Text
                          style={[
                            styles.statusButtonText,
                            editBookingStatus === status && styles.statusButtonTextActive,
                          ]}
                        >
                          {status}
                        </Text>
                      </Pressable>
                    ))}
                  </View>
                </View>

                <View style={styles.inputContainer}>
                  <Text style={styles.inputLabel}>Statut de paiement</Text>
                  <View style={styles.statusButtons}>
                    {['Payé', 'En attente', 'Remboursé'].map((status) => (
                      <Pressable
                        key={status}
                        style={[
                          styles.statusButton,
                          editPaymentStatus === status && styles.statusButtonActive,
                        ]}
                        onPress={() => setEditPaymentStatus(status)}
                      >
                        <Text
                          style={[
                            styles.statusButtonText,
                            editPaymentStatus === status && styles.statusButtonTextActive,
                          ]}
                        >
                          {status}
                        </Text>
                      </Pressable>
                    ))}
                  </View>
                </View>

                <View style={styles.inputContainer}>
                  <Text style={styles.inputLabel}>Lieu de récupération</Text>
                  <TextInput
                    style={styles.textInput}
                    value={editPickupLocation}
                    onChangeText={setEditPickupLocation}
                    placeholder="Lieu de récupération"
                    placeholderTextColor="#CCCCCC"
                  />
                </View>

                <View style={styles.modalButtons}>
                  <Pressable
                    style={[styles.modalButton, styles.cancelButton]}
                    onPress={() => setShowEditModal(false)}
                  >
                    <Text style={styles.cancelButtonText}>Annuler</Text>
                  </Pressable>

                  <Pressable
                    style={[styles.modalButton, styles.saveButton]}
                    onPress={handleSaveBooking}
                  >
                    <Text style={styles.saveButtonText}>Enregistrer</Text>
                  </Pressable>
                </View>
              </ScrollView>
            </BlurView>
          </View>
        </Modal>
      </SafeAreaView>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  headerBackButton: {
    padding: 8,
    marginLeft: -8,
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
    borderRadius: 20,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    fontSize: 16,
    color: '#FFFFFF',
    marginTop: 16,
  },
  headerCard: {
    borderRadius: 16,
    padding: 24,
    alignItems: 'center',
    marginBottom: 20,
    boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.3)',
    elevation: 8,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
    overflow: 'hidden',
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: '800',
    color: '#FFFFFF',
    marginTop: 12,
    marginBottom: 8,
    textAlign: 'center',
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#FFFFFF',
    textAlign: 'center',
    marginBottom: 16,
  },
  refreshButton: {
    backgroundColor: colors.primary,
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 8,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  refreshButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.card,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 12,
    marginBottom: 20,
  },
  statCard: {
    flex: 1,
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    boxShadow: '0px 2px 8px rgba(0, 0, 0, 0.2)',
    elevation: 4,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
    overflow: 'hidden',
  },
  statNumber: {
    fontSize: 28,
    fontWeight: '800',
    color: colors.primary,
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: '#FFFFFF',
    textAlign: 'center',
  },
  bookingsContainer: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#FFFFFF',
    marginBottom: 16,
  },
  emptyState: {
    borderRadius: 12,
    padding: 40,
    alignItems: 'center',
    boxShadow: '0px 2px 8px rgba(0, 0, 0, 0.2)',
    elevation: 4,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
    overflow: 'hidden',
  },
  emptyStateText: {
    fontSize: 16,
    color: '#FFFFFF',
    marginTop: 12,
  },
  bookingCard: {
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    boxShadow: '0px 2px 8px rgba(0, 0, 0, 0.2)',
    elevation: 4,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
    overflow: 'hidden',
  },
  bookingHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  bookingIdContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  bookingId: {
    fontSize: 14,
    fontWeight: '700',
    color: '#FFFFFF',
  },
  statusBadge: {
    paddingVertical: 4,
    paddingHorizontal: 12,
    borderRadius: 12,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  bookingInfo: {
    marginBottom: 12,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 8,
  },
  infoText: {
    fontSize: 14,
    color: '#FFFFFF',
    flex: 1,
  },
  bookingActions: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.1)',
  },
  actionButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 10,
    borderRadius: 8,
  },
  editButton: {
    backgroundColor: colors.primary,
  },
  deleteButton: {
    backgroundColor: '#FF4444',
  },
  actionButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.card,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.8)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalContent: {
    width: '100%',
    maxWidth: 500,
    maxHeight: '90%',
    borderRadius: 16,
    padding: 24,
    boxShadow: '0px 8px 24px rgba(0, 0, 0, 0.4)',
    elevation: 12,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
    overflow: 'hidden',
  },
  modalTitle: {
    fontSize: 22,
    fontWeight: '800',
    color: '#FFFFFF',
    marginBottom: 20,
    textAlign: 'center',
  },
  inputContainer: {
    marginBottom: 16,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#FFFFFF',
    marginBottom: 8,
  },
  textInput: {
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    borderWidth: 2,
    borderColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 8,
    padding: 12,
    fontSize: 14,
    color: '#FFFFFF',
  },
  statusButtons: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  statusButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderWidth: 2,
    borderColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 16,
  },
  statusButtonActive: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },
  statusButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  statusButtonTextActive: {
    color: colors.card,
  },
  modalButtons: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 20,
  },
  modalButton: {
    flex: 1,
    paddingVertical: 14,
    borderRadius: 8,
    alignItems: 'center',
  },
  cancelButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderWidth: 2,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  saveButton: {
    backgroundColor: colors.primary,
  },
  cancelButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  saveButtonText: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.card,
  },
});
