
import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  SafeAreaView,
  ImageBackground,
  Platform,
  Pressable,
} from 'react-native';
import { Stack, router } from 'expo-router';
import { IconSymbol } from '@/components/IconSymbol';
import { colors } from '@/styles/commonStyles';
import { BlurView } from 'expo-blur';

export default function AdminSetupInstructionsScreen() {
  return (
    <ImageBackground
      source={require('@/assets/images/285c86af-6344-4f73-beac-dbfa2112b685.jpeg')}
      style={styles.container}
      resizeMode="cover"
    >
      <SafeAreaView style={styles.safeArea}>
        <Stack.Screen
          options={{
            title: 'Configuration Admin',
            headerShown: true,
            headerStyle: { backgroundColor: 'transparent' },
            headerTintColor: '#FFFFFF',
            headerTitleStyle: { fontWeight: '700', fontSize: 20 },
            headerLeft: () => (
              <Pressable onPress={() => router.back()} style={styles.headerBackButton}>
                <IconSymbol name="chevron.left" color="#FFFFFF" size={24} />
              </Pressable>
            ),
            headerBackground: () => (
              <BlurView
                intensity={10}
                tint="dark"
                style={[StyleSheet.absoluteFill, Platform.OS !== 'ios' && { backgroundColor: 'rgba(0,0,0,0.1)' }]}
              />
            ),
          }}
        />

        <ScrollView style={styles.scrollView} contentContainerStyle={styles.scrollContent}>
          <BlurView
            intensity={5}
            tint="extraLight"
            style={[styles.card, Platform.OS !== 'ios' && { backgroundColor: 'rgba(255,255,255,0.05)' }]}
          >
            <IconSymbol name="exclamationmark.triangle.fill" color="#FFB74D" size={64} />
            <Text style={styles.title}>Configuration requise</Text>
            <Text style={styles.subtitle}>
              Pour activer le panneau d'administration, vous devez exécuter les migrations SQL suivantes dans votre base de données Supabase.
            </Text>

            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Étape 1: Créer la table admin_users</Text>
              <View style={styles.codeBlock}>
                <Text style={styles.code}>
{`-- Créer la table admin_users
CREATE TABLE IF NOT EXISTS admin_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  role text NOT NULL DEFAULT 'admin',
  created_at timestamptz DEFAULT now()
);

-- Activer RLS
ALTER TABLE admin_users ENABLE ROW LEVEL SECURITY;

-- Politique RLS pour les admins
CREATE POLICY "Admins can view admin records"
ON admin_users
FOR SELECT
TO authenticated
USING (true);

-- Créer des index
CREATE INDEX IF NOT EXISTS idx_admin_users_email 
ON admin_users(email);

-- Insérer le compte admin
INSERT INTO admin_users (email, role)
VALUES ('khaireddinechouki@outlook.fr', 'admin')
ON CONFLICT (email) DO NOTHING;`}
                </Text>
              </View>
            </View>

            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Étape 2: Mettre à jour les politiques RLS des réservations</Text>
              <View style={styles.codeBlock}>
                <Text style={styles.code}>
{`-- Politique pour permettre aux admins de voir toutes les réservations
CREATE POLICY "Admins can view all bookings"
ON bookings
FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM admin_users
    WHERE admin_users.email = (
      SELECT email FROM auth.users
      WHERE id = auth.uid()
    )
  )
);

-- Politique pour permettre aux admins de modifier les réservations
CREATE POLICY "Admins can update all bookings"
ON bookings
FOR UPDATE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM admin_users
    WHERE admin_users.email = (
      SELECT email FROM auth.users
      WHERE id = auth.uid()
    )
  )
);

-- Politique pour permettre aux admins de supprimer les réservations
CREATE POLICY "Admins can delete all bookings"
ON bookings
FOR DELETE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM admin_users
    WHERE admin_users.email = (
      SELECT email FROM auth.users
      WHERE id = auth.uid()
    )
  )
);`}
                </Text>
              </View>
            </View>

            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Comment appliquer ces migrations</Text>
              <Text style={styles.instruction}>
                1. Connectez-vous à votre tableau de bord Supabase
              </Text>
              <Text style={styles.instruction}>
                2. Allez dans l'onglet "SQL Editor"
              </Text>
              <Text style={styles.instruction}>
                3. Copiez et collez le code SQL de l'Étape 1
              </Text>
              <Text style={styles.instruction}>
                4. Cliquez sur "Run" pour exécuter
              </Text>
              <Text style={styles.instruction}>
                5. Répétez pour l'Étape 2
              </Text>
              <Text style={styles.instruction}>
                6. Vérifiez que tout fonctionne en vous connectant avec l'email admin
              </Text>
            </View>

            <View style={styles.warningBox}>
              <IconSymbol name="info.circle.fill" color={colors.primary} size={24} />
              <Text style={styles.warningText}>
                Une fois ces migrations appliquées, l'utilisateur avec l'email khaireddinechouki@outlook.fr pourra accéder au panneau d'administration et modifier toutes les réservations.
              </Text>
            </View>
          </BlurView>
        </ScrollView>
      </SafeAreaView>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  headerBackButton: {
    padding: 8,
    marginLeft: -8,
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
    borderRadius: 20,
  },
  card: {
    borderRadius: 16,
    padding: 24,
    boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.3)',
    elevation: 8,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
    overflow: 'hidden',
  },
  title: {
    fontSize: 24,
    fontWeight: '800',
    color: '#FFFFFF',
    marginTop: 16,
    marginBottom: 8,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 16,
    color: '#FFFFFF',
    textAlign: 'center',
    lineHeight: 22,
    marginBottom: 24,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.primary,
    marginBottom: 12,
  },
  codeBlock: {
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    borderRadius: 8,
    padding: 16,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
  },
  code: {
    fontSize: 12,
    color: '#FFFFFF',
    fontFamily: Platform.OS === 'ios' ? 'Courier' : 'monospace',
    lineHeight: 18,
  },
  instruction: {
    fontSize: 14,
    color: '#FFFFFF',
    marginBottom: 8,
    paddingLeft: 8,
  },
  warningBox: {
    backgroundColor: 'rgba(33, 150, 243, 0.2)',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    borderWidth: 1,
    borderColor: colors.primary,
    marginTop: 8,
  },
  warningText: {
    fontSize: 14,
    color: '#FFFFFF',
    flex: 1,
    lineHeight: 20,
  },
});
